from pathlib import Path
import json,csv,hashlib,collections,sys
ROOT=Path(__file__).resolve().parents[1];H=Path('/var/folders/sy/_tdkyl2x0gx6z5kl2wbhd9tc0000gn/T/graphite-view-cancel-helper.ptfakahe');D=ROOT/'complete38-pairs';O=Path(__file__).parent;V=Path('/private/tmp/graphite-independent-drain-v2.6csfc8du');P=V/'complete38-oracle'
sys.path.insert(0,str(V/'complete38-protocol'))
from verify_run import verify_run,validate_catalog,read_tsv
read=lambda p:json.loads(p.read_text())
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
r=read(D/'run.json');summary=read(D/'all38-pairs.json');proof=read(P/'run.json')
assert r['status']=='complete' and r['verifiedQueryOutputs']==456 and r['pairedQueryComparisons']==228
assert r['inputsUnchanged'] and r['graphInputsUnchanged'] and r['perQueryP95'] is None and not r['cpuAndRssMeasured']
assert proof['status']=='complete' and proof['oracleReady'] and proof['trustedControlVerified'] and proof['inputsUnchanged']
assert read(D/'graph-input-before.json')==read(D/'graph-input-after.json')==read(P/'graph-input-before.json')
before=r['inputHashesBefore'];after=r['inputHashesAfter'];assert set(before)<=set(after) and all(after[p]==h for p,h in before.items())
origins={**proof['oracleOutputHashes'],**proof['compiledClasses'],str(P/'run.json'):sha(P/'run.json'),str(P/'trusted-control-reference-check.json'):sha(P/'trusted-control-reference-check.json')}
added=set(after)-set(before);assert added==set(origins)-set(before)
assert all(after[p]==origins[p] for p in added)
assert r['oracleOutputHashes']==proof['oracleOutputHashes']
small={};large={}
for p,h in after.items():
 path=Path(p)
 if path.suffix not in {'.py','.java','.kt','.class','.json','.tsv','.correctness','.md','.patch','.log','.txt'} or path.stat().st_size>8*1024*1024:large[p]={'expected':h,'scope':'Historical checked receipt; large inputs verified by completed execution receipts; this offline audit rereads small inputs only'}
 else:assert sha(path)==h,p;small[p]=h
jars={'base':Path('/private/tmp/graphite-pr116-conflicts.ghc4dddf/repo/graphite-webgraph/build/libs/webgraph-1.0.0-SNAPSHOT-jmh.jar'),'candidate':H/'repo/graphite-webgraph/build/libs/webgraph-1.0.0-SNAPSHOT-jmh.jar'}
expectedsha={'base':'04ae90ec1f5560aa54f491a747e651c2f7b44ff453e169c9f2e8bb9fa9570814','candidate':'177d9c15cd07181766abbbc5ce275ab0da403c149a8a54e609857ae26eb91996'}
for side,p in jars.items():assert r['selectedJars'][side]=={'path':str(p),'sha256':expectedsha[side]} and after[str(p.resolve())]==expectedsha[side]
states=['per-query-cold','replay-cold'];orders=[['candidate','base'],['base','candidate'],['candidate','base']]
assert r['states']==states and r['order']==orders
labels=[f'{state}-group-{group}-{side}' for state in states for group,order in enumerate(orders,1) for side in order]
assert r['completed']==labels and len(r['commands'])==12
catalog=P/'oracle/catalog.json';workload=P/'oracle/workloads.tsv';_,ids=validate_catalog(read(catalog));assert len(ids)==38
assert sha(workload)=='f3e240e79739fd28ae8c869758dcd4b2bc2559c4c90254136ab74f0235ae3923'
checks={};raw={}
for label,cmd in zip(labels,r['commands']):
 side=label.rsplit('-',1)[1];state=next(s for s in states if label.startswith(s));prefix=D/label
 assert cmd['command']==['/opt/homebrew/opt/openjdk@17/libexec/openjdk.jdk/Contents/Home/bin/java','-Xmx8g','-XX:ActiveProcessorCount=4','-cp',str(ROOT/'classes')+':'+str(jars[side]),'MultiKeywordProfileRunner','/private/tmp/graphite-current34-jfr.fonqampc/graphs.local.tsv',str(workload),str(prefix),'all',state]
 assert cmd['exitCode']==0 and cmd['cleanup']=={'membersBeforeCleanup':[],'signals':[],'membersAfterCleanup':[],'drained':True}
 check=verify_run(catalog,workload,prefix,expected_reset=state);assert check['passed'] and check['queryCount']==38 and check['verifiedFullRowsAndProvenance'];checks[label]=check
 raw[label]=read_tsv(str(prefix)+'.tsv');assert [row['id'] for row in raw[label]]==ids
results={};nonlat=[]
for state in states:
 recs=[]
 assert len(summary['states'][state])==38
 for index,ident in enumerate(ids):
  old=summary['states'][state][index];assert old['id']==ident and old['ordinal']==index+1 and old['perQueryP95'] is None
  item={'id':ident,'ordinal':index+1,'pairs':[]}
  for side in jars:
   rr=[raw[f'{state}-group-{group}-{side}'][index] for group in range(1,4)];lat=[int(x['latencyNanos']) for x in rr];assert all(t>0 for t in lat)
   assert old['versions'][side]=={'allRawObservations':rr,'latencyNanos':lat,'medianLatencyNanos':sorted(lat)[1]}
  for group in range(1,4):
   b,c=[raw[f'{state}-group-{group}-{side}'][index] for side in ['base','candidate']];assert set(b)==set(c);bv=int(b['latencyNanos']);cv=int(c['latencyNanos']);diff={k:{'base':b[k],'candidate':c[k]} for k in b if k!='latencyNanos' and b[k]!=c[k]}
   pair={'group':group,'runOrder':orders[group-1],'baseLatencyNanos':bv,'candidateLatencyNanos':cv,'candidateOverBase':cv/bv,'deltaNanos':cv-bv,'above15PercentAnd1Ms':cv*100>bv*115 and cv-bv>1000000,'allNonLatencyDifferences':diff}
   assert pair==old['pairs'][group-1];item['pairs'].append(pair)
   if diff:nonlat.append({'state':state,'id':ident,'group':group,'differences':diff})
  repeated=sum(x['above15PercentAnd1Ms'] for x in item['pairs'])>=2;assert repeated==old['repeatedDoubleBoundary'];item['repeatedDoubleBoundary']=repeated;recs.append(item)
 results[state]=recs
out={'accepted':False,'full456ValuesOrderProvenanceVerified':True,'all12ExactCommandClasspathsVerified':True,'all228PairsRecomputed':True,'all12OwnedGroupsExited':True,'addedPinLineage':{p:{'expected':after[p],'origin':'prepared oracleOutputHashes' if p in proof['oracleOutputHashes'] else 'prepared compiledClasses' if p in proof['compiledClasses'] else 'prepared receipt SHA'} for p in sorted(added)},'smallPinsIndependentlyReread':small,'largePinScope':large,'fullVerifierResults':checks,'states':results,'allNonLatencyPairDifferences':nonlat,'primarySummaryMatches':True,'evidenceSHA256':{str(p):sha(p) for p in [D/'run.json',D/'all38-pairs.json',P/'run.json',catalog,workload,V/'complete38-protocol/verify_run.py']}}
(O/'full38-audit.json').write_text(json.dumps(out,indent=2)+'\n')
print('PASS456 full oracle,228pairs,12exactcp/exit, addedpins',len(added),'nonlat',len(nonlat))
for state,recs in results.items():
 print(state,'flags',[(x['id'],[p['candidateOverBase'] for p in x['pairs']]) for x in recs if x['repeatedDoubleBoundary']])
print('nonlat byquery',collections.Counter((x['state'],x['id']) for x in nonlat));print('nonlatkeys',collections.Counter(k for x in nonlat for k in x['differences']))
