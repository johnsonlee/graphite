"""Run only after parent confirms terminal capture; requires successful independent full38 audit."""
from pathlib import Path
import json,csv,hashlib,struct,collections
O=Path(__file__).resolve().parent;ROOT=O.parent;D=ROOT/'complete38-pairs';P=Path('/private/tmp/graphite-independent-drain-v2.6csfc8du/complete38-oracle');pins={}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):pins[str(p)]=sha(p);return json.loads(p.read_text())
r=read(D/'run.json');assert r['status']=='complete' and r['inputsUnchanged'] and r['graphInputsUnchanged']
a=read(O/'full38-audit.json');assert a['all228PairsRecomputed'] and a['full456ValuesOrderProvenanceVerified']
current=read(ROOT/'current-prefix/result.json');assert current['status']=='passed' and current['full200ValuesOrderProvenanceExact'] and not current['usedPrior45297AsInput'];prefix=current['oneBased200thMatchingCallSiteOrdinal']
c=read(P/'oracle/catalog.json');ids=[x['id'] for x in c['queries']];assert len(ids)==38 and ids[20]=='mixed-four-few-rows';assert hashlib.sha256(c['queries'][20]['query'].encode()).hexdigest()==current['querySha256']
manifest=Path(c['manifest']);pins[str(manifest)]=sha(manifest);sources=[l.split('\t') for l in manifest.read_text().splitlines() if l and not l.startswith('#')];assert len(sources)==64
before=read(D/'graph-input-before.json');assert before==read(D/'graph-input-after.json')==read(P/'graph-input-before.json');assert [x['id'] for x in before]==[x[0] for x in sources]
NAMES=['IntConstant','StringConstant','LongConstant','FloatConstant','DoubleConstant','BooleanConstant','NullConstant','EnumConstant','LocalVariable','FieldNode','ParameterNode','ReturnNode','CallSiteNode','AnnotationNode','ResourceValueNode','ResourceFileNode'];headers={};headerEvidence=[]
for source,g in zip(sources,before):
 p=Path(source[1])/'graph.typeindex'
 with p.open('rb') as f:
  start=f.read(8);magic,n=struct.unpack('>II',start);assert magic&0xffffff00==0x47525400 and 0<(magic&255)<=3 and n==len(NAMES);body=f.read(n*13)
 assert len(body)==n*13;decoded={}
 for i in range(n):
  tag,count,offset=struct.unpack_from('>Biq',body,i*13);assert 0<=tag<len(NAMES) and count>=0 and offset>=8+len(body) and offset+4*count<=p.stat().st_size
  name='io.johnsonlee.graphite.core.'+NAMES[tag];assert name not in decoded;decoded[name]=(count,offset)
 headers[source[0]]=decoded;proof=next(x for x in g['files'] if x['path']=='graph.typeindex');assert proof['size']==p.stat().st_size
 headerEvidence.append({'graphId':source[0],'path':str(p),'bytesRead':8+len(body),'headerSHA256':hashlib.sha256(start+body).hexdigest(),'recordedFullContentSHA256':proof['sha256'],'scope':'Actual compact header independently decoded; full payload SHA bound to completed measurement receipts, not rehashed here.'})
observations=[];seen=set();CALLSITE='io.johnsonlee.graphite.core.CallSiteNode'
for label,cmd in zip(r['completed'],r['commands']):
 actual=read(D/(label+'-process.json'));assert actual==cmd and cmd['exitCode']==0 and cmd['cleanup']['drained'] and not cmd['cleanup']['membersAfterCleanup']
 tpath=D/(label+'-type-order.json');t=read(tpath);assert sha(tpath)==r['typeOrderReports'][str(D/label)]['sha256'];assert sha(tpath)==r['outputHashes'][str(tpath)]
 assert t['schema']=='graphite-attempt146-complete38-type-order-v1' and t['mode']=='all' and t['resetMode']==cmd['command'][-1]
 assert t['targetId']==ids[20] and t['targetOriginalOrdinal']==21 and t['executedQueryIds']==ids
 assert t['pid']==cmd['pid']==cmd['pgid'] and t['pid'] not in seen;seen.add(t['pid'])
 assert t['vmArguments']==cmd['command'][1:3] and t['availableProcessors']==4 and t['javaVersion'].startswith('17.')
 assert t['inspectionStartedNanoTime']<=t['inspectionEndedNanoTime']
 assert [g['graphId'] for g in t['graphs']]==[x[0] for x in sources];classHashes={}
 for ordinal,g in enumerate(t['graphs']):
  assert g['sourceOrdinal']==ordinal and g['indexClass']=='io.johnsonlee.graphite.webgraph.MappedNodeTypeIndex' and g['graphClass']=='io.johnsonlee.graphite.webgraph.MappedWebGraphBackedGraph' and g['mapClass']=='java.util.HashMap'
  entries=g['entriesInActualMapIterationOrder'];assert len(entries)==16 and [e['mapEntryOrdinal'] for e in entries]==list(range(16))
  assert len({e['nodeClass'] for e in entries})==16;assert {e['nodeClass']:(e['count'],e['offsetBytes']) for e in entries}==headers[g['graphId']]
  assert not g['directNodeRangePresent'] # Actual current16-class index has no Node direct range; unexpected shape fails rather than infers.
  assert all(e['includedInUnlabeledNodeRanges'] for e in entries) and g['unlabeledNodeRangesInIteratorOrder']==entries
  assert g['totalNodeRangeCount']==sum(e['count'] for e in entries)
  for e in entries:
   assert e['classHashCode']==e['classIdentityHashCode'];assert classHashes.setdefault(e['nodeClass'],e['classHashCode'])==e['classHashCode']
 entries=t['graphs'][0]['unlabeledNodeRangesInIteratorOrder'];at=next(i for i,e in enumerate(entries) if e['nodeClass']==CALLSITE);pre=sum(e['count'] for e in entries[:at])
 tsv=D/(label+'.tsv');pins[str(tsv)]=sha(tsv);rows=list(csv.DictReader(tsv.open(),delimiter='\t'));q=rows[20];assert q['id']==ids[20] and q['workloadIdentity']==current['querySha256'] and q['digest']==current['resultDigest'] and q['rowCount']=='200' and q['hitGraphIds']=='fixture-android-00'
 work=int(q['graphWorkUnits']);observations.append({'label':label,'pid':t['pid'],'reset':t['resetMode'],'latencyNanos':int(q['latencyNanos']),'work':work,'actualPreCallSiteCounts':pre,'independentCurrentCallSitePrefix':prefix,'residual':work-pre,'accountingIdentityMatches':work==pre+prefix,'preCallSiteEntries':entries[:at],'firstGraphActualTypeOrder':[e['nodeClass'] for e in entries],'typeReportSHA256':pins[str(tpath)]})
assert len(observations)==12
result={'status':'complete-independent-observation-audit','accepted':False,'complete38Results':456,'queryPairs':228,'forks':12,'validatedGraphTypeMaps':12*64,'currentPrefix':prefix,'allWorkIdentitiesMatch':all(x['accountingIdentityMatches'] for x in observations),'observations':observations,'headerEvidence':headerEvidence,'limitations':['No latency/CPU causality from work identity.','Post-output immutable map order, not an in-query instrumentation record.','All original nonlat and flags remain in full38-audit.json; accounting agreement does not waive failures.','If any accounting identity mismatches it is retained as an observation, not silently coerced to the historical prefix.'],'inputHashes':pins}
(O/'type-audit.json').write_text(json.dumps(result,indent=2)+'\n');print('Independent type-map audit complete:768 maps,12 forks; work identities matched',sum(x['accountingIdentityMatches'] for x in observations),'/12')
