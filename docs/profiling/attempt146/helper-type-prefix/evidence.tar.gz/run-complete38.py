"""Paired full38 PR/serial-cancellation-guard diagnostic using the unchanged independently bound oracle."""
from pathlib import Path
import importlib.util, json, time, traceback, os
D = Path(__file__).resolve().parent
H = Path('/var/folders/sy/_tdkyl2x0gx6z5kl2wbhd9tc0000gn/T/graphite-view-cancel-helper.ptfakahe')
PROTOCOL = Path('/private/tmp/graphite-independent-drain-v2.6csfc8du/run-complete38.py')
spec = importlib.util.spec_from_file_location('frozen38', PROTOCOL)
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)

original_execute = m.execute

def diagnostic_execute(cmd, prefix, state, receipt, timeout):
    cmd = list(map(str, cmd))
    m.require(cmd.count('MultiKeywordProfileRunner') == 1 and cmd[-2] == 'all', 'Only full38 adapter commands expected')
    i = cmd.index('-cp') + 1
    old_classes, jar = cmd[i].rsplit(':', 1)
    m.require(old_classes == str(m.H / 'complete38-oracle/classes') and jar in set(map(str, m.JARS.values())), 'Unexpected classpath')
    cmd[i] = str(D / 'classes') + ':' + jar
    entry = original_execute(cmd, prefix, state, receipt, timeout)
    report = m.read(str(prefix) + '-type-order.json')
    ids = [q['id'] for q in m.read(m.H / 'complete38-oracle/oracle/catalog.json')['queries']]
    m.require(report['pid'] == entry['pid'] and report['mode'] == 'all' and report['resetMode'] == cmd[-1], 'Type report run binding')
    m.require(report['executedQueryIds'] == ids and len(ids) == 38, 'Type inspection did not follow full38')
    m.require(report['availableProcessors'] == 4 and '-Xmx8g' in report['vmArguments'], 'Wrong processor/heap budget')
    m.require(len(report['graphs']) == 64 and report['inspectionStartedNanoTime'] <= report['inspectionEndedNanoTime'], 'Type inspection incomplete')
    state.setdefault('typeOrderReports', {})[str(prefix)] = {'sha256': m.sha(str(prefix) + '-type-order.json'), 'pid': entry['pid']}
    m.write(receipt, state)
    return entry

m.execute = diagnostic_execute

def main():
    out = D / 'complete38-pairs'
    out.mkdir()
    receipt = out / 'run.json'
    state = {'status': 'running', 'accepted': False, 'pid': os.getpid(), 'commands': [], 'completed': [],
             'comparisonBase': 'Official PR5e05242a, SHA04ae90ec',
             'candidate': 'Official PR5e05242a plus task cancellation check in mapped-view interruption helper',
             'finalTargetReference': 'Frozen main4e328b01; this is not a main comparison or CI acceptance.',
             'order': m.ORDER, 'states': m.STATES, 'resetMeaning': m.RESET_MEANING,
             'samplesPerQueryPerVersionPerState': 3, 'perQueryP95': None, 'cpuAndRssMeasured': False,
             'notes': ['Frozen oracle is reused byte-for-byte; same original38 workload and same authenticated CI64 files.',
                       'Only selected executable JAR bindings change in this imported protocol instance; no frozen file changes.',
                       'No additional warmup/JFR/queue observation. Each replay uses a fresh P4/8g JVM.',
                       'Full values/order/provenance verified by original full38 verifier. Retain all work/coverage differences.',
                       'External JVM inventory retained; local diagnostic flags are not new CI gates.',
                       'Exactly one post-all-output type map inspection call is added to diagnostic adapter. Original production JARs unchanged; original methods verified after removal of the call. This is mechanism evidence, not performance acceptance.']}
    m.write(receipt, state)
    hashes, before = {}, None
    try:
        # Verify the original frozen protocol and its prepared-oracle provenance before selecting this experiment's JARs.
        hashes = m.pinned_inputs()
        prep = m.read(D / 'preparation.json')
        m.require(prep['status'] == 'verified', 'Adapter bytecode verification required')
        m.unchanged(prep['inputHashes']); m.unchanged(prep['classHashes'])
        hashes.update(prep['inputHashes']); hashes.update(prep['classHashes'])
        hashes.update(m.identities([D / 'preparation.json', D / 'verify-adapter.log']))
        build = m.read(H / 'build-receipt.json')
        scope = m.read(H / 'class-scope.json')
        m.require(scope['status'] == 'passed' and scope['allOtherClassBytesIdentical'], 'Scope verification must pass')
        m.require(build['status'] == 'passed' and build['allSourceInputsStillMatch'], 'Candidate checks must pass')
        jar = H / 'repo/graphite-webgraph/build/libs/webgraph-1.0.0-SNAPSHOT-jmh.jar'
        m.require(m.sha(jar) == build['candidateJarSha256'], 'Frozen candidate changed')
        m.require(build['candidateJarSha256'] == scope['candidateSha256'] and scope['baseSha256'] == '04ae90ec1f5560aa54f491a747e651c2f7b44ff453e169c9f2e8bb9fa9570814', 'Scope proof JAR binding differs')
        for p, want in build['sourceHashes'].items(): m.require(m.sha(H / 'repo' / p) == want, 'Checked source changed')
        baseline = m.JARS['base']
        m.require(m.sha(baseline) == '04ae90ec1f5560aa54f491a747e651c2f7b44ff453e169c9f2e8bb9fa9570814', 'Official PR baseline changed')
        m.JARS = {'base': baseline, 'candidate': jar}
        hashes.update(m.identities([Path(__file__), PROTOCOL, H / 'build-receipt.json', H / 'preparation.json',
                                   H / 'class-scope.json', H / 'verify-class-scope.py', H / 'SymbolicClassCompare.java', H / 'symbolic-methods.tsv', H / 'class-scope.log', H / 'symbolic-methods.tsv-base.txt', H / 'symbolic-methods.tsv-candidate.txt', H / 'candidate.patch',
                                   jar, *[H / 'repo' / p for p in build['sourceHashes']]]))
        state['selectedJars'] = {k: {'path': str(p), 'sha256': m.sha(p)} for k, p in m.JARS.items()}
        state['inputHashesBefore'] = hashes.copy()
        before = m.restored_identity()
        m.write(out / 'graph-input-before.json', before)
        m.write(receipt, state)
        m.paired(out, state, receipt, hashes, before)
    except BaseException:
        state.update(status='failed', error=traceback.format_exc())
        raise
    finally:
        try:
            m.require(all(c.get('cleanup', {}).get('drained') for c in state['commands'] if 'pid' in c), 'Private group still live')
            m.unchanged(hashes)
            if before is not None:
                after = m.restored_identity()
                m.write(out / 'graph-input-after.json', after)
                m.require(before == after, 'Fixture changed')
                state.update(inputsUnchanged=True, inputHashesAfter=m.identities(hashes), graphInputsUnchanged=True)
        except BaseException:
            state.update(status='failed', integrityError=traceback.format_exc())
            raise
        finally:
            state['outputHashes'] = m.identities([p for p in out.iterdir() if p.is_file() and p != receipt])
            state['finishedEpoch'] = time.time()
            m.write(receipt, state)

if __name__ == '__main__': main()
