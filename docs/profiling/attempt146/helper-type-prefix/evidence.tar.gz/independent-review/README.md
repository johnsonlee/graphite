# q21 generic traversal: existing evidence and minimal reuse

The current `mixed-four-few-rows` is original38 **ordinal 21**. It has exactly the same query SHA (`ec6f27daf80e0fffcfab75c2ed3ea92ed479a7248d7cc653e51aeb342e778d4e`) and expected 200-row values/order/provenance digest (`1ae0f35e1944fc343d3fae7b7dd0e25c206c08f602de0b7eaf1eed8bf26ddd43`) as attempt140's target. Its complete matching graph census includes android-00 and kotlin-compiler-15, but ordinary LIMIT returns the first 200 rows from android-00. This is a previously investigated mechanism, not a new scheduler finding.

## Current source route

Line references use the frozen helper repo `/var/folders/sy/_tdkyl2x0gx6z5kl2wbhd9tc0000gn/T/graphite-view-cancel-helper.ptfakahe/repo`.

- `QueryPipeline.kt:3138`–3165 candidate compilation first tries a direct filter/disjunction/regex; recursive candidate extraction then requires top-level AND. q21 is `(four-property OR A AND four-property OR B) OR (four-property OR C AND four-property OR D)`. Its outer OR cannot pass that recursion. Direct disjunction cannot compile the AND operands except an exists guard, and the top-level conjunction check also declines.
- `tryFastFilteredNodeLimit` consequently reaches its generic loop at 1472–1500. It evaluates the WHERE expression and projects each accepted node, stopping at 200 ordinary rows. `filteredNodeLimitFastPathExecutions=1` covers this entire handler; `generalFallbackExecutions=0` does not imply an indexed/raw fast route.
- `nodeCandidates` at 4503–4513 visits source graphs in order, wraps `source.graph.nodes(Node)` with `trackWork`, and qualifies each returned node. `MappedWebGraphBackedGraph.kt:246`–257 uses `nodeTypeIndex.ids(type)` → node offsets → `readNodeAt`; at 2560–2562, node reading calls `NodeSerializer.readNode` with the existing string table.
- `NodeTypeIndex.kt:86`–90 resolves a direct type range if present; otherwise it filters `rangesByType.entries` by assignability without sorting. That map is constructed as `HashMap<Class<out Node>, NodeTypeRange>` (95–108). The iterator (128–151) exhausts ranges in this list order. Class-key map iteration can therefore place different non-CallSite ranges before CallSite in different JVMs.

There is **no direct mapped-string-index-view lookup or `checkViewInterrupted` call on this query's generic traversal/predicate route**. Thus this query's work change must not be attributed to the added helper merely because it is the only production diff. Earlier full38 queries can execute changed code; altered execution history/JIT/heap effects remain possible but unproven. An incidental full-query stack would be needed for a runtime claim; static reachability and equal bytecode are not such a stack. This is also not evidence that all other full38 queries avoid the helper.

## What attempt140 actually proved

The completed top-level report and independent audit supersede the inner `type-order/README.md`'s stale “尚未执行” preparation wording. All **40 individual command JSONs** select `isolated per-query-cold`, 20 pairs alternating C/B and B/C, 8g/P4. The adapter selects only catalog ordinal21 from the then-36-query catalog. It supports `prefix-through-target` in source, but **zero prefix runs were scheduled or executed**. Neither the prior 40 nor its one-query timings are a full-prefix experiment.

The old completed independent audit verified 8,000 output rows and all 64 × 40 recorded type maps against compact binary typeindex headers. In all 40 isolated runs:

`recorded graphWorkUnits − sum(count of actual included ranges before CallSite in first graph) = 45,297`.

The header decoder is `type-order/independent-audit.py:95`–116: read 8-byte magic/count, then each 13-byte `>Biq` tag/count/offset record. At 150–181 it validates recorded map entries/range order, sums actual preceding counts, and checks the residual. The old audit explicitly did **not** independently scan the CallSite data to prove that 45,297 is the physical rank of the 200th matching CallSite. It is an empirically verified old residual, not an assumed current rank.

The old six rejected full-prefix JVMs did not record type order. Their work-minus-45,297 values fit type-count subsets, but subset arithmetic does not recover exact order or prove their causes. The same restriction applies to the current 12 helper forks: without their actual map order, compatible work is a hypothesis, not reconstructed runtime evidence.

## Old/current fixture identity

Comparing completed content receipts (not reading the multi-GB graphs), the source ID order and all 1,088 member names match. **862 file size/hash records match; 226 differ**:

- graph.nodedata: 64
- forward.properties: 64
- graph.metadata: 54
- forward.graph: 16
- forward.offsets: 14
- graph.labelprefix: 14

All 64 `graph.typeindex` size/hash records match, as do the string tables and string/property sidecar identities. This supports reusing the independently decoded type-count/range structure, subject to current binding, but **the whole old fixture is not byte-identical to the recovered CI fixture**. The exact target query and full expected 200 rows match independently; neither fact alone proves the current within-CallSite prefix rank. All 226 differences are retained in `history-and-fixture.json`; no cause for those byte differences is assumed here.

## Minimal complete38 diagnostic reuse

Reuse only the post-query reflection body of the old TypeOrderDiagnosticRunner, not its isolated/prefix selection code. Start from the current frozen `MultiKeywordProfileRunner`, retain all 38 original queries in order, original setup/reset semantics, submit/get/timeout/cancellation, complete TSV/full rows, original JARs 04ae/177d, 8g/P4 and three fixed pairs in each reset state. Keep oracle and input identities unchanged. Do not add a warmup, sort a map, restrict to q21, or insert any observation within timed queries.

Insert one read-only inspection call **after the final query timing and all original TSV/row output, before the existing tearDownTrial**. The helper should only read `sources → graph → nodeTypeIndex → rangesByType.entrySet`, recording each source's original ordinal/id, map implementation, direct-Node-range presence, entry order, class name/hash/identityHash, count/offset and assignability selection, plus PID/JVM arguments and inspection timestamps. Handle an unexpected index/type structure as diagnostic failure; never replace it with an inferred order. Preserve the original `finally` teardown and record private process-group drain separately. Hash the full outputs and final type report together. Class/map references are already present in the immutable loaded index; post-replay observation does not establish the order if a future implementation mutates/replaces that map, so confirm its lifecycle under the exact JAR.

Compile only the adapter/helper externally; production JAR payloads must remain unchanged. Validate original adapter instructions after stripping the single inserted call (and report any helper payloads); verify exact commands, both reset states, all 456 results/228 pairs, no new query observer and source/JAR/fixture before/after pins. Reflection/class-loading/output after the final query can still perturb teardown/whole-process runtime; it is not part of query latency and is not a performance acceptance artifact.

For each new fork, join q21's exact id/query hash/work/complete rows to that fork's PID/type report. Independently decode current compact typeindex headers and match **all** recorded ranges, including zero counts and a direct Node range if present. Sum only actually included non-CallSite ranges preceding CallSite in the first source. Then compare work minus this sum to a separately authenticated current CallSite prefix calculation (or report it as a residual if not derived). Binding should include the current node data/string table identities, original CallSite ID order and full predicate semantics; do not simply set the expected rank to 45,297. The post-query evidence can establish actual map order under the immutable-map contract and a work accounting identity, but cannot assign all elapsed-time differences to that identity or quantify scheduler/CPU costs.

No new JVM, benchmark, production code or diagnostic adapter was run or edited by this audit. `audit-history.py` independently checks the 40 commands, fixture receipts, target query and expected rows; it completed successfully. This report narrows the next evidence collection and does not accept the helper candidate or retrospectively reverse any failed gate.
