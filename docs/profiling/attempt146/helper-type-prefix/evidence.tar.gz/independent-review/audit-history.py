from pathlib import Path
import json,gzip,hashlib,collections
ROOT=Path('/Users/johnsonlee/.codex/worktrees/ac7b5da2-2450-48c5-894c-5fd84ab6cb7d/graphite');OLD=ROOT/'docs/profiling/attempt140/causal-diagnosis/type-order';H=Path('/var/folders/sy/_tdkyl2x0gx6z5kl2wbhd9tc0000gn/T/graphite-view-cancel-helper.ptfakahe');O=Path(__file__).resolve().parent;hashes={}
def read(p):
 data=p.read_bytes();hashes[str(p)]=hashlib.sha256(data).hexdigest();return json.loads(gzip.decompress(data) if p.suffix=='.gz' else data)
def pin(p):hashes[str(p)]=hashlib.sha256(p.read_bytes()).hexdigest()
a=read(OLD/'inputs-before.json.gz');assert a==read(OLD/'inputs-after.json.gz');b=read(H/'complete38-pairs/graph-input-before.json');assert b==read(H/'complete38-pairs/graph-input-after.json');assert [x['id'] for x in a]==[x['id'] for x in b]
aa={(g['id'],f['path']):f for g in a for f in g['files']};bb={(g['id'],f['path']):f for g in b for f in g['files']};assert aa.keys()==bb.keys() and len(aa)==1088
changes=[{'graphId':k[0],'file':k[1],'old':aa[k],'current':bb[k]} for k in sorted(aa) if aa[k]!=bb[k]]
assert all(aa[(g['id'],'graph.typeindex')]==bb[(g['id'],'graph.typeindex')] for g in a)
old=read(OLD/'independent-audit.json.gz');plan=read(OLD/'measurement-plan.json.gz');oldReceipt=read(OLD/'receipt.json')
commands=[]
for i in range(1,21):
 for side in ['candidate','base'] if i%2 else ['base','candidate']:
  p=OLD/f'pair-{i:02d}-{side}/command.json';cmd=read(p);assert cmd[-2:]==['isolated','per-query-cold'];assert '-Xmx8g' in cmd and '-XX:ActiveProcessorCount=4' in cmd;commands.append({'pair':i,'side':side,'mode':cmd[-2],'reset':cmd[-1],'command':cmd})
assert old['verifiedNewQueries']==40 and old['scheduledPrefixRuns']==0 and old['remainingWorkValues']==[45297]
c=read(Path('/private/tmp/graphite-independent-drain-v2.6csfc8du/complete38-oracle/oracle/catalog.json'));q=c['queries'][20];assert q['id']=='mixed-four-few-rows' and not q['distinct'] and len(q['expectedRows'])==200
querysha=hashlib.sha256(q['query'].encode()).hexdigest();digest=hashlib.sha256(json.dumps(q['expectedRows'],ensure_ascii=False,separators=(',',':')).encode()).hexdigest();assert querysha==old['querySha256'];assert digest==old['oracleRowsDigest']
for p in [OLD/'TypeOrderDiagnosticRunner.java',OLD/'independent-audit.py',OLD/'README.md',OLD.parent/'README.md',OLD.parent/'path-audit.md']:pin(p)
for rel in ['graphite-cypher/src/main/kotlin/io/johnsonlee/graphite/cypher/QueryPipeline.kt','graphite-webgraph/src/main/kotlin/io/johnsonlee/graphite/webgraph/MappedWebGraphBackedGraph.kt','graphite-webgraph/src/main/kotlin/io/johnsonlee/graphite/webgraph/NodeTypeIndex.kt']:pin(H/'repo'/rel)
r={'status':'passed-read-only-history-and-source-audit','accepted':False,'queryId':q['id'],'ordinal':21,'querySHA256':querysha,'expected200RowsDigest':digest,'currentHitGraphs':q['expectedHitGraphIds'],'old40ExecutionCommands':commands,'oldPrefixRuns':0,'oldObservedResidualWork':45297,'oldCountResidualIsCurrentPrefixProof':False,'fixtureComparison':{'sameSourceIdOrder':True,'fileCountEach':1088,'sameFiles':1088-len(changes),'changedFiles':len(changes),'changedByName':dict(collections.Counter(x['file'] for x in changes)),'all64TypeIndexReceiptsEqual':True,'wholeFixtureBytesEqual':False,'differences':changes,'scope':'Comparing completed before/after size+SHA receipts, not rereading graph payload.'},'inputHashes':hashes}
(O/'history-and-fixture.json').write_text(json.dumps(r,indent=2)+'\n');print('PASS',len(commands),'isolated commands; unchanged q21 query/full expected rows; fixture equal',1088-len(changes),'different',len(changes))
