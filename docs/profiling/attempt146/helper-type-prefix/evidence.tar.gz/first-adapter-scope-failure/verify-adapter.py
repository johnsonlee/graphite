from pathlib import Path
import importlib.util
D=Path(__file__).resolve().parent
p=Path('/private/tmp/graphite-independent-drain-v2.6csfc8du/run-complete38.py');s=importlib.util.spec_from_file_location('m',p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
r=m.read(D/'preparation.json');m.require(r['status']=='compiled-awaiting-bytecode-verification','Already processed or not compiled');m.unchanged(r['inputHashes']);m.unchanged(r['classHashes'])
e=['--add-exports','java.base/jdk.internal.org.objectweb.asm=ALL-UNNAMED','--add-exports','java.base/jdk.internal.org.objectweb.asm.tree=ALL-UNNAMED']
m.execute([m.JAVA.with_name('javac'),'-J-Xmx1g',*e,'-d',D/'verify-classes',D/'SymbolicClassCompare.java',D/'VerifyAdapter.java'],D/'compile-verifier',r,D/'preparation.json',180)
m.execute([m.JAVA,'-Xmx1g',*e,'-cp',D/'verify-classes','VerifyAdapter',D/'original-classes/MultiKeywordProfileRunner.class',D/'classes/MultiKeywordProfileRunner.class',D/'adapter-symbolic.tsv'],D/'verify-adapter',r,D/'preparation.json',180)
r['inputHashes'].update(m.identities([D/'VerifyAdapter.java',D/'verify-adapter.py',D/'adapter-symbolic.tsv',*list((D/'verify-classes').glob('*.class'))]))
r['status']='verified';m.write(D/'preparation.json',r)
print('verified')
