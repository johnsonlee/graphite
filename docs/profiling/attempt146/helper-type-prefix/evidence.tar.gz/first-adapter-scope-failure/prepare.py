from pathlib import Path
import hashlib,json,importlib.util,shutil
D=Path(__file__).resolve().parent
ROOT=Path('/Users/johnsonlee/.codex/worktrees/ac7b5da2-2450-48c5-894c-5fd84ab6cb7d/graphite')
H=Path('/var/folders/sy/_tdkyl2x0gx6z5kl2wbhd9tc0000gn/T/graphite-view-cancel-helper.ptfakahe')
P=Path('/private/tmp/graphite-independent-drain-v2.6csfc8du')
spec=importlib.util.spec_from_file_location('m',P/'run-complete38.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
original=P/'complete38-protocol/MultiKeywordProfileRunner.java'
old=ROOT/'docs/profiling/attempt140/causal-diagnosis/type-order/TypeOrderDiagnosticRunner.java'
s=original.read_text();t=old.read_text()
start=t.index('            // Deliberately after query timing')
end=t.index('        } finally {b.tearDownTrial();}',start)
body=t[start:end].replace('graphite-attempt140-type-order-v1','graphite-attempt146-complete38-type-order-v1')
body=body.replace('diagnostic.put("mode",args[3]);','diagnostic.put("mode",args[3]); diagnostic.put("resetMode",args[4]);')
method='\n    static void inspectTypeOrder(List<CypherGraph> sources, List<Map<String,String>> workload, Path prefix, String[] args) throws Exception {\n'+body+'    }\n'
call='            inspectTypeOrder(sources, workload, prefix, args);\n'
anchor='        } finally {b.tearDownTrial();}'
assert s.count(anchor)==1
candidate=s.replace(anchor,call+anchor)
pos=candidate.rfind('}')
candidate=candidate[:pos]+method+candidate[pos:]
assert candidate.replace(method,'').replace(call,'')==s
(D/'original').mkdir();(D/'adapter').mkdir();(D/'classes').mkdir();(D/'original-classes').mkdir();(D/'verify-classes').mkdir()
shutil.copyfile(original,D/'original/MultiKeywordProfileRunner.java')
(D/'adapter/MultiKeywordProfileRunner.java').write_text(candidate)
shutil.copyfile(H/'SymbolicClassCompare.java',D/'SymbolicClassCompare.java')
state={'status':'preparing','commands':[],'accepted':False,'sourceRestoresByteExactlyAfterRemovingOneMethodAndCall':True,
'plannedQueries':38,'plannedStates':m.STATES,'plannedPairsPerState':3,'plannedJvms':12,'order':m.ORDER,
'purpose':'Bind actual immutable type-map order to q21 work under the full38 prefix. Diagnostic only; not performance acceptance.',
'unchangedProductionJars':{'base':str(m.JARS['base']),'candidate':str(H/'repo/graphite-webgraph/build/libs/webgraph-1.0.0-SNAPSHOT-jmh.jar')},
'inputHashes':m.identities([original,old,D/'prepare.py',D/'original/MultiKeywordProfileRunner.java',D/'adapter/MultiKeywordProfileRunner.java',D/'SymbolicClassCompare.java'])}
m.write(D/'preparation.json',state)
for name,source,out in [('original',D/'original/MultiKeywordProfileRunner.java',D/'original-classes'),('adapter',D/'adapter/MultiKeywordProfileRunner.java',D/'classes')]:
 m.execute([m.JAVA.with_name('javac'),'-J-Xmx1g','-cp',m.JARS['base'],'-d',out,source],D/('compile-'+name),state,D/'preparation.json',180)
state['status']='compiled-awaiting-bytecode-verification';state['classHashes']=m.identities(list((D/'classes').glob('*.class'))+list((D/'original-classes').glob('*.class')))
m.write(D/'preparation.json',state)
print(json.dumps({'status':state['status'],'classHashes':state['classHashes']}))
