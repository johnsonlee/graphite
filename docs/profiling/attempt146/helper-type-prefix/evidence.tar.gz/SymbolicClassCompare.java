import java.nio.file.*;
import java.util.*;
import java.util.jar.*;
import java.security.MessageDigest;
import jdk.internal.org.objectweb.asm.*;
import jdk.internal.org.objectweb.asm.tree.*;

/** Compare symbolic bytecode without executing either graph implementation. */
class SymbolicClassCompare {
    static String atom(String value) { return value.length()+":"+value; }
    static String constant(Object value) {
        if (value == null) return "null";
        if (value instanceof Handle h) return "handle("+h.getTag()+","+atom(h.getOwner())+","+atom(h.getName())+","+atom(h.getDesc())+","+h.isInterface()+")";
        if (value instanceof Type t) return "type("+atom(t.getDescriptor())+")";
        if (value instanceof ConstantDynamic d) {
            var result = new StringBuilder("dynamic(").append(atom(d.getName())).append(',').append(atom(d.getDescriptor())).append(',').append(constant(d.getBootstrapMethod())).append(" argc=").append(d.getBootstrapMethodArgumentCount());
            for (int i=0;i<d.getBootstrapMethodArgumentCount();i++) result.append(',').append(constant(d.getBootstrapMethodArgument(i)));
            return result.append(')').toString();
        }
        if (value instanceof Float f) return "float-bits:"+Integer.toHexString(Float.floatToRawIntBits(f));
        if (value instanceof Double d) return "double-bits:"+Long.toHexString(Double.doubleToRawLongBits(d));
        if (value instanceof String text) return "string:"+atom(text);
        if (value instanceof Integer number) return "int:"+number;
        if (value instanceof Long number) return "long:"+number;
        throw new IllegalArgumentException("Unhandled constant "+value.getClass());
    }
    static int target(Map<LabelNode,Integer> labels, LabelNode label) {
        Integer value=labels.get(label); if(value==null) throw new IllegalStateException("Unresolved label"); return value;
    }
    static String symbolic(MethodNode method) {
        var labels = new IdentityHashMap<LabelNode,Integer>(); int index=0;
        for(AbstractInsnNode i:method.instructions) {
            if(i instanceof LabelNode l) labels.put(l,index);
            else if(i.getOpcode()>=0) index++;
        }
        var out=new StringBuilder().append("access=").append(method.access).append(" desc=").append(method.desc)
            .append(" signature=").append(method.signature).append(" exceptions=").append(method.exceptions)
            .append(" maxStack=").append(method.maxStack).append(" maxLocals=").append(method.maxLocals).append('\n');
        for(AbstractInsnNode i:method.instructions) {
            if(i.getOpcode()<0) continue;
            out.append(i.getOpcode()).append(' ');
            if(i instanceof InsnNode) {}
            else if(i instanceof IntInsnNode n) out.append(n.operand);
            else if(i instanceof VarInsnNode n) out.append(n.var);
            else if(i instanceof TypeInsnNode n) out.append(n.desc);
            else if(i instanceof FieldInsnNode n) out.append(n.owner).append('.').append(n.name).append(':').append(n.desc);
            else if(i instanceof MethodInsnNode n) out.append(n.owner).append('.').append(n.name).append(n.desc).append(" interface=").append(n.itf);
            else if(i instanceof InvokeDynamicInsnNode n) {
                out.append(n.name).append(n.desc).append(" bootstrap=").append(constant(n.bsm)).append(" argc=").append(n.bsmArgs.length);
                for(Object a:n.bsmArgs) out.append(" arg=").append(constant(a));
            }
            else if(i instanceof JumpInsnNode n) out.append(target(labels,n.label));
            else if(i instanceof LdcInsnNode n) out.append(constant(n.cst));
            else if(i instanceof IincInsnNode n) out.append(n.var).append(' ').append(n.incr);
            else if(i instanceof TableSwitchInsnNode n) {
                out.append(n.min).append(' ').append(n.max).append(" default=").append(target(labels,n.dflt));
                for(LabelNode l:n.labels) out.append(' ').append(target(labels,l));
            }
            else if(i instanceof LookupSwitchInsnNode n) {
                out.append("default=").append(target(labels,n.dflt));
                for(int k=0;k<n.keys.size();k++) out.append(' ').append(n.keys.get(k)).append(':').append(target(labels,n.labels.get(k)));
            }
            else if(i instanceof MultiANewArrayInsnNode n) out.append(n.desc).append(' ').append(n.dims);
            else throw new IllegalStateException("Unhandled instruction "+i.getClass());
            out.append('\n');
        }
        for(TryCatchBlockNode t:method.tryCatchBlocks) out.append("catch ").append(target(labels,t.start)).append(' ').append(target(labels,t.end)).append(' ').append(target(labels,t.handler)).append(' ').append(t.type).append('\n');
        return out.toString();
    }
    static Map<String,String> methods(Path path, String className) throws Exception {
        try(var jar=new JarFile(path.toFile())) {
            var entry=Objects.requireNonNull(jar.getJarEntry(className+".class"));
            var node=new ClassNode();
            new ClassReader(jar.getInputStream(entry)).accept(node,ClassReader.SKIP_DEBUG|ClassReader.SKIP_FRAMES);
            var result=new TreeMap<String,String>();
            for(MethodNode m:node.methods) {
                if(result.put(m.name+m.desc,symbolic(m))!=null) throw new IllegalStateException("Duplicate method");
            }
            return result;
        }
    }
    static String sha(String value) throws Exception { return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(value.getBytes(java.nio.charset.StandardCharsets.UTF_8))); }
    static MethodNode fixture(boolean padding, String owner, int destination) {
        var writer=new ClassWriter(0);
        if(padding) writer.newConst("unused-constant-pool-padding");
        writer.visit(Opcodes.V11,Opcodes.ACC_PUBLIC,"fixture/Compare",null,"java/lang/Object",null);
        var mv=writer.visitMethod(Opcodes.ACC_PUBLIC|Opcodes.ACC_STATIC,"run","()V",null,null);
        var first=new Label();var second=new Label();
        mv.visitCode();mv.visitInsn(Opcodes.ICONST_0);
        mv.visitJumpInsn(Opcodes.IFEQ,destination==0?first:second);
        mv.visitLabel(first);mv.visitFieldInsn(Opcodes.GETSTATIC,owner,"field","I");mv.visitInsn(Opcodes.POP);
        mv.visitLabel(second);mv.visitInsn(Opcodes.RETURN);mv.visitMaxs(1,0);mv.visitEnd();writer.visitEnd();
        var parsed=new ClassNode();new ClassReader(writer.toByteArray()).accept(parsed,ClassReader.SKIP_DEBUG|ClassReader.SKIP_FRAMES);
        return parsed.methods.get(0);
    }
    static void selfTest() {
        String base=symbolic(fixture(false,"fixture/Owner",0));
        if(!base.equals(symbolic(fixture(true,"fixture/Owner",0)))) throw new AssertionError("CP relocation changed symbolic meaning");
        if(base.equals(symbolic(fixture(false,"fixture/Other",0)))) throw new AssertionError("Field owner change lost");
        if(base.equals(symbolic(fixture(false,"fixture/Owner",1)))) throw new AssertionError("Branch destination change lost");
        var bootstrap=new Handle(Opcodes.H_INVOKESTATIC,"fixture/Bootstrap","make","()Ljava/lang/Object;",false);
        String one=constant(new ConstantDynamic("value","Ljava/lang/Object;",bootstrap,"x arg=java.lang.String:y"));
        String two=constant(new ConstantDynamic("value","Ljava/lang/Object;",bootstrap,"x","y"));
        if(one.equals(two)) throw new AssertionError("Constant/argument serialization collision");
        try {constant(new Object());throw new AssertionError("Unknown constant accepted");}
        catch(IllegalArgumentException expected) {}
        System.out.println("PASS5 symbolic verifier checks: CP relocation, owner, branch, bootstrap-arg ambiguity, unknown constant");
    }
    public static void main(String[] args) throws Exception {
        selfTest();
        Path base=Path.of(args[0]), candidate=Path.of(args[1]), out=Path.of(args[2]);
        var report=new StringBuilder("class\tmethod\tstatus\n"); int changed=0, equal=0;
        try(var b=new JarFile(base.toFile());var c=new JarFile(candidate.toFile())) {
            for(var entry:Collections.list(b.entries())) {
                String n=entry.getName(); if(!n.endsWith(".class")) continue;
                if(Arrays.equals(b.getInputStream(entry).readAllBytes(),c.getInputStream(c.getJarEntry(n)).readAllBytes())) continue;
                String cls=n.substring(0,n.length()-6); var bm=methods(base,cls);var cm=methods(candidate,cls);
                if(!bm.keySet().equals(cm.keySet())) throw new AssertionError("Methods changed: "+cls);
                for(String method:bm.keySet()) {
                    boolean same=bm.get(method).equals(cm.get(method));
                    report.append(cls).append('\t').append(method).append('\t').append(same?"equal":"changed").append('\n');
                    if(same) equal++; else {
                        changed++;
                        if(!cls.equals("io/johnsonlee/graphite/webgraph/MappedCallSiteStringIndexViewKt") || !method.equals("checkViewInterrupted()V")) throw new AssertionError("Unexpected method change: "+cls+" "+method);
                        Files.writeString(Path.of(args[2]+"-base.txt"),bm.get(method));
                        Files.writeString(Path.of(args[2]+"-candidate.txt"),cm.get(method));
                    }
                }
            }
        }
        Files.writeString(out,report);
        if(changed!=1) throw new AssertionError("changed="+changed);
        System.out.println("PASS: changed="+changed+" unchanged methods in byte-different classes="+equal);
    }
}
