import java.nio.file.*;
import java.util.*;
import jdk.internal.org.objectweb.asm.*;
import jdk.internal.org.objectweb.asm.tree.*;
public class VerifyAdapter {
 static ClassNode read(String p) throws Exception { var c=new ClassNode();new ClassReader(Files.readAllBytes(Path.of(p))).accept(c,ClassReader.SKIP_DEBUG|ClassReader.SKIP_FRAMES);return c; }
 static Map<String,MethodNode> methods(ClassNode c) {var m=new TreeMap<String,MethodNode>();for(var x:c.methods)if(m.put(x.name+x.desc,x)!=null)throw new AssertionError("duplicate");return m;}
 public static void main(String[] args) throws Exception {
  SymbolicClassCompare.selfTest();
  var b=read(args[0]);var c=read(args[1]);var bm=methods(b);var cm=methods(c);
  String extra="inspectTypeOrder(Ljava/util/List;Ljava/util/List;Ljava/nio/file/Path;[Ljava/lang/String;)V";
  if(!cm.containsKey(extra) || bm.containsKey(extra) || cm.size()!=bm.size()+1)throw new AssertionError("scope");
  cm.remove(extra);
  if(!bm.keySet().equals(cm.keySet()))throw new AssertionError("method set");
  MethodNode main=cm.get("main([Ljava/lang/String;)V");int calls=0;var removed=new ArrayList<String>();
  for(AbstractInsnNode n:main.instructions.toArray()) if(n instanceof MethodInsnNode x && x.owner.equals("MultiKeywordProfileRunner") && x.name.equals("inspectTypeOrder")) {
   if(x.getOpcode()!=Opcodes.INVOKESTATIC || !x.desc.equals(extra.substring(extra.indexOf('('))))throw new AssertionError("call shape");
   AbstractInsnNode prev=x.getPrevious();
   for(int i=0;i<4;i++) {
    if(!(prev instanceof VarInsnNode v) || v.getOpcode()!=Opcodes.ALOAD)throw new AssertionError("call argument");
    removed.add("ALOAD "+v.var);AbstractInsnNode next=prev.getPrevious();main.instructions.remove(prev);prev=next;
   }
   main.instructions.remove(x);calls++;
  }
  if(calls!=1)throw new AssertionError("call count");
  var report=new StringBuilder("method\tstatus\n");
  for(String key:bm.keySet()) {
   String bs=SymbolicClassCompare.symbolic(bm.get(key)),cs=SymbolicClassCompare.symbolic(cm.get(key));
   Files.writeString(Path.of(args[2]+"-"+key.substring(0,key.indexOf('(')).replace('<','_').replace('>','_')+"-base.txt"),bs);
   Files.writeString(Path.of(args[2]+"-"+key.substring(0,key.indexOf('(')).replace('<','_').replace('>','_')+"-candidate-stripped.txt"),cs);
   if(!bs.equals(cs))throw new AssertionError("Changed original method: "+key);
   report.append(key).append("\tequal\n");
  }
  Files.writeString(Path.of(args[2]),report);
  System.out.println("PASS: original methods="+bm.size()+", exactly one post-output call removed; arguments reverse="+removed+"; one inspection method added. Comparison ignores debug/frames/class metadata and does not assert JIT equivalence.");
 }
}
