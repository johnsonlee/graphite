# Full38 type-order diagnosis of the cancellation helper candidate

Status: complete and independently audited; no candidate accepted and no performance gate waived. See [RESULTS.md](RESULTS.md) for all six q21 pairs and remaining regression flags.

The existing 177d helper fixes reproduced task cancellation gaps, but original34 still fails against starting main and full38 previously flags q21. This experiment diagnoses q21 without adding an optimization direction. It compares the unchanged official 04ae and helper177d JARs on authenticated real CI64 graphs, P4, max heap8g, all38 queries in their original order, both original reset modes, three fixed C/B–B/C–C/B pairs each (12 fresh sequential JVMs).

The adapter adds a single read-only inspection call after all query timers AND full TSV/rows output, before teardown. It reads the immutable mapped type index's actual HashMap order. After removing four argument loads and that call, all nine original methods' symbolic instructions and exception regions match. The freshly compiled original class is byte-identical to the frozen full38 adapter. Debug/frames/metadata are excluded from symbolic comparison; this is not JIT equivalence. The initial inspection used a stream lambda and failed the one-extra-method scope check; that complete preparation is preserved in first-adapter-scope-failure, and the final helper uses a simple loop.

current-prefix/ independently derives the first graph's 200th matching CallSite at ordinal45297 from the current trusted export and verifies all200 result values/order/provenance. The old Attempt14040-fork isolated residual is not used as an input. Current independent-review/ explains the generic source path and old/current fixture differences.

The testable identity for each new fork is q21 graphWorkUnits = the counts of actual included types preceding CallSite in graph0 + independently derived CallSite prefix45297. This can explain work differences under the immutable-map/per-node accounting contract, not assign all latency differences to traversal or prove CPU/scheduler causality. Original terminated helper forks did not record their map order; the new samples cannot retroactively supply it.

The full oracle, original input pins, all commands and real process-group drains remain required. No JVM overlap, new warmup, JFR/native profiler or query-only replay is added. Three samples per query/version/reset are not query P95. This adapter does not measure CPU/RSS; the added adapter method/constant-pool references may change prior class loading or JIT even though its call is after all queries, and post-query inspection may perturb teardown/whole-process duration. This is mechanism evidence, not acceptance evidence for the10x goal.

Run: python3 run-complete38.py (fresh output required). Independent audit: [independent-diagnostic-audit/README.md](independent-diagnostic-audit/README.md). Final results: [RESULTS.md](RESULTS.md).
