"""Independent current q21 first-graph CallSite prefix derivation; no JVM or production changes."""
from pathlib import Path
import json,gzip,csv,base64,hashlib,struct
O=Path(__file__).resolve().parent;P=Path('/private/tmp/graphite-independent-drain-v2.6csfc8du/complete38-oracle');H=Path('/var/folders/sy/_tdkyl2x0gx6z5kl2wbhd9tc0000gn/T/graphite-view-cancel-helper.ptfakahe');pins={}
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def read(p):pins[str(p)]=sha(p);return json.loads(p.read_text())
def canonical(x):return json.dumps(x,ensure_ascii=False,separators=(',',':'))
r=read(P/'run.json');e=read(P/'export-receipt.json');control=read(P/'trusted-control-reference-check.json');cat=read(P/'oracle/catalog.json');proc=read(P/'export-process.json')
assert r['status']=='complete' and r['oracleReady'] and r['trustedControlVerified'] and r['inputsUnchanged']
assert proc['exitCode']==0 and proc['cleanup']['drained'] and not proc['cleanup']['membersAfterCleanup'];assert e['passed'] and e['kind']=='ordered-callsite-tuples'
assert e['jarSha256']==cat['jarSha256']=='a5c2db2b0020798488916ec86902459d1044a7dcef606a73e00055883cdf5abe'
assert control['passed'] and control['queryCount']==38 and control['verifiedFullRowsAndProvenance']
source=P.parent/'complete38-protocol/ExportCallSites.java';pins[str(source)]=sha(source);assert r['inputHashesBefore'][str(source)]==r['inputHashesAfter'][str(source)]==pins[str(source)]
blob=P/'callsites.tsv.gz';pins[str(blob)]=sha(blob);assert pins[str(blob)]==e['outputSha256']==cat['exportSha256'];assert blob.stat().st_size==e['outputBytes']==cat['exportCompressedBytes']
manifest=Path(cat['manifest']);pins[str(manifest)]=sha(manifest);assert pins[str(manifest)]==e['manifestSha256']==cat['manifestSha256']
rows=[x.split('\t') for x in manifest.read_text().splitlines() if x and not x.startswith('#')];assert len(rows)==64 and rows[0][0]==e['graphIds'][0]=='fixture-android-00'
before=read(P/'graph-input-before.json');assert before==read(P/'graph-input-after.json')==read(H/'complete38-pairs/graph-input-before.json')==read(H/'complete38-pairs/graph-input-after.json')
q=cat['queries'][20];logic=next(x for x in cat['logicalCases'] if x['id']==q['logicalId']);assert q['id']=='mixed-four-few-rows' and not q['distinct'];assert logic['ast']==['or',['and',0,1],['and',2,3]]
terms=logic['terms'];assert len(terms)==4 and all(t and t.isascii() and t==t.lower() for t in terms)
props=['caller_class','caller_name','callee_class','callee_name'];parts=['('+' OR '.join("toLower(coalesce(n."+p+", '')) CONTAINS '"+t.replace("'","\\'")+"'" for p in props)+')' for t in terms]
expected='MATCH (n) WHERE (('+parts[0]+' AND '+parts[1]+') OR ('+parts[2]+' AND '+parts[3]+')) RETURN '+', '.join('n.'+p for p in props)+' LIMIT 200';assert expected==q['query']
workloads=P/'oracle/workloads.tsv';pins[str(workloads)]=sha(workloads);wr=list(csv.DictReader(workloads.open(),delimiter='\t'));assert len(wr)==38 and wr[20]['id']==q['id'];assert base64.b64decode(wr[20]['queryBase64']).decode()==expected
index=Path(rows[0][1])/'graph.typeindex';fileProof=next(x for x in before[0]['files'] if x['path']=='graph.typeindex');pins[str(index)]=sha(index);assert pins[str(index)]==fileProof['sha256'] and index.stat().st_size==fileProof['size']
with index.open('rb') as f:
 header=f.read(8);magic,n=struct.unpack('>II',header);assert magic & 0xffffff00==0x47525400 and 0<(magic&255)<=3 and n==16
 body=f.read(n*13);ranges={}
 for i in range(n):
  tag,count,offset=struct.unpack_from('>Biq',body,i*13);assert tag not in ranges and count>=0 and offset>=8+n*13;ranges[tag]=(count,offset)
 callCount,callOffset=ranges[12];assert callCount==e['perGraphNodeCounts'][0]==cat['perGraphCallSiteCounts'][0]
 f.seek(callOffset);ids=f.read(callCount*4);assert len(ids)==callCount*4
 idList=struct.unpack('>'+str(callCount)+'i',ids);assert len(set(idList))==callCount and all(x>=0 for x in idList)
selected=[];ordinals=[];firstGraphCount=0;totalMatches=0;matchMasks=[];asciiOnly=True
with gzip.open(blob,'rt',encoding='utf-8',newline='') as f:
 for line in f:
  cells=line.rstrip('\n').split('\t');assert len(cells)==5
  gi=int(cells[0])
  if gi!=0:
   assert gi==1;break
  vals=cells[1:];assert all('\r' not in x for x in vals);firstGraphCount+=1
  asciiOnly=asciiOnly and all(v.isascii() for v in vals)
  low=[v.lower() for v in vals];bits=[any(t in v for v in low) for t in terms]
  hit=(bits[0] and bits[1]) or (bits[2] and bits[3])
  if hit:
   totalMatches+=1
   if len(selected)<200:
    selected.append({'values':vals,'graphIds':['fixture-android-00']});ordinals.append(firstGraphCount);matchMasks.append(bits)
assert asciiOnly,'Non-ASCII strings require a separate case-mapping proof; do not silently assume Python/Java equivalence'
assert firstGraphCount==callCount and len(selected)==200;assert totalMatches==logic['perGraphMatchingCounts'][0]
assert selected==q['expectedRows'];digest=hashlib.sha256(canonical(selected).encode()).hexdigest()
controlRow=next(x for x in csv.DictReader((P/'trusted-control.tsv').open(),delimiter='\t') if x['id']==q['id']);assert controlRow['digest']==digest and int(controlRow['rowCount'])==200
pins[str(P/'trusted-control.tsv')]=sha(P/'trusted-control.tsv');rawrow=next(json.loads(x) for x in (P/'trusted-control-rows.jsonl').read_text().splitlines() if json.loads(x)['id']==q['id']);assert rawrow['rows']==selected;pins[str(P/'trusted-control-rows.jsonl')]=sha(P/'trusted-control-rows.jsonl')
result={'status':'passed','queryId':q['id'],'ordinal':21,'querySha256':hashlib.sha256(expected.encode()).hexdigest(),'terms':terms,'ast':logic['ast'],'firstGraph':'fixture-android-00','firstGraphCallSiteCount':firstGraphCount,'firstGraphTotalMatchingCallSites':totalMatches,'oneBased200thMatchingCallSiteOrdinal':ordinals[-1],'zeroBased200thMatchingCallSiteIndex':ordinals[-1]-1,'200thMatchingNodeId':idList[ordinals[-1]-1],'firstMatchingCallSiteOrdinal':ordinals[0],'matchedCallSiteOrdinals':ordinals,'matchedNodeIds':[idList[x-1] for x in ordinals],'matchingBooleanMasks':matchMasks,'allFirstGraphFieldsAscii':asciiOnly,'full200ValuesOrderProvenanceExact':True,'trustedControl200RowsExact':True,'resultDigest':digest,'callSiteTypeindexTag':12,'typeindexRangeCount':callCount,'typeindexRangeOffset':callOffset,'typeindexCallSiteIdsSHA256':hashlib.sha256(ids).hexdigest(),'usedPrior45297AsInput':False,'scope':['Export tuple order is bound to frozen-main GraphStore.loadMapped -> nodes(CallSiteNode) exporter source and receipts; no node data deserialization was rerun.','Typeindex content hash and complete CallSite ID range are independently read. Mapping export ordinals to these IDs relies on the verified exporter/source order contract; TSV does not contain node IDs.','This proves the within-CallSite scan prefix on current authenticated export, not any completed JVM\'s preceding type order or elapsed-time cause.','Current generic query total work should add actual included non-CallSite prefix counts only after observing the same fork\'s type order; unavailable orders remain unknown.','Full export compressed hash is checked; only android-00 tuples are decompressed and independently evaluated. Other graph tuples are bound by existing trusted export/oracle receipts.'],'inputHashes':pins}
(O/'result.json').write_text(json.dumps(result,indent=2)+'\n');print('PASS: current independently-derived 200th match ordinal',ordinals[-1],'; first graph CallSites',firstGraphCount,'matches',totalMatches,'; all200 values/order/provenance exact')
