from pathlib import Path
import json,csv,hashlib
D=Path(__file__).resolve().parent
r=json.loads((D/'complete38-pairs/run.json').read_text());assert r['status']=='complete' and len(r['completed'])==12
T=json.loads((D/'independent-diagnostic-audit/type-audit.json').read_text());A=json.loads((D/'independent-diagnostic-audit/full38-audit.json').read_text())
assert T['validatedGraphTypeMaps']==768 and A['full456ValuesOrderProvenanceVerified'] and A['all228PairsRecomputed']
S=json.loads((D/'complete38-pairs/all38-pairs.json').read_text());obs={x['label']:x for x in T['observations']};pairs=[];flags={};diffs=[]
for mode,items in S['states'].items():
 flags[mode]=[q['id'] for q in items if q['repeatedDoubleBoundary']]
 for q in items:
  for p in q['pairs']:
   if p['allNonLatencyDifferences']:diffs.append({'mode':mode,'id':q['id'],'group':p['group'],'differences':p['allNonLatencyDifferences']})
 for g in (1,2,3):
  b,c=[obs[f'{mode}-group-{g}-{v}'] for v in ('base','candidate')]
  pairs.append({'mode':mode,'group':g,'baseMs':b['latencyNanos']/1e6,'candidateMs':c['latencyNanos']/1e6,'candidateOverBase':c['latencyNanos']/b['latencyNanos'],'baseWork':b['work'],'candidateWork':c['work'],'baseExtraTypeNodes':b['actualPreCallSiteCounts'],'candidateExtraTypeNodes':c['actualPreCallSiteCounts'],'workDirectionMatchesLatencyDirection':(c['work']>b['work'])==(c['latencyNanos']>b['latencyNanos']) if c['work']!=b['work'] else None})
result={'status':'complete-diagnostic-only','accepted':False,'original34AndStartingMainGateUnchanged':True,'typeWorkIdentityMatches':T['allWorkIdentitiesMatch'],'queryOutputs':456,'mapsVerified':768,'pairs':pairs,'allRepeatedFlags':flags,'allNonLatencyDifferences':diffs,'perQueryP95':None,'cpuAndRssMeasured':False}
(D/'numeric-summary.json').write_text(json.dumps(result,indent=2)+'\n')
lines=['# 完整38：混合查询的类型遍历工作量诊断','',f"**12个完整回放的工作量算式全部匹配：{T['allWorkIdentitiesMatch']}。候选仍未接受，10x未达成。**",'',
'官方PR04ae与取消helper177d保持不变；真实CI64、P4、maxheap8g、38条原查询/顺序、两种原reset、每种三对C/B–B/C–C/B。12 JVM实际退出、456完整值/顺序/来源、228配对、768类型映射独立验证。', '',
'当前q21 `(A AND B) OR (C AND D)` 走generic nodes(Node)过滤，其直接路径不调用被改helper。当前可信数据独立推导：第200个匹配CallSite在该类型内第45,297个位置，完整200行与可信main结果相同。', '',
'各fork的实际总扫描量 = 同一fork在CallSite之前的其他类型节点数 + 45,297。类型范围按Class键HashMap的实际顺序遍历。顺序在index加载后不再修改，因此查询全部输出后的只读快照可绑定该fork的遍历；这不是对旧已退出fork顺序的重建。', '',
'| reset | pair | 基线→候选 ms | 基线→候选扫描节点 | 其中前置其他类型节点 B→C |','|---|---:|---:|---:|---:|']
for p in pairs:lines.append(f"| {p['mode']} | {p['group']} | {p['baseMs']:.3f} → {p['candidateMs']:.3f} | {p['baseWork']} → {p['candidateWork']} | {p['baseExtraTypeNodes']} → {p['candidateExtraTypeNodes']} |")
lines+=['','记录全部原诊断回退标记：']
for mode,ids in flags.items():lines.append(f"- {mode}: "+(', '.join(ids) or '无重复15%且1ms标记'))
lines+=['',f'所有非时间字段差异保留在 numeric-summary.json，共{len(diffs)}个查询配对记录。每查询/版本/reset只有3点，不称P95；此adapter不测CPU/RSS。', '',
'适用范围：实际类型顺序精确解释此批q21的扫描量差异，不能由此把全部耗时变化归因于它，不能宣称helper无开销，也不能豁免原full38回退、原34相对起点main失败或CI。新诊断修改了adapter，不是优化验收批次；即使调用在最后，新增方法及常量池引用仍可能影响前序类加载/JIT，不能声称timed查询零扰动。后置检查还可影响teardown/整进程时间。', '',
'编译审计：重新编译的原adapter class与冻结实际class逐字节相同；逆向删除单次后置调用后9个原方法符号指令/异常区间相同，只有1个inspection方法新增。首次stream lambda导致scope失败的完整准备已保留，修订为for循环后通过。符号比较排除debug/frames/metadata，不推导JIT等价。', '',
'与Attempt140的区别：旧40次只做孤立q21，未保留完整前序；这里执行了完整38，并从当前可信CallSite导出独立计算前缀。旧当前fixture有226个文件字节不同，64typeindex相同；不把旧45297残差当输入。', '',
'下一步：结束此类型顺序观察器。保留取消helper为未接受候选，处理原34第5条相对起点main的重复回退，先区分官方PR既有成本和helper新增成本；不叠加混合OR或类型排序优化。全原34最终10x、maxheap8g、NCPU上限及取消实际退出要求不变，未新增production commit/push/CI/merge。', '',
'原始路径、精确命令和JAR/fixture/oracle身份见complete38-pairs/run.json；type-audit.json验证实际768映射，current-prefix/保留独立推导。归档不包含外部原始JAR及9.7GB图，需要原路径对应内容才能重跑。']
(D/'RESULTS.md').write_text('\n'.join(lines)+'\n')
print(json.dumps(result,indent=2))
