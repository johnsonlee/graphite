from pathlib import Path
import importlib.util,json,os,time,traceback,xml.etree.ElementTree as ET
H=Path(__file__).resolve().parent
helper=Path('/private/tmp/graphite-root-admission-probe.15TXkwF5/run.py')
spec=importlib.util.spec_from_file_location('owned',helper);o=importlib.util.module_from_spec(spec);spec.loader.exec_module(o)
prep=json.loads((H/'preparation.json').read_text())
assert not (H/'build-receipt.json').exists()
for p,h in prep['sourceHashes'].items():assert o.sha(H/'repo'/p)==h
s={'status':'running','accepted':False,'pid':os.getpid(),'command':{},'sourceHashes':prep['sourceHashes'],'scope':'Local correctness/lint/module checks, not CI acceptance.'}
save=lambda:o.write(H/'build-receipt.json',s);save()
os.chdir(H/'repo');os.environ['JAVA_HOME']='/opt/homebrew/opt/openjdk@17/libexec/openjdk.jdk/Contents/Home'
cmd=['./gradlew','--no-daemon','--max-workers=2','-Dorg.gradle.jvmargs=-Xmx2g','-Pkotlin.compiler.execution.strategy=in-process',':core:check',':cypher:check',':webgraph:check',':explore:check',':webgraph:jmhJar']
s['command'].update(command=cmd,startedEpoch=time.time());save()
try:
 o.execute_owned(cmd,H/'checks.log',s['command'],save,1800)
 suites={}
 for mod in ['core','cypher','webgraph','explore']:
  files=list((H/f'repo/graphite-{mod}/build/test-results/test').glob('TEST-*.xml'));assert files
  counts={k:0 for k in ['tests','failures','errors','skipped']}
  for p in files:
   root=ET.parse(p).getroot()
   for k in counts:counts[k]+=int(root.attrib.get(k,0))
  assert counts['failures']==counts['errors']==counts['skipped']==0,counts
  suites[mod]=counts
 jar=H/'repo/graphite-webgraph/build/libs/webgraph-1.0.0-SNAPSHOT-jmh.jar'
 s.update(status='passed',suites=suites,candidateJarSha256=o.sha(jar),jar=str(jar))
except BaseException:
 s.update(status='failed',error=traceback.format_exc());raise
finally:
 s['allSourceInputsStillMatch']=all(o.sha(H/'repo'/p)==h for p,h in prep['sourceHashes'].items())
 if not s['allSourceInputsStillMatch']:s['status']='failed'
 save()
