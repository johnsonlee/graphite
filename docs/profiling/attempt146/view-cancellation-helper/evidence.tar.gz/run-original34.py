from pathlib import Path
import subprocess,json,csv,hashlib,time,traceback,os,signal,math,sys
H=Path(__file__).resolve().parent
MODE=sys.argv[1]
assert MODE in ['currentpr','startingmain']
JAVA='/opt/homebrew/opt/openjdk@17/libexec/openjdk.jdk/Contents/Home/bin/java'
REF=Path('/private/tmp/graphite-exact-property-union.rhc6p2g8/global34-triples/base-global-wide-1.tsv')
FIX=Path('/private/tmp/graphite-current34-jfr.fonqampc')
MANIFEST=FIX/'graphs.local.tsv';ORACLE=Path('/private/tmp/graphite-exact-property-union.rhc6p2g8/performance-plan/oracle.correctness')
BASE_PATHS={'startingmain':Path('/private/tmp/graphite-next-baseline.T2FTs9/graphite-webgraph/build/libs/webgraph-1.0.0-SNAPSHOT-jmh.jar'),'currentpr':Path('/private/tmp/graphite-pr116-conflicts.ghc4dddf/repo/graphite-webgraph/build/libs/webgraph-1.0.0-SNAPSHOT-jmh.jar')}
BASE_HASHES={'startingmain':'a5c2db2b0020798488916ec86902459d1044a7dcef606a73e00055883cdf5abe','currentpr':'04ae90ec1f5560aa54f491a747e651c2f7b44ff453e169c9f2e8bb9fa9570814'}
JARS={'base':BASE_PATHS[MODE],'candidate':H/'repo/graphite-webgraph/build/libs/webgraph-1.0.0-SNAPSHOT-jmh.jar'}
SIGNATURE='id family shape selectivity operator boundary projection targetGraphId workloadIdentity limit outcome rowCount responseBytes digest'.split()
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def write(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
def read(p):return json.loads(p.read_text())
def rows(p):return list(csv.DictReader(p.open(),delimiter='\t'))
def process_group_members(pgid):
 text=subprocess.check_output(['ps','-axo','pid=,pgid=,command='],text=True)
 result=[]
 for line in text.splitlines():
  parts=line.strip().split(None,2)
  if len(parts)>=2 and int(parts[1])==pgid:
   result.append({'pid':int(parts[0]),'pgid':int(parts[1]),'command':parts[2] if len(parts)>2 else ''})
 return result

def drain_owned_group(process):
 # Only the private session/process group created for this exact Popen is eligible.
 before=process_group_members(process.pid);sent=[]
 for sig in (signal.SIGTERM,signal.SIGKILL):
  if not process_group_members(process.pid):break
  try:os.killpg(process.pid,sig);sent.append(sig.name)
  except ProcessLookupError:break
  deadline=time.monotonic()+3
  while time.monotonic()<deadline:
   process.poll()  # Reap our direct child; do not leave its zombie in the group.
   if not process_group_members(process.pid):break
   time.sleep(0.05)
 after=process_group_members(process.pid)
 return {'membersBeforeCleanup':before,'signals':sent,'membersAfterCleanup':after,'drained':not after}

def graph_hashes():
 root=FIX/'restored-ci-fixture64'
 return {str(p.relative_to(root)):sha(p) for p in sorted(root.rglob('*')) if p.is_file()}

def validate_jmh(path):
 data=read(path);assert isinstance(data,list) and len(data)==1,'Expected exactly one JMH result'
 row=data[0]
 assert row['benchmark']=='io.johnsonlee.graphite.webgraph.LargeBroadQueryPressureBenchmark.replayBroadQueries'
 assert row['params']=={'graphCount':'64','coverageFamily':'global-wide','indexState':'cold','timeoutMillis':'300000'}
 assert row['mode']=='ss' and row['threads']==1 and row['forks']==1
 assert row['warmupIterations']==0 and row['measurementIterations']==1
 assert '-Xmx8g' in row['jvmArgs'] and '-XX:ActiveProcessorCount=4' in row['jvmArgs']
 assert math.isfinite(row['primaryMetric']['score']) and row['primaryMetric']['score']>0
 for key,expected in [('queryCount',34),('successCount',34),('failureCount',0),('timeoutCount',0)]:
  assert row['secondaryMetrics'][key]['score']==expected,(key,row['secondaryMetrics'][key]['score'])
 return {'validated':True,'benchmark':row['benchmark'],'params':row['params'],'queryCount':34}

def main():
 for key in ['JAVA_TOOL_OPTIONS','JDK_JAVA_OPTIONS','_JAVA_OPTIONS']:assert not os.environ.get(key),key
 build=read(H/'build-receipt.json');assert build['status']=='passed'
 scope=read(H/'class-scope.json');assert scope['status']=='passed' and scope['allOtherClassBytesIdentical']
 assert sha(JARS['candidate'])==scope['candidateSha256']
 assert build['allSourceInputsStillMatch']
 for name,digest in build['sourceHashes'].items():assert sha(H/'repo'/name)==digest,name
 assert sha(JARS['candidate'])==build['candidateJarSha256'];assert sha(JARS['base'])==BASE_HASHES[MODE]
 out=H/('original34-'+MODE+'-pairs');assert not out.exists();out.mkdir()
 ref=rows(REF);ids=[r['id'] for r in ref];assert len(ids)==len(set(ids))==34
 comparator=H/'repo/.github/scripts/benchmark-gate.mjs'
 assert sha(comparator)=='a4d09bf16e44deb05cab214db16bd9f922cf41430fb6028de1a3f8a9d71b3950'
 assert ['|'.join(r[k] for k in SIGNATURE) for r in ref]==ORACLE.read_text().splitlines()
 pins=list(JARS.values())+[REF,MANIFEST,ORACLE,comparator,H/'run-original34.py',H/'build-receipt.json',H/'preparation.json',H/'class-scope.json',H/'verify-class-scope.py',H/'SymbolicClassCompare.java',H/'symbolic-methods.tsv',H/'class-scope.log',H/'symbolic-methods.tsv-base.txt',H/'symbolic-methods.tsv-candidate.txt',H/'candidate.patch',*[H/'repo'/name for name in build['sourceHashes']]]
 before={str(p):sha(p) for p in pins};state={'status':'running','pid':os.getpid(),'accepted':False,'comparisonBase':MODE,'comparisonBaseSha':('4e328b0109e13c896b74004823fb049fcb19251a' if MODE=='startingmain' else '5e05242a8f1a9cc3ae07959d387af77adabf4705'),'candidate':'Official PR5e052 plus context cancellation check in existing mapped-view interruption helper; no scanner or scheduler change','finalTargetReference':'4e328b0109e13c896b74004823fb049fcb19251a','note':'Same frozen original34 JMH and gc profiler/resource sampler; no added observer. Baseline selected by explicit currentpr/startingmain argument; final target remains frozen starting main4e328b01. Source/JAR/fixture pins, full14 oracle and process-group exits checked. This local single-variable ablation is not CI acceptance. Full replay processCPU includes between-query canonical/verification work. External JVM inventory retained.','inputHashesBefore':before,'completed':[],'commands':[]};write(out/'run.json',state)
 try:
  gb=graph_hashes();write(out/'graph-input-before.json',gb)
  assert gb==read(FIX/'fixture-input-before.json'),'Restored graph inputs differ before measurement'
  state['graphInputsVerifiedBefore']=True;write(out/'run.json',state)
  for i in range(1,4):
   for side in (['candidate','base'] if i%2 else ['base','candidate']):
    label=f'{side}-global-wide-{i}';prefix=out/label
    assert all(sha(Path(p))==h for p,h in before.items())
    args=f'-Xmx8g -XX:ActiveProcessorCount=4 -Dgraphite.broad.pressure.graphs={MANIFEST} -Dgraphite.broad.pressure.correctness.mode=verify -Dgraphite.broad.pressure.correctness.oracle={ORACLE} -Dgraphite.broad.pressure.observations.output={prefix}.tsv'
    cmd=[JAVA,'-Xmx256m','-jar',str(JARS[side]),'io.johnsonlee.graphite.webgraph.LargeBroadQueryPressureBenchmark.replayBroadQueries','-p','graphCount=64','-p','coverageFamily=global-wide','-p','indexState=cold','-p','timeoutMillis=300000','-wi','0','-i','1','-f','1','-to','30m','-foe','true','-prof','gc','-rf','json','-rff',str(prefix)+'.json','-jvmArgs',args]
    command={'id':label,'command':cmd,'beforeProcesses':subprocess.check_output(['ps','-axo','pid,ppid,etime,command'],text=True),'startedEpoch':time.time()};state['commands'].append(command);write(out/'run.json',state);print('START',label,flush=True)
    with Path(str(prefix)+'.log').open('w') as log:
     p=subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);command['pid']=p.pid;command['pgid']=p.pid;write(out/'run.json',state)
     try:
      code=p.wait(timeout=2100)
     except BaseException:
      command['waitError']=traceback.format_exc()
      raise
     finally:
      try:command['processGroupCleanup']=drain_owned_group(p)
      except BaseException:command['processGroupCleanup']={'drained':False,'error':traceback.format_exc()}
      command['exitCode']=p.poll();command['finishedEpoch']=time.time();write(out/'run.json',state)
     assert command['processGroupCleanup']['drained'],'Owned benchmark process group did not drain'
     assert not command['processGroupCleanup']['membersBeforeCleanup'],'Benchmark left live descendants after exit'
    command.update(exitCode=code,finishedEpoch=time.time());write(out/'run.json',state);assert code==0,(label,code)
    command['jmhValidation']=validate_jmh(Path(str(prefix)+'.json'));write(out/'run.json',state)
    rs=rows(Path(str(prefix)+'.tsv'));assert [r['id'] for r in rs]==ids
    diff=[]
    for a,b in zip(rs,ref):
     assert set(a)==set(b)
     assert [a[k] for k in SIGNATURE]==[b[k] for k in SIGNATURE],a['id']
     ds={k:[b[k],a[k]] for k in a if k!='latencyNanos' and a[k]!=b[k]}
     if ds:diff.append({'id':a['id'],'differences':ds})
    write(Path(str(prefix)+'-oracle-check.json'),{'full14FieldsPassed':True,'queryCount':34,'nonTimeDifferences':diff})
    state['completed'].append(label);write(out/'run.json',state);print('DONE',label,flush=True)
  node=subprocess.check_output(['which','node'],text=True).strip()
  cmd=[node,str(comparator),'compare-global-wide-pressure']
  for opt,side,ext in [('bases','base','json'),('candidates','candidate','json'),('base-observations','base','tsv'),('candidate-observations','candidate','tsv')]:cmd+=['--'+opt,','.join(str(out/f'{side}-global-wide-{i}.{ext}') for i in range(1,4))]
  cmd+=['--run-orders','candidate-base,base-candidate,candidate-base','--graph-manifest',str(MANIFEST),'--correctness-oracle',str(ORACLE),'--minimum-speedup','10','--regression-only','--report',str(out/'global-wide-report.md'),'--status',str(out/'global-wide-status.json')]
  write(out/'comparator-command.json',cmd)
  with (out/'comparator.log').open('w') as log:code=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=60).returncode
  assert code in [0,1];assert (out/'global-wide-status.json').is_file()
  state.update(status='complete',verifiedQueryOutputs=204,comparatorExitCode=code,comparison=read(out/'global-wide-status.json'))
 except BaseException:state.update(status='failed',error=traceback.format_exc());raise
 finally:
  original_failed=state['status']=='failed'
  try:
   assert all(c.get('processGroupCleanup',{}).get('drained',False) for c in state['commands'] if 'pid' in c),'Skip integrity hashing while an owned process may remain live'
   after={str(p):sha(p) for p in pins};state.update(inputHashesAfter=after,inputsUnchanged=before==after)
   ga=graph_hashes();write(out/'graph-input-after.json',ga)
   state['graphInputsUnchanged']=ga==read(FIX/'fixture-input-before.json') and ('gb' not in locals() or gb==ga)
   assert state['inputsUnchanged'] and state['graphInputsUnchanged'],'Pinned inputs changed during diagnosis'
  except BaseException:
   state.update(status='failed',integrityError=traceback.format_exc())
   if not original_failed:raise
  finally:
   state['finishedEpoch']=time.time();write(out/'run.json',state)
if __name__=='__main__':main()
