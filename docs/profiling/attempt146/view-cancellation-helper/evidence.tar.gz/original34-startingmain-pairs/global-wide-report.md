### 64 fixture-derived global wide-query pressure gate

Evaluation: **non-regression**
P95 target in every independent paired fork: **10.0x**
Regression checks: **FAIL**; target achieved: **NO**
Target remains unmet; a passing regression evaluation does not establish the speedup target.
pair-1: P95 speedup 2.46x; required 10.00x in every independent fork
pair-1: global-wide-wrapped-case-insensitive P95 speedup 0.91x; required 10.00x
pair-1: global-wide-wrapped-case-insensitive-distinct P95 speedup 2.46x; required 10.00x
pair-2: P95 speedup 0.94x; required 10.00x in every independent fork
pair-2: global-wide-wrapped-case-insensitive P95 speedup 1.00x; required 10.00x
pair-2: global-wide-wrapped-case-insensitive-distinct P95 speedup 0.94x; required 10.00x
pair-3: P95 speedup 1.21x; required 10.00x in every independent fork
pair-3: global-wide-wrapped-case-insensitive P95 speedup 0.94x; required 10.00x
pair-3: global-wide-wrapped-case-insensitive-distinct P95 speedup 1.21x; required 10.00x

- Worst paired base P50 / P95: **1.951 ms / 41.688 ms**
- Worst paired candidate P50 / P95: **2.233 ms / 44.348 ms**
- Worst individual P95 speedup (retained for audit): **0.94x**
- Worst wrapped case-insensitive P95 speedup: **0.91x**
- Worst order-median P95 speedup: **0.94x**
- candidate-base: **2 pair(s), 0.76x P50 / 1.83x P95**
- base-candidate: **1 pair(s), 0.87x P50 / 0.94x P95**

| Pair | Order | Base P50 | Base P95 | Candidate P50 | Candidate P95 | P50 speedup | P95 speedup | CPU total | CPU cores | Heap | RSS |
| ---: | :--- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 1 | candidate-base | 1.869 ms | 105.942 ms | 2.410 ms | 43.120 ms | 0.78x | 2.46x | 1790.205 ms → 1690.624 ms | 3.17 | 4.03 GiB → 4.39 GiB | 4.66 GiB → 4.91 GiB |
| 2 | base-candidate | 1.951 ms | 41.688 ms | 2.233 ms | 44.348 ms | 0.87x | 0.94x | 1461.106 ms → 1639.901 ms | 3.17 | 4.04 GiB → 4.38 GiB | 4.66 GiB → 4.91 GiB |
| 3 | candidate-base | 1.750 ms | 47.837 ms | 2.331 ms | 39.451 ms | 0.75x | 1.21x | 1559.989 ms → 1603.209 ms | 3.29 | 4.38 GiB → 4.01 GiB | 4.89 GiB → 4.51 GiB |

**Result: FAIL**

pair-2/global-wide-class-pair/targeted: aligned latency 5527417 exceeds base 4263542 by >15% and >1 ms; repeated in 2 independent pairs
