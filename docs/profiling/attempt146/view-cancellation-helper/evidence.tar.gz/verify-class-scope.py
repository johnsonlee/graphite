from pathlib import Path
import importlib.util,json,time,zipfile
H=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('owned','/private/tmp/graphite-root-admission-probe.15TXkwF5/run.py');o=importlib.util.module_from_spec(spec);spec.loader.exec_module(o)
b=Path('/private/tmp/graphite-pr116-conflicts.ghc4dddf/repo/graphite-webgraph/build/libs/webgraph-1.0.0-SNAPSHOT-jmh.jar');c=H/'repo/graphite-webgraph/build/libs/webgraph-1.0.0-SNAPSHOT-jmh.jar'
s={'status':'running','commands':[],'initialScopeAssertion':'Helper refinement of rejected direct serial guard. Only the existing interruption helper may change symbolic instructions; query loops and scheduler remain untouched.'};save=lambda:o.write(H/'class-scope.json',s)
cmd=[o.JAVA,'-Xmx512m','-XX:ActiveProcessorCount=4','--add-exports','java.base/jdk.internal.org.objectweb.asm=ALL-UNNAMED','--add-exports','java.base/jdk.internal.org.objectweb.asm.tree=ALL-UNNAMED',str(H/'SymbolicClassCompare.java'),str(b),str(c),str(H/'symbolic-methods.tsv')]
r={'command':cmd,'startedEpoch':time.time()};s['commands'].append(r);save();o.execute_owned(cmd,H/'class-scope.log',r,save,180)
with zipfile.ZipFile(b) as bz,zipfile.ZipFile(c) as cz:
 bn={n for n in bz.namelist() if n.endswith('.class')};cn={n for n in cz.namelist() if n.endswith('.class')};assert bn==cn
 changed=sorted(n for n in bn if bz.read(n)!=cz.read(n))
 assert changed and all(n.startswith('io/johnsonlee/graphite/webgraph/') for n in changed)
 s.update(status='passed',baseSha256=o.sha(b),candidateSha256=o.sha(c),comparedClasses=len(bn),byteChangedClasses=changed,allOtherClassBytesIdentical=True,symbolicChangedMethod='MappedCallSiteStringIndexViewKt.checkViewInterrupted',scope='Executable instruction and exception-handler comparison ignores debug lines and frames; does not establish JIT or performance equality.')
save();print((H/'class-scope.log').read_text())
