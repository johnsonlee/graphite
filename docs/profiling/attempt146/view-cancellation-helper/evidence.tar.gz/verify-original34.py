from pathlib import Path
import json, csv, math, hashlib, zipfile, collections
H = Path(__file__).resolve().parent
def read(p): return json.loads(p.read_text())
def rows(p): return list(csv.DictReader(p.open(), delimiter='\t'))
def sha(p):
    with p.open('rb') as f: return hashlib.file_digest(f, 'sha256').hexdigest()
build = read(H / 'build-receipt.json')
assert build['status'] == 'passed' and build['allSourceInputsStillMatch']
assert all(sha(H / 'repo' / p) == h for p, h in build['sourceHashes'].items())
jar = H / 'repo/graphite-webgraph/build/libs/webgraph-1.0.0-SNAPSHOT-jmh.jar'
assert sha(jar) == build['candidateJarSha256']
baselineJar = Path('/private/tmp/graphite-pr116-conflicts.ghc4dddf/repo/graphite-webgraph/build/libs/webgraph-1.0.0-SNAPSHOT-jmh.jar')
with zipfile.ZipFile(jar) as c, zipfile.ZipFile(baselineJar) as b:
    classes = [n for n in b.namelist() if n.startswith('io/johnsonlee/graphite/graph/GraphTask') and n.endswith('.class')]
    assert len(classes) == 8 and all(c.read(n) == b.read(n) for n in classes)
sig = 'id family shape selectivity operator boundary projection targetGraphId workloadIdentity limit outcome rowCount responseBytes digest'.split()
ref = rows(Path('/private/tmp/graphite-exact-property-union.rhc6p2g8/global34-triples/base-global-wide-1.tsv'))
out = {'accepted': False, 'finalGoalAchieved': False, 'schedulerClassBytesUnchanged': classes, 'comparisons': {}}
for mode in ['currentpr', 'startingmain']:
    d = H / f'original34-{mode}-pairs'
    state, gate = read(d / 'run.json'), read(d / 'global-wide-status.json')
    assert state['status'] == 'complete' and state['inputsUnchanged'] and state['graphInputsUnchanged']
    assert all(c['exitCode'] == 0 and c['processGroupCleanup']['drained']
               and not c['processGroupCleanup']['membersBeforeCleanup'] for c in state['commands'])
    counts, pairs, nonlat = collections.Counter(), [], []
    for rnd in range(1, 4):
        pair, results = {}, {}
        for side in ['base', 'candidate']:
            rs, j = rows(d / f'{side}-global-wide-{rnd}.tsv'), read(d / f'{side}-global-wide-{rnd}.json')[0]
            assert [{k: r[k] for k in sig} for r in rs] == [{k: r[k] for k in sig} for r in ref]
            assert '-Xmx8g' in j['jvmArgs'] and '-XX:ActiveProcessorCount=4' in j['jvmArgs']
            assert not any(a.startswith('-Dgraphite.cypher.directStringParallelism=') for a in j['jvmArgs'])
            assert not any('FlightRecorder' in a or 'StartFlightRecording' in a or 'graphite.diagnostic.' in a for a in j['jvmArgs'])
            metric = lambda k: j['secondaryMetrics'][k]['score']
            p95 = sorted(int(r['latencyNanos']) for r in rs)[math.ceil(.95 * len(rs)) - 1]
            assert p95 == metric('p95LatencyNanos')
            assert metric('processCpuNanos') > 0 and metric('maxHeapBytes') <= 8 * 1024**3
            assert metric('availableProcessors') == 4
            pair[side] = {'p95Ms': p95 / 1e6, 'processCpuMs': metric('processCpuNanos') / 1e6,
                          'sampledHeapGiB': metric('peakUsedHeapBytes') / 1024**3,
                          'sampledRssGiB': metric('peakResidentSetBytes') / 1024**3}
            results[side] = rs
        b, c = pair['base'], pair['candidate']
        speed = b['p95Ms'] / c['p95Ms']
        assert abs(speed - gate['runs'][rnd - 1]['p95Speedup']) < 1e-12
        qs = []
        for br, cr in zip(results['base'], results['candidate']):
            bn, cn = int(br['latencyNanos']), int(cr['latencyNanos'])
            flag = cn > bn * 1.15 and cn - bn > 1e6
            if flag: counts[br['id']] += 1
            ds = {k: [br[k], cr[k]] for k in br if k != 'latencyNanos' and br[k] != cr[k]}
            if ds: nonlat.append({'pair': rnd, 'id': br['id'], 'differences': ds})
            qs.append({'id': br['id'], 'baseMs': bn / 1e6, 'candidateMs': cn / 1e6, 'speedup': bn / cn,
                       'diagnosticRegressionFlag': flag})
        pairs.append({'pair': rnd, **pair, 'p95Speedup': speed,
                      'fullReplayCpuPercent': (c['processCpuMs'] / b['processCpuMs'] - 1) * 100,
                      'q29': qs[28], 'q30': qs[29], 'queries': qs})
    out['comparisons'][mode] = {'verifiedOutputs': 204, 'pairs': pairs,
                               'repeatedDiagnosticRegressions': {k: n for k, n in counts.items() if n >= 2},
                               'nonLatencyPairDifferences': nonlat, 'regressionPassed': gate['regressionPassed'],
                               'targetAchieved': gate['targetAchieved']}
out['startingMainOriginal34TargetPassed'] = (out['comparisons']['startingmain']['targetAchieved'] and
                                           out['comparisons']['startingmain']['regressionPassed'])
(H / 'original34-verification.json').write_text(json.dumps(out, indent=2) + '\n')
for name, c in out['comparisons'].items():
    print(name, 'p95', [round(p['p95Speedup'], 3) for p in c['pairs']],
          'CPU%', [round(p['fullReplayCpuPercent'], 2) for p in c['pairs']],
          'q29', [round(p['q29']['speedup'], 3) for p in c['pairs']],
          'repeated', c['repeatedDiagnosticRegressions'], 'nonlatPairs', len(c['nonLatencyPairDifferences']))
