"""Paired full38 PR/serial-cancellation-guard diagnostic using the unchanged independently bound oracle."""
from pathlib import Path
import importlib.util, json, time, traceback, os
H = Path(__file__).resolve().parent
PROTOCOL = Path('/private/tmp/graphite-independent-drain-v2.6csfc8du/run-complete38.py')
spec = importlib.util.spec_from_file_location('frozen38', PROTOCOL)
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)

def main():
    out = H / 'complete38-pairs'
    out.mkdir()
    receipt = out / 'run.json'
    state = {'status': 'running', 'accepted': False, 'pid': os.getpid(), 'commands': [], 'completed': [],
             'comparisonBase': 'Official PR5e05242a, SHA04ae90ec',
             'candidate': 'Official PR5e05242a plus task cancellation check in mapped-view interruption helper',
             'finalTargetReference': 'Frozen main4e328b01; this is not a main comparison or CI acceptance.',
             'order': m.ORDER, 'states': m.STATES, 'resetMeaning': m.RESET_MEANING,
             'samplesPerQueryPerVersionPerState': 3, 'perQueryP95': None, 'cpuAndRssMeasured': False,
             'notes': ['Frozen oracle is reused byte-for-byte; same original38 workload and same authenticated CI64 files.',
                       'Only selected executable JAR bindings change in this imported protocol instance; no frozen file changes.',
                       'No additional warmup/JFR/queue observation. Each replay uses a fresh P4/8g JVM.',
                       'Full values/order/provenance verified by original full38 verifier. Retain all work/coverage differences.',
                       'External JVM inventory retained; local diagnostic flags are not new CI gates.']}
    m.write(receipt, state)
    hashes, before = {}, None
    try:
        # Verify the original frozen protocol and its prepared-oracle provenance before selecting this experiment's JARs.
        hashes = m.pinned_inputs()
        build = m.read(H / 'build-receipt.json')
        scope = m.read(H / 'class-scope.json')
        m.require(scope['status'] == 'passed' and scope['allOtherClassBytesIdentical'], 'Scope verification must pass')
        m.require(build['status'] == 'passed' and build['allSourceInputsStillMatch'], 'Candidate checks must pass')
        jar = H / 'repo/graphite-webgraph/build/libs/webgraph-1.0.0-SNAPSHOT-jmh.jar'
        m.require(m.sha(jar) == build['candidateJarSha256'], 'Frozen candidate changed')
        m.require(build['candidateJarSha256'] == scope['candidateSha256'] and scope['baseSha256'] == '04ae90ec1f5560aa54f491a747e651c2f7b44ff453e169c9f2e8bb9fa9570814', 'Scope proof JAR binding differs')
        for p, want in build['sourceHashes'].items(): m.require(m.sha(H / 'repo' / p) == want, 'Checked source changed')
        baseline = m.JARS['base']
        m.require(m.sha(baseline) == '04ae90ec1f5560aa54f491a747e651c2f7b44ff453e169c9f2e8bb9fa9570814', 'Official PR baseline changed')
        m.JARS = {'base': baseline, 'candidate': jar}
        hashes.update(m.identities([Path(__file__), PROTOCOL, H / 'build-receipt.json', H / 'preparation.json',
                                   H / 'class-scope.json', H / 'verify-class-scope.py', H / 'SymbolicClassCompare.java', H / 'symbolic-methods.tsv', H / 'class-scope.log', H / 'symbolic-methods.tsv-base.txt', H / 'symbolic-methods.tsv-candidate.txt', H / 'candidate.patch',
                                   jar, *[H / 'repo' / p for p in build['sourceHashes']]]))
        state['selectedJars'] = {k: {'path': str(p), 'sha256': m.sha(p)} for k, p in m.JARS.items()}
        state['inputHashesBefore'] = hashes.copy()
        before = m.restored_identity()
        m.write(out / 'graph-input-before.json', before)
        m.write(receipt, state)
        m.paired(out, state, receipt, hashes, before)
    except BaseException:
        state.update(status='failed', error=traceback.format_exc())
        raise
    finally:
        try:
            m.require(all(c.get('cleanup', {}).get('drained') for c in state['commands'] if 'pid' in c), 'Private group still live')
            m.unchanged(hashes)
            if before is not None:
                after = m.restored_identity()
                m.write(out / 'graph-input-after.json', after)
                m.require(before == after, 'Fixture changed')
                state.update(inputsUnchanged=True, inputHashesAfter=m.identities(hashes), graphInputsUnchanged=True)
        except BaseException:
            state.update(status='failed', integrityError=traceback.format_exc())
            raise
        finally:
            state['finishedEpoch'] = time.time()
            m.write(receipt, state)

if __name__ == '__main__': main()
