from pathlib import Path
import collections,hashlib,json,subprocess,xml.etree.ElementTree as ET
H=Path(__file__).resolve().parents[1];R=H/'repo';O=H/'independent-review'
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
b=read(H/'build-receipt.json');prep=read(H/'preparation.json');assert b['status']=='passed' and b['allSourceInputsStillMatch'] and b['sourceHashes']==prep['sourceHashes']
for p,v in b['sourceHashes'].items():assert sha(R/p)==v
cmd=b['command'];assert cmd['exitCode']==0 and cmd['pid']==cmd['pgid'];assert cmd['processGroupCleanup']=={'membersBeforeCleanup':[],'signals':[],'membersAfterCleanup':[],'drained':True}
ps=subprocess.check_output(['ps','-axo','pid=,pgid='],text=True);members=[l for l in ps.splitlines()if len(l.split())==2 and int(l.split()[1])==cmd['pgid']];assert not members
log=(H/'checks.log').read_text();assert 'BUILD SUCCESSFUL' in log
regular={};extra={};hashes={};caseNames={}
for mod in ['core','cypher','webgraph','explore']:
 for directory in (R/f'graphite-{mod}/build/test-results').iterdir():
  files=sorted(directory.glob('TEST-*.xml')) if directory.is_dir() else []
  if not files:continue
  counts=collections.Counter();actual=collections.Counter()
  for p in files:
   root=ET.parse(p).getroot();counts.update({k:int(root.get(k,0))for k in ['tests','failures','errors','skipped']});cases=root.findall('testcase');actual['tests']+=len(cases)
   for typ in ['failure','error','skipped']:actual[{'failure':'failures','error':'errors','skipped':'skipped'}[typ]]+=sum(c.find(typ)is not None for c in cases)
   hashes[str(p)]=sha(p);caseNames[root.get('name')]=[c.get('name')for c in cases]
  assert all(counts[k]==actual[k]for k in ['tests','failures','errors','skipped']);assert counts['failures']==counts['errors']==counts['skipped']==0
  if directory.name=='test':regular[mod]=dict(counts);assert regular[mod]==b['suites'][mod]
  else:extra[mod+':'+directory.name]=dict(counts)
focus={k:v for k,v in caseNames.items()if k.endswith(('MappedExactStringIdsSplitTest','ViewTaskCancellationTest'))};assert sorted(map(len,focus.values()))==[3,6]
assert 'serial discovery observes task cancellation without interrupting a running callback' in focus['io.johnsonlee.graphite.webgraph.MappedExactStringIdsSplitTest']
taskNames=['core:test','cypher:test','webgraph:test','explore:test','cypher:filteredRelationshipMemoryTest','webgraph:largeCorpusTest'];taskReuse={}
for task in taskNames:
 lines=[l for l in log.splitlines()if l=='> Task :'+task or l.startswith('> Task :'+task+' ')];assert len(lines)==1;taskReuse[task]=lines[0].removeprefix('> Task :'+task).strip()or'executed'
for p in [H/'build-receipt.json',H/'preparation.json',H/'checks.py',H/'checks.log',Path(__file__)]:hashes[str(p)]=sha(p)
out={'status':'passed','regularTests':sum(x['tests']for x in regular.values()),'regularSuites':regular,'extraTests':sum(x['tests']for x in extra.values()),'extraSuites':extra,'failuresErrorsSkips':0,'focusedNineTestsAllPassed':focus,'taskReuse':taskReuse,'sourceHashesIndependentlyVerified':b['sourceHashes'],'candidateJarRecordedSHA256':b['candidateJarSha256'],'jarIndependentlyRehashed':False,'jarHashScope':'Completed build receipt binding only; no large JAR read in this review.','process':{'pid':cmd['pid'],'pgid':cmd['pgid'],'exit':0,'recordedDrain':cmd['processGroupCleanup'],'currentMembers':members},'localChecksNotCIAcceptance':True,'newHelperPerformanceNotAssessed':True,'noJVM':True,'inputHashes':hashes}
(O/'post-checks.json').write_text(json.dumps(out,indent=2)+'\n');print(out['regularTests'],out['extraTests'],taskReuse)
