from pathlib import Path
import collections,csv,hashlib,json,math,shlex,statistics
O=Path(__file__).resolve().parent;H=Path(__file__).resolve().parents[1];D=H/'original34-startingmain-pairs'
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def rows(p):
 with p.open()as f:return list(csv.DictReader(f,delimiter='\t'))
REF=Path('/private/tmp/graphite-exact-property-union.rhc6p2g8/global34-triples/base-global-wide-1.tsv');ORACLE=Path('/private/tmp/graphite-exact-property-union.rhc6p2g8/performance-plan/oracle.correctness');MANIFEST=Path('/private/tmp/graphite-current34-jfr.fonqampc/graphs.local.tsv');ref=rows(REF);sig='id family shape selectivity operator boundary projection targetGraphId workloadIdentity limit outcome rowCount responseBytes digest'.split();assert len(ref)==34;assert ['|'.join(r[k]for k in sig)for r in ref]==ORACLE.read_text().splitlines()
s=read(D/'run.json');g=read(D/'global-wide-status.json');assert s['status']=='complete'and s['verifiedQueryOutputs']==204 and s['inputsUnchanged']and s['graphInputsUnchanged'];assert s['inputHashesBefore']==s['inputHashesAfter'];assert read(D/'graph-input-before.json')==read(D/'graph-input-after.json');assert s['comparisonBase']=='startingmain';orders=['candidate-base','base-candidate','candidate-base'];labels=[f'{side}-global-wide-{i}'for i,order in enumerate(orders,1)for side in order.split('-')];assert s['completed']==labels and len(s['commands'])==6
jarsha={'base':'a5c2db2b0020798488916ec86902459d1044a7dcef606a73e00055883cdf5abe','candidate':'177d9c15cd07181766abbbc5ce275ab0da403c149a8a54e609857ae26eb91996'};jars={'base':Path('/private/tmp/graphite-next-baseline.T2FTs9/graphite-webgraph/build/libs/webgraph-1.0.0-SNAPSHOT-jmh.jar'),'candidate':H/'repo/graphite-webgraph/build/libs/webgraph-1.0.0-SNAPSHOT-jmh.jar'}
for side in jars:assert s['inputHashesAfter'][str(jars[side])]==jarsha[side]
allRows={};js={};nonlatref=[];hashes={}
for label,c in zip(labels,s['commands']):
 side=label.split('-')[0];prefix=D/label;args=f'-Xmx8g -XX:ActiveProcessorCount=4 -Dgraphite.broad.pressure.graphs={MANIFEST} -Dgraphite.broad.pressure.correctness.mode=verify -Dgraphite.broad.pressure.correctness.oracle={ORACLE} -Dgraphite.broad.pressure.observations.output={prefix}.tsv'
 expected=['/opt/homebrew/opt/openjdk@17/libexec/openjdk.jdk/Contents/Home/bin/java','-Xmx256m','-jar',str(jars[side]),'io.johnsonlee.graphite.webgraph.LargeBroadQueryPressureBenchmark.replayBroadQueries','-p','graphCount=64','-p','coverageFamily=global-wide','-p','indexState=cold','-p','timeoutMillis=300000','-wi','0','-i','1','-f','1','-to','30m','-foe','true','-prof','gc','-rf','json','-rff',str(prefix)+'.json','-jvmArgs',args];assert c['command']==expected;assert c['exitCode']==0 and c['pid']==c['pgid'];assert c['processGroupCleanup']=={'membersBeforeCleanup':[],'signals':[],'membersAfterCleanup':[],'drained':True}
 rs=rows(Path(str(prefix)+'.tsv'));j=read(Path(str(prefix)+'.json'));assert len(j)==1;j=j[0];assert len(rs)==34 and [{k:r[k]for k in sig}for r in rs]==[{k:r[k]for k in sig}for r in ref];assert all(set(a)==set(b)for a,b in zip(rs,ref));assert j['jvmArgs']==shlex.split(args)
 assert j['params']=={'coverageFamily':'global-wide','graphCount':'64','indexState':'cold','timeoutMillis':'300000'};assert j['benchmark']==expected[4]and j['mode']=='ss'and j['threads']==j['forks']==j['measurementIterations']==1 and j['warmupIterations']==0
 m={k:v['score']for k,v in j['secondaryMetrics'].items()};assert m['queryCount']==m['successCount']==34 and m['failureCount']==m['timeoutCount']==0 and m['availableProcessors']==4 and m['maxHeapBytes']<=8*1024**3 and m['processCpuNanos']>0
 for p,n in [(.5,'p50LatencyNanos'),(.95,'p95LatencyNanos')]:assert sorted(int(r['latencyNanos'])for r in rs)[math.ceil(34*p)-1]==m[n]
 for a,b in zip(rs,ref):
  diff={k:[b[k],a[k]]for k in a if k!='latencyNanos'and a[k]!=b[k]}
  if diff:nonlatref.append({'run':label,'id':a['id'],'differences':diff})
 allRows[label]=rs;js[label]=m
 for p in [Path(str(prefix)+'.json'),Path(str(prefix)+'.tsv')]:hashes[str(p)]=sha(p)
flags=collections.defaultdict(list);nonlat=[];pairs=[];errors=[];target=[]
shapes=['global-wide-wrapped-case-insensitive','global-wide-wrapped-case-insensitive-distinct']
for i in range(1,4):
 br,cr=[allRows[f'{side}-global-wide-{i}']for side in ['base','candidate']];bm,cm=[js[f'{side}-global-wide-{i}']for side in ['base','candidate']];wrapped=[]
 for shape in shapes:
  b=max(int(r['latencyNanos'])for r in br if r['shape']==shape);c=max(int(r['latencyNanos'])for r in cr if r['shape']==shape);wrapped.append({'shape':shape,'baseLatencyNanos':b,'latencyNanos':c,'speedup':b/c})
 worst=min(wrapped,key=lambda x:x['speedup']);result={'order':orders[i-1],'baseP50LatencyNanos':bm['p50LatencyNanos'],'baseP95LatencyNanos':bm['p95LatencyNanos'],'p50LatencyNanos':cm['p50LatencyNanos'],'p95LatencyNanos':cm['p95LatencyNanos'],'p50Speedup':bm['p50LatencyNanos']/cm['p50LatencyNanos'],'p95Speedup':bm['p95LatencyNanos']/cm['p95LatencyNanos'],'baseWrappedP95LatencyNanos':worst['baseLatencyNanos'],'wrappedP95LatencyNanos':worst['latencyNanos'],'wrappedP95Speedup':worst['speedup'],'wrappedShapeRuns':wrapped,'baseProcessCpuNanos':bm['processCpuNanos'],'processCpuNanos':cm['processCpuNanos'],'cpuCoreUtilizationPermille':cm['cpuCoreUtilizationPermille'],'basePeakUsedHeapBytes':bm['peakUsedHeapBytes'],'peakUsedHeapBytes':cm['peakUsedHeapBytes'],'basePeakResidentSetBytes':bm['peakResidentSetBytes'],'peakResidentSetBytes':cm['peakResidentSetBytes']};assert result==g['runs'][i-1]
 for label,b,c in [('aggregate P95',int(bm['p95LatencyNanos']),int(cm['p95LatencyNanos']))]+[(w['shape']+' P95',w['baseLatencyNanos'],w['latencyNanos'])for w in wrapped]:
  if c>b*1.15 and c-b>1000000:flags[label].append(f'pair-{i}/{label}: latency {c} exceeds base {b} by >15% and >1 ms')
 qs=[]
 for b,c in zip(br,cr):
  bn,cn=int(b['latencyNanos']),int(c['latencyNanos']);f=cn>bn*1.15 and cn-bn>1000000
  if f:
   key=c['shape']+'/'+c['selectivity'];flags[key].append(f'pair-{i}/{key}: aligned latency {cn} exceeds base {bn} by >15% and >1 ms')
  diff={k:[b[k],c[k]]for k in b if k!='latencyNanos'and b[k]!=c[k]}
  if diff:nonlat.append({'pair':i,'id':b['id'],'differences':diff})
  qs.append({'id':b['id'],'baseNanos':bn,'candidateNanos':cn,'candidateOverBase':cn/bn,'flag':f})
 for label,k in [('process CPU','processCpuNanos'),('peak used heap','peakUsedHeapBytes'),('peak RSS','peakResidentSetBytes')]:
  if bm[k]>0 and cm[k]>bm[k]*1.15:errors.append(f'pair-{i}: {label} {cm[k]} exceeds paired base {bm[k]} by >15%')
 pairs.append({'pair':i,'metrics':result,'fullReplayCpuPercent':(cm['processCpuNanos']/bm['processCpuNanos']-1)*100,'allBaseSecondaryMetrics':bm,'allCandidateSecondaryMetrics':cm,'queries':qs,'q29':qs[28]})
for samples in flags.values():
 if len(samples)>=2:errors.append(samples[0]+f'; repeated in {len(samples)} independent pairs')
assert errors==g['errors'];assert not g['regressionPassed']and not g['passed']and not g['targetAchieved'];assert g['regressionOnly']and g['minimumSpeedup']==10;assert all(p['metrics']['p95Speedup']< 10 for p in pairs)
for p in [REF,ORACLE,H/'build-receipt.json',H/'class-scope.json',H/'run-original34.py',D/'run.json',D/'global-wide-status.json',D/'comparator-command.json',Path(__file__)]:hashes[str(p)]=sha(p)
out={'status':'verified-local-regression-failure-target-false','fullOracleResults':204,'pairs':pairs,'repeatedGateFlags':{k:len(v)for k,v in flags.items()if len(v)>=2},'gateErrorsExactlyRecomputed':errors,'allPairedNonLatencyDifferences':nonlat,'allReferenceNonLatencyDifferences':nonlatref,'baselineSHA':jarsha['base'],'candidateSHA':jarsha['candidate'],'allSixExactCommandsAndDrains':True,'resourceEvidence':'Process CPU includes full replay/inter-query work; heap/RSS sampled peaks are retained, not per-query CPU.','sourceAndJarBindings':'Recorded capture before/after and completed build/class-scope receipts; no large JAR/graph hash rerun.','newHelperCandidateIncluded':True,'noJVMOrNode':True,'acceptance':False,'inputHashes':hashes}
(O/'helper-original34-startingmain.json').write_text(json.dumps(out,indent=2)+'\n');print('verified',len(nonlat),'paired nonlat','P95',[round(p['metrics']['p95Speedup'],4)for p in pairs],'CPU%',[round(p['fullReplayCpuPercent'],3)for p in pairs],out['repeatedGateFlags'])
