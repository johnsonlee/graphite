# q5 path and prior official-branch evidence

Independent full starting-main replay audit passed 204 original 14-field signatures and exact order, six commands and normal private-group exits. All paired non-latency fields agree. The original regression gate **fails**: `global-wide-class-pair/targeted` flags in pairs 2 and 3. P95 speedups are 2.457/0.940/1.213; replay process CPU changes are −5.56/+12.24/+2.77%. These local results are not CI or a stable speedup.

The failing case is **ordinal 5 (q5), not q6**. `class-pair` names the two projected columns; its predicate is one term ORed across four properties. It is neither AND nor a multi-keyword query:

```cypher
MATCH (n) WHERE n.caller_class CONTAINS 'com.android.server.wallpapereffectsgeneration.RemoteWallpaperEffectsGenerationService$RemoteWallpaperEffectsGenerationServiceCallback' OR n.caller_name CONTAINS 'com.android.server.wallpapereffectsgeneration.RemoteWallpaperEffectsGenerationService$RemoteWallpaperEffectsGenerationServiceCallback' OR n.callee_class CONTAINS 'com.android.server.wallpapereffectsgeneration.RemoteWallpaperEffectsGenerationService$RemoteWallpaperEffectsGenerationServiceCallback' OR n.callee_name CONTAINS 'com.android.server.wallpapereffectsgeneration.RemoteWallpaperEffectsGenerationService$RemoteWallpaperEffectsGenerationServiceCallback' RETURN n.caller_class, n.callee_class LIMIT 200
```

The source manifest binds the term to fixture-android-07 and workload identity `2884fe5070e6e70bd2c44e54af37c56e2cfd19343a8721d5b36093d7d1db0f7d`. Every current pair returns one row / 548 response bytes, digest `293726158b0e5fab1ac11826253b0682c325d22e027a3b3fd202214984b341d6`, with 2674 work units, all 64 graphs accessed, and only android-07 hit.

## Concrete source route

Line numbers below refer to the frozen candidate repo under this audit's parent directory. The benchmark builds this query at `LargeBroadQueryPressureBenchmark.kt:1568`–1579, selects the class-pair projection at 2009–2012, and resolves the targeted routing term in the workload builder at 1230–1263.

`QueryPipeline.kt:1291` recognizes MATCH/WHERE/RETURN/LIMIT; there is no graph scope and RETURN is non-DISTINCT. The four-arm disjunction routes at 1355/1374 to `executeDirectStringDisjunctionRows` (1639). Its separate indexed-projection shortcut (1890–1904) declines because there are 64 sources and `preferPersistedStorage=false`. Balanced splitting applies (170); this long term cannot take the ≤4-character raw-leading branch (1663, 4620–4624). The first source can use initialized mapped projection via `projectLeadingRows` (1831–1874); if unavailable it falls back to candidate lookup. Following sources use scanner `nextRows` (2657) and `directStringCandidates` (2761). This is the ordinary rows path, not q29/q30's specialized DISTINCT path.

The storage consumer factory (210–241, 4577–4618) supplies `PreferredMappedStringIndexViewGraphWorkConsumer`, which is a Split consumer, for the balanced mapped route. Backend `lookupStringPropertyDisjunction` at `MappedWebGraphBackedGraph.kt:917`–942 chooses a retained index if one already exists, otherwise loads/reuses the mapped view and calls `exactMatchingStringIds`. Its predicates share the same transform/mode/term; the mapped `matchingNodeIds` shortcut therefore returns physical-order posting candidates without a raw node scan. The initialized leading projection at 773–778 calls the same view methods. A retained-index or unsupported/missing-view fallback is a separate conditional path.

The term is ASCII, raw CONTAINS, and longer than three characters, satisfying `MappedCallSiteStringIndexView.kt:587` eligibility. The new `checkViewInterrupted` can therefore be reached through index load/checksum, exact-ID scan polling (238), posting validation (182), and lazy merge polling (148). Actual calls depend on cache state, empty trigram early returns, absolute posting-mask alignment and whether a nonempty cursor is consumed; current TSVs do not count these calls. Reaching these methods is **not proof of a new guard invocation on every graph**, nor of its duration. A warmed mapped view does not bypass exact-ID computation, but validated postings may bypass validation. The zero legacy `indexLookupCount`/`parallelScanCount` metrics do not demonstrate no index use or no graph tasks.

## Paired observations retained

| Comparison | Pair 1 B→C ms | Pair 2 B→C ms | Pair 3 B→C ms | q5 flags |
|---|---:|---:|---:|---|
| Current local official 04ae → helper 177d | 4.972→5.113 | 4.981→5.045 | 5.400→5.236 | none |
| Current local frozen main a5c2 → helper 177d | 4.507→5.009 | 4.264→5.527 | 4.373→5.696 | 2, 3 |
| Prior CI frozen main 4e328 → official 5e052 | 13.631→12.470 | 13.655→11.910 | 10.634→11.395 | none |
| Prior CI current main 847c → official 5e052 | 9.855→12.201 | 11.487→13.258 | 11.554→9.284 | 1, 2 |

History is narrowly scoped to the already archived CI 34308711510 original 12 TSVs and its reference/provenance receipt. The original query id, workload identity, result digest and all q5 non-latency values agree across each historical pair. CI's official commit is 5e052, but its Linux-built JAR is not asserted identical to the local 04ae payload. Thus a q5 regression against the then-current main existed before this helper change; the examined prior frozen-main comparison does **not** show a q5 repeated regression. Neither observation explains away the current frozen-main failure. Separate batches cannot be joined into a causal difference-of-differences comparison.

## Next bounded discriminator

First isolate the production contrast without adding another observer: if further q5 attribution is required, run a predeclared balanced three-version full original34 comparison of frozen main, official 5e052, and helper 177d with the existing uninstrumented protocol, unchanged prefix/order/heap/NCPU/oracle and all gates/resources retained. This directly distinguishes an official-branch difference from an incremental helper effect within the same experiment; existing separate batches cannot do that. It still will not identify CPU versus waiting. If the incremental official→helper regression reproduces, restrict subsequent path diagnosis to the exact view entry and poll counts, query-owner/task CPU completeness and direct-versus-nested waits using the already validated boundary protocol. Do not alter the cancellation fix based solely on equal work counters or inferred JIT overhead; do not reduce the full benchmark to q5-only timing.

No JVM, benchmark, large artifact hash, or frozen input mutation was performed for this audit. Small source, TSV and receipt hashes are in the companion JSON. Starting-main full204 arithmetic is independently recorded in `helper-original34-startingmain.json`.
