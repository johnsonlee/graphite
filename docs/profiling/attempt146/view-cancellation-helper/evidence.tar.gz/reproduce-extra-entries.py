from pathlib import Path
import importlib.util,json,subprocess,os,time,xml.etree.ElementTree as ET,shutil,traceback
H=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('owned','/private/tmp/graphite-root-admission-probe.15TXkwF5/run.py');o=importlib.util.module_from_spec(spec);spec.loader.exec_module(o)
repo=H/'repo';rel='graphite-webgraph/src/main/kotlin/io/johnsonlee/graphite/webgraph/MappedCallSiteStringIndexView.kt';source=repo/rel
wanted=source.read_bytes();baseline=subprocess.check_output(['git','show','5e05242a8f1a9cc3ae07959d387af77adabf4705:'+rel],cwd=repo)
out=H/'baseline-extra-entry-reproduction';out.mkdir();(out/'intended-candidate.kt').write_bytes(wanted)
s={'status':'running','expected':'All three extra-entry tests fail specifically because remaining work or cache publication completes after cancellation','command':{},'candidateSourceSha256':o.sha(source)};save=lambda:o.write(out/'receipt.json',s);save()
source.write_bytes(baseline);s['baselineSourceSha256']=o.sha(source);save()
os.chdir(repo);os.environ['JAVA_HOME']='/opt/homebrew/opt/openjdk@17/libexec/openjdk.jdk/Contents/Home'
cmd=['./gradlew','--no-daemon','--max-workers=2','-Dorg.gradle.jvmargs=-Xmx2g','-Pkotlin.compiler.execution.strategy=in-process',':webgraph:test','--tests','io.johnsonlee.graphite.webgraph.ViewTaskCancellationTest'];s['command'].update(command=cmd,startedEpoch=time.time());save()
try:
 try:o.execute_owned(cmd,out/'gradle.log',s['command'],save,1800)
 except AssertionError as e:
  if e.args!=(('Java failed',1),):raise
 assert s['command']['exitCode']==1 and s['command']['processGroupCleanup']['drained']
 p=repo/'graphite-webgraph/build/test-results/test/TEST-io.johnsonlee.graphite.webgraph.ViewTaskCancellationTest.xml';shutil.copy2(p,out/p.name)
 root=ET.parse(p).getroot();assert int(root.attrib['tests'])==3 and int(root.attrib['failures'])==3 and int(root.attrib['errors'])==0
 expected={'cancelled checksum loading stops work and leaves the persisted index loadable':'Cancelled load must stop before a full checksum','cancelled posting validation does not cache an incomplete range':'Cancelled validation must stop scanning','cancelled lazy merge stops after a prefix without interrupting the callback':'Cancelled merge must stop remaining work'}
 for test in root.findall('testcase'):
  assert test.attrib['name'] in expected
  failure=test.find('failure');assert failure is not None and expected[test.attrib['name']] in failure.attrib['message'],failure.attrib
 s['failures']={t.attrib['name']:t.find('failure').attrib for t in root.findall('testcase')}
 assert source.read_bytes()==baseline
 s['status']='reproduced'
except BaseException:s.update(status='failed',error=traceback.format_exc());raise
finally:
 assert s['command'].get('processGroupCleanup',{}).get('drained'), 'Refuse source restore with live owned JVM'
 source.write_bytes(wanted);s['candidateSourceRestored']=o.sha(source)==s['candidateSourceSha256'];save()
print(s['status'])
