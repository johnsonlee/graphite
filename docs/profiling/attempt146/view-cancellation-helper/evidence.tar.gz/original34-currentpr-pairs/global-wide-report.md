### 64 fixture-derived global wide-query pressure gate

Evaluation: **non-regression**
P95 target in every independent paired fork: **10.0x**
Regression checks: **PASS**; target achieved: **NO**
Target remains unmet; a passing regression evaluation does not establish the speedup target.
pair-1: P95 speedup 1.26x; required 10.00x in every independent fork
pair-1: global-wide-wrapped-case-insensitive P95 speedup 0.96x; required 10.00x
pair-1: global-wide-wrapped-case-insensitive-distinct P95 speedup 1.26x; required 10.00x
pair-2: P95 speedup 0.81x; required 10.00x in every independent fork
pair-2: global-wide-wrapped-case-insensitive P95 speedup 1.00x; required 10.00x
pair-2: global-wide-wrapped-case-insensitive-distinct P95 speedup 0.81x; required 10.00x
pair-3: P95 speedup 1.02x; required 10.00x in every independent fork
pair-3: global-wide-wrapped-case-insensitive P95 speedup 0.97x; required 10.00x
pair-3: global-wide-wrapped-case-insensitive-distinct P95 speedup 1.02x; required 10.00x

- Worst paired base P50 / P95: **2.332 ms / 56.866 ms**
- Worst paired candidate P50 / P95: **2.587 ms / 70.615 ms**
- Worst individual P95 speedup (retained for audit): **0.81x**
- Worst wrapped case-insensitive P95 speedup: **0.81x**
- Worst order-median P95 speedup: **0.81x**
- candidate-base: **2 pair(s), 0.97x P50 / 1.14x P95**
- base-candidate: **1 pair(s), 0.90x P50 / 0.81x P95**

| Pair | Order | Base P50 | Base P95 | Candidate P50 | Candidate P95 | P50 speedup | P95 speedup | CPU total | CPU cores | Heap | RSS |
| ---: | :--- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 1 | candidate-base | 2.239 ms | 57.680 ms | 2.466 ms | 45.653 ms | 0.91x | 1.26x | 1888.211 ms → 1652.341 ms | 3.17 | 4.39 GiB → 4.39 GiB | 4.91 GiB → 4.93 GiB |
| 2 | base-candidate | 2.332 ms | 56.866 ms | 2.587 ms | 70.615 ms | 0.90x | 0.81x | 1747.880 ms → 1835.159 ms | 3.41 | 3.94 GiB → 4.02 GiB | 4.47 GiB → 4.52 GiB |
| 3 | candidate-base | 2.356 ms | 47.229 ms | 2.268 ms | 46.194 ms | 1.04x | 1.02x | 1605.086 ms → 1664.476 ms | 3.19 | 3.94 GiB → 4.38 GiB | 4.45 GiB → 4.89 GiB |

**Result: PASS**
