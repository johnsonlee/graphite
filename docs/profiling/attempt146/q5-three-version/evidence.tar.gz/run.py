"""Fixed original34 three-version attribution; unchanged production/JMH/gates, not CI acceptance."""
from pathlib import Path
import importlib.util,sys,json,subprocess,os,time,traceback,hashlib,csv
D=Path(__file__).resolve().parent
H=Path('/var/folders/sy/_tdkyl2x0gx6z5kl2wbhd9tc0000gn/T/graphite-view-cancel-helper.ptfakahe')
P=H/'run-original34.py'
argv=sys.argv[:]
try:
 sys.argv=[str(P),'currentpr'];spec=importlib.util.spec_from_file_location('frozen34',P);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
finally:sys.argv=argv
JARS={'main':m.BASE_PATHS['startingmain'],'official':m.BASE_PATHS['currentpr'],'helper':H/'repo/graphite-webgraph/build/libs/webgraph-1.0.0-SNAPSHOT-jmh.jar'}
SHAS={'main':m.BASE_HASHES['startingmain'],'official':m.BASE_HASHES['currentpr'],'helper':'177d9c15cd07181766abbbc5ce275ab0da403c149a8a54e609857ae26eb91996'}
ORDER=(('main','official','helper'),('official','helper','main'),('helper','main','official'))
COMPARISONS=(('official-vs-main','main','official'),('helper-vs-main','main','helper'),('helper-vs-official','official','helper'))
COMPARATOR=H/'repo/.github/scripts/benchmark-gate.mjs'
def command(side,prefix):
 args=f'-Xmx8g -XX:ActiveProcessorCount=4 -Dgraphite.broad.pressure.graphs={m.MANIFEST} -Dgraphite.broad.pressure.correctness.mode=verify -Dgraphite.broad.pressure.correctness.oracle={m.ORACLE} -Dgraphite.broad.pressure.observations.output={prefix}.tsv'
 return [m.JAVA,'-Xmx256m','-jar',str(JARS[side]),'io.johnsonlee.graphite.webgraph.LargeBroadQueryPressureBenchmark.replayBroadQueries','-p','graphCount=64','-p','coverageFamily=global-wide','-p','indexState=cold','-p','timeoutMillis=300000','-wi','0','-i','1','-f','1','-to','30m','-foe','true','-prof','gc','-rf','json','-rff',str(prefix)+'.json','-jvmArgs',args]
def identity():
 for key in ('JAVA_TOOL_OPTIONS','JDK_JAVA_OPTIONS','_JAVA_OPTIONS'):assert not os.environ.get(key),key
 build=m.read(H/'build-receipt.json');scope=m.read(H/'class-scope.json')
 assert build['status']=='passed' and build['allSourceInputsStillMatch'] and scope['status']=='passed' and scope['allOtherClassBytesIdentical']
 assert build['candidateJarSha256']==scope['candidateSha256']==SHAS['helper'] and scope['baseSha256']==SHAS['official']
 for k,p in JARS.items():assert m.sha(p)==SHAS[k],k
 for p,h in build['sourceHashes'].items():assert m.sha(H/'repo'/p)==h,p
 assert m.sha(COMPARATOR)=='a4d09bf16e44deb05cab214db16bd9f922cf41430fb6028de1a3f8a9d71b3950'
 ref=m.rows(m.REF);ids=[r['id'] for r in ref];assert len(ids)==len(set(ids))==34
 assert ids[4]=='global-wide-class-pair-targeted'
 assert ['|'.join(r[k] for k in m.SIGNATURE) for r in ref]==m.ORACLE.read_text().splitlines()
 payload=m.read(D/'benchmark-payload-scope.json');assert len(payload['classes']['main'])==12 and not payload['mainOfficialDifferent'] and not payload['officialHelperDifferent']
 pins=[Path(__file__),D/'benchmark-payload-scope.json',P,COMPARATOR,*JARS.values(),m.REF,m.MANIFEST,m.ORACLE,H/'build-receipt.json',H/'preparation.json',H/'class-scope.json',H/'verify-class-scope.py',H/'SymbolicClassCompare.java',H/'symbolic-methods.tsv',H/'class-scope.log',H/'symbolic-methods.tsv-base.txt',H/'symbolic-methods.tsv-candidate.txt',H/'candidate.patch',*[H/'repo'/p for p in build['sourceHashes']]]
 return ref,{str(p):m.sha(p) for p in pins}
def validate_output(prefix,ref):
 check=m.validate_jmh(Path(str(prefix)+'.json'));rs=m.rows(Path(str(prefix)+'.tsv'));assert [r['id'] for r in rs]==[r['id'] for r in ref]
 diff=[]
 for a,b in zip(rs,ref):
  assert set(a)==set(b) and [a[k] for k in m.SIGNATURE]==[b[k] for k in m.SIGNATURE],a['id']
  ds={k:[b[k],a[k]] for k in a if k!='latencyNanos' and a[k]!=b[k]}
  if ds:diff.append({'id':a['id'],'differences':ds})
 m.write(Path(str(prefix)+'-oracle-check.json'),{'full14FieldsPassed':True,'queryCount':34,'nonTimeDifferences':diff})
 return check
def run():
 out=D/'original34';assert not out.exists();out.mkdir();receipt=out/'run.json'
 state={'status':'preparing','accepted':False,'goalAchieved':False,'purpose':'Attribute q5 regression to official PR inherited cost vs helper incremental cost under the full original34 prefix. No new optimization or observer.',
 'pid':os.getpid(),'order':ORDER,'comparisons':COMPARISONS,'completed':[],'commands':[],
 'frozenStartingMain':'4e328b0109e13c896b74004823fb049fcb19251a','officialPR':'5e05242a8f1a9cc3ae07959d387af77adabf4705',
 'selectedJars':{k:{'path':str(p),'sha256':SHAS[k]} for k,p in JARS.items()},
 'samplesPerQueryPerVersion':3,'perQueryP95':None,'benchmarkProtocol':'Original34 full replay cold-on-replay, original JMH single-shot, zero warmup, original gc profiler and resource sampler, P4, max heap8g. No new observer or query-only run.',
 'designLimits':['Three Latin rotations balance each version over positions; pair direction counts remain 2:1, as with a three-pair schedule. Predecessors are not fully balanced and not all six permutations are run.','One version can lie between the other paired versions; exact positions and execution times retained. OS cache/JIT/frequency effects are not controlled by this ordering.','Same-block comparisons are diagnostic; no cross-batch difference-in-differences or significance claims.','Full replay processCPU includes canonicalization and verification between queries, not q5 CPU.','Every original gate result, all34 query observations and every nonlatency difference retained. No changed thresholds or retries to green.']}
 m.write(receipt,state);pins={};gb=None
 try:
  ref,pins=identity();state.update(status='running',inputHashesBefore=pins.copy());m.write(receipt,state)
  gb=m.graph_hashes();m.write(out/'graph-input-before.json',gb);assert gb==m.read(m.FIX/'fixture-input-before.json');state['graphInputsVerifiedBefore']=True;m.write(receipt,state)
  for group,order in enumerate(ORDER,1):
   for position,side in enumerate(order,1):
    assert all(m.sha(Path(p))==h for p,h in pins.items())
    label=f'{side}-global-wide-{group}';prefix=out/label;cmd=command(side,prefix)
    c={'id':label,'version':side,'group':group,'position':position,'command':cmd,'startedEpoch':time.time(),'beforeProcesses':subprocess.check_output(['ps','-axo','pid,ppid,pgid,etime,command'],text=True)}
    state['commands'].append(c);m.write(receipt,state);print('START',label,flush=True)
    with Path(str(prefix)+'.log').open('w') as log:
     p=subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);c.update(pid=p.pid,pgid=p.pid);m.write(receipt,state)
     try:code=p.wait(timeout=2100)
     except BaseException:c['waitError']=traceback.format_exc();raise
     finally:
      try:c['processGroupCleanup']=m.drain_owned_group(p)
      except BaseException:c['processGroupCleanup']={'drained':False,'error':traceback.format_exc()}
      c.update(exitCode=p.poll(),finishedEpoch=time.time(),afterProcesses=subprocess.check_output(['ps','-axo','pid,ppid,pgid,etime,command'],text=True));m.write(receipt,state)
     assert c['processGroupCleanup']['drained'] and not c['processGroupCleanup']['membersBeforeCleanup'];assert code==0,(label,code)
    c['jmhValidation']=validate_output(prefix,ref);state['completed'].append(label);m.write(receipt,state);print('DONE',label,flush=True)
  node=subprocess.check_output(['which','node'],text=True).strip();state['comparisonResults']={}
  for name,base,candidate in COMPARISONS:
   target=out/name;target.mkdir();orders=['base-candidate' if order.index(base)<order.index(candidate) else 'candidate-base' for order in ORDER]
   cmd=[node,str(COMPARATOR),'compare-global-wide-pressure']
   for opt,version,ext in [('bases',base,'json'),('candidates',candidate,'json'),('base-observations',base,'tsv'),('candidate-observations',candidate,'tsv')]:cmd+=['--'+opt,','.join(str(out/f'{version}-global-wide-{i}.{ext}') for i in (1,2,3))]
   cmd+=['--run-orders',','.join(orders),'--graph-manifest',str(m.MANIFEST),'--correctness-oracle',str(m.ORACLE),'--minimum-speedup','10','--regression-only','--report',str(target/'report.md'),'--status',str(target/'status.json')]
   m.write(target/'command.json',cmd)
   with (target/'comparator.log').open('w') as log:code=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=60).returncode
   assert code in (0,1) and (target/'status.json').exists();state['comparisonResults'][name]={'base':base,'candidate':candidate,'runOrders':orders,'exitCode':code,'status':m.read(target/'status.json')};m.write(receipt,state)
  state.update(status='complete',verifiedQueryOutputs=306)
 except BaseException:state.update(status='failed',error=traceback.format_exc());raise
 finally:
  failed=state['status']=='failed'
  try:
   assert all(c.get('processGroupCleanup',{}).get('drained',False) for c in state['commands'] if 'pid' in c),'Do not hash while owned process remains'
   after={p:m.sha(Path(p)) for p in pins};state.update(inputHashesAfter=after,inputsUnchanged=pins==after);assert pins==after
   if gb is not None:
    ga=m.graph_hashes();m.write(out/'graph-input-after.json',ga);assert ga==gb==m.read(m.FIX/'fixture-input-before.json');state['graphInputsUnchanged']=True
   state['outputHashes']={str(p):m.sha(p) for p in out.rglob('*') if p.is_file() and p!=receipt}
  except BaseException:
   state.update(status='failed',integrityError=traceback.format_exc())
   if not failed:raise
  finally:state['finishedEpoch']=time.time();m.write(receipt,state)
if __name__=='__main__':run()
