from pathlib import Path
import collections,csv,hashlib,json,math,shlex,statistics
O=Path(__file__).resolve().parent;ROOT=O.parent;D=ROOT/'original34';H=Path('/var/folders/sy/_tdkyl2x0gx6z5kl2wbhd9tc0000gn/T/graphite-view-cancel-helper.ptfakahe')
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def rows(p):
 with p.open() as f:return list(csv.DictReader(f,delimiter='\t'))
def number_text(x):return str(int(x)) if isinstance(x,(int,float)) and float(x).is_integer() else str(x)
def recompute(g,orders,allRows,js):
 flags=collections.defaultdict(list);nonlat=[];pairs=[];errors=[];target=[]
 shapes=['global-wide-wrapped-case-insensitive','global-wide-wrapped-case-insensitive-distinct']
 for i in range(1,4):
  br,cr=[allRows[f'{side}-global-wide-{i}']for side in ['base','candidate']];bm,cm=[js[f'{side}-global-wide-{i}']for side in ['base','candidate']];wrapped=[]
  for shape in shapes:
   b=max(int(r['latencyNanos'])for r in br if r['shape']==shape);c=max(int(r['latencyNanos'])for r in cr if r['shape']==shape);wrapped.append({'shape':shape,'baseLatencyNanos':b,'latencyNanos':c,'speedup':b/c})
  worst=wrapped[0] if wrapped[0]['speedup']<wrapped[1]['speedup'] else wrapped[1];result={'order':orders[i-1],'baseP50LatencyNanos':bm['p50LatencyNanos'],'baseP95LatencyNanos':bm['p95LatencyNanos'],'p50LatencyNanos':cm['p50LatencyNanos'],'p95LatencyNanos':cm['p95LatencyNanos'],'p50Speedup':bm['p50LatencyNanos']/cm['p50LatencyNanos'],'p95Speedup':bm['p95LatencyNanos']/cm['p95LatencyNanos'],'baseWrappedP95LatencyNanos':worst['baseLatencyNanos'],'wrappedP95LatencyNanos':worst['latencyNanos'],'wrappedP95Speedup':worst['speedup'],'wrappedShapeRuns':wrapped,'baseProcessCpuNanos':bm['processCpuNanos'],'processCpuNanos':cm['processCpuNanos'],'cpuCoreUtilizationPermille':cm['cpuCoreUtilizationPermille'],'basePeakUsedHeapBytes':bm['peakUsedHeapBytes'],'peakUsedHeapBytes':cm['peakUsedHeapBytes'],'basePeakResidentSetBytes':bm['peakResidentSetBytes'],'peakResidentSetBytes':cm['peakResidentSetBytes']};assert result==g['runs'][i-1]
  for label,b,c in [('aggregate P95',int(bm['p95LatencyNanos']),int(cm['p95LatencyNanos']))]+[(w['shape']+' P95',w['baseLatencyNanos'],w['latencyNanos'])for w in wrapped]:
   if c>b*1.15 and c-b>1000000:flags[label].append(f'pair-{i}/{label}: latency {c} exceeds base {b} by >15% and >1 ms')
  qs=[]
  for b,c in zip(br,cr):
   bn,cn=int(b['latencyNanos']),int(c['latencyNanos']);f=cn>bn*1.15 and cn-bn>1000000
   if f:
    key=c['shape']+'/'+c['selectivity'];flags[key].append(f'pair-{i}/{key}: aligned latency {cn} exceeds base {bn} by >15% and >1 ms')
   diff={k:[b[k],c[k]]for k in b if k!='latencyNanos'and b[k]!=c[k]}
   if diff:nonlat.append({'pair':i,'id':b['id'],'differences':diff})
   qs.append({'id':b['id'],'baseNanos':bn,'candidateNanos':cn,'candidateOverBase':cn/bn,'flag':f})
  for label,k in [('process CPU','processCpuNanos'),('peak used heap','peakUsedHeapBytes'),('peak RSS','peakResidentSetBytes')]:
   if bm[k]>0 and cm[k]>bm[k]*1.15:errors.append(f'pair-{i}: {label} {number_text(cm[k])} exceeds paired base {number_text(bm[k])} by >15%')
  pairs.append({'pair':i,'metrics':result,'fullReplayCpuPercent':(cm['processCpuNanos']/bm['processCpuNanos']-1)*100,'allBaseSecondaryMetrics':bm,'allCandidateSecondaryMetrics':cm,'queries':qs,'q29':qs[28]})
 for samples in flags.values():
  if len(samples)>=2:errors.append(samples[0]+f'; repeated in {len(samples)} independent pairs')
 targetErrors=[]
 for i,p in enumerate(pairs,1):
  m=p['metrics']
  if m['p95Speedup']<10:targetErrors.append(f"pair-{i}: P95 speedup {m['p95Speedup']:.2f}x; required 10.00x in every independent fork")
  for w in m['wrappedShapeRuns']:
   if w['speedup']<10:targetErrors.append(f"pair-{i}: {w['shape']} P95 speedup {w['speedup']:.2f}x; required 10.00x")
 assert errors==g['errors'] and targetErrors==g['targetErrors']
 assert g['regressionPassed']==(not errors) and g['targetAchieved']==(not errors and not targetErrors)
 assert g['regressionOnly'] and g['minimumSpeedup']==10 and g['passed']==g['regressionPassed']
 orderSummaries=[]
 for order in ['base-candidate','candidate-base']:
  selected=[p['metrics'] for p in pairs if p['metrics']['order']==order];assert selected
  orderSummaries.append({'order':order,'runCount':len(selected),'medianP50Speedup':statistics.median(x['p50Speedup'] for x in selected),'medianP95Speedup':statistics.median(x['p95Speedup'] for x in selected)})
 assert {x['order']:x for x in orderSummaries}=={x['order']:x for x in g['orderSummaries']}
 return {'pairs':pairs,'allPairedNonLatencyDifferences':nonlat,'repeatedFlags':{k:len(v) for k,v in flags.items() if len(v)>=2},'errors':errors,'targetErrors':targetErrors,'regressionPassed':g['regressionPassed'],'targetAchieved':g['targetAchieved'],'orderSummaries':orderSummaries}

REF=Path('/private/tmp/graphite-exact-property-union.rhc6p2g8/global34-triples/base-global-wide-1.tsv');ORACLE=Path('/private/tmp/graphite-exact-property-union.rhc6p2g8/performance-plan/oracle.correctness');MANIFEST=Path('/private/tmp/graphite-current34-jfr.fonqampc/graphs.local.tsv');COMPARATOR=H/'repo/.github/scripts/benchmark-gate.mjs'
ref=rows(REF);sig='id family shape selectivity operator boundary projection targetGraphId workloadIdentity limit outcome rowCount responseBytes digest'.split();assert len(ref)==34 and ref[4]['id']=='global-wide-class-pair-targeted';assert ['|'.join(x[k] for k in sig) for x in ref]==ORACLE.read_text().splitlines()
r=read(D/'run.json');assert r['status']=='complete' and r['verifiedQueryOutputs']==306 and r['inputsUnchanged'] and r['graphInputsUnchanged'] and not r['accepted'] and not r['goalAchieved']
assert r['inputHashesBefore']==r['inputHashesAfter'];assert read(D/'graph-input-before.json')==read(D/'graph-input-after.json')==read(MANIFEST.parent/'fixture-input-before.json')
ORDER=[['main','official','helper'],['official','helper','main'],['helper','main','official']];COMPS=[['official-vs-main','main','official'],['helper-vs-main','main','helper'],['helper-vs-official','official','helper']];assert r['order']==ORDER and r['comparisons']==COMPS and r['samplesPerQueryPerVersion']==3 and r['perQueryP95'] is None
labels=[f'{side}-global-wide-{i}' for i,order in enumerate(ORDER,1) for side in order];assert r['completed']==labels and len(r['commands'])==9 and len({x['pid'] for x in r['commands']})==9
jars={'main':Path('/private/tmp/graphite-next-baseline.T2FTs9/graphite-webgraph/build/libs/webgraph-1.0.0-SNAPSHOT-jmh.jar'),'official':Path('/private/tmp/graphite-pr116-conflicts.ghc4dddf/repo/graphite-webgraph/build/libs/webgraph-1.0.0-SNAPSHOT-jmh.jar'),'helper':H/'repo/graphite-webgraph/build/libs/webgraph-1.0.0-SNAPSHOT-jmh.jar'}
SHAS={'main':'a5c2db2b0020798488916ec86902459d1044a7dcef606a73e00055883cdf5abe','official':'04ae90ec1f5560aa54f491a747e651c2f7b44ff453e169c9f2e8bb9fa9570814','helper':'177d9c15cd07181766abbbc5ce275ab0da403c149a8a54e609857ae26eb91996'}
for side,p in jars.items():assert r['selectedJars'][side]=={'path':str(p),'sha256':SHAS[side]} and r['inputHashesAfter'][str(p)]==SHAS[side]
smallPins={};largePins={}
for p,h in r['inputHashesAfter'].items():
 path=Path(p)
 if path.suffix=='.jar' or path.stat().st_size>8*1024*1024:largePins[p]=h
 else:assert sha(path)==h,p;smallPins[p]=h
assert sha(COMPARATOR)=='a4d09bf16e44deb05cab214db16bd9f922cf41430fb6028de1a3f8a9d71b3950'
allRows={};metrics={};resources={};refdiff=[];hashes={}
for index,(label,c) in enumerate(zip(labels,r['commands'])):
 group=index//3+1;position=index%3+1;side=ORDER[group-1][position-1];prefix=D/label
 assert c['id']==label and c['group']==group and c['position']==position and c['version']==side
 args=f'-Xmx8g -XX:ActiveProcessorCount=4 -Dgraphite.broad.pressure.graphs={MANIFEST} -Dgraphite.broad.pressure.correctness.mode=verify -Dgraphite.broad.pressure.correctness.oracle={ORACLE} -Dgraphite.broad.pressure.observations.output={prefix}.tsv'
 expected=['/opt/homebrew/opt/openjdk@17/libexec/openjdk.jdk/Contents/Home/bin/java','-Xmx256m','-jar',str(jars[side]),'io.johnsonlee.graphite.webgraph.LargeBroadQueryPressureBenchmark.replayBroadQueries','-p','graphCount=64','-p','coverageFamily=global-wide','-p','indexState=cold','-p','timeoutMillis=300000','-wi','0','-i','1','-f','1','-to','30m','-foe','true','-prof','gc','-rf','json','-rff',str(prefix)+'.json','-jvmArgs',args]
 assert c['command']==expected and c['pid']==c['pgid'] and c['exitCode']==0 and c['processGroupCleanup']=={'membersBeforeCleanup':[],'signals':[],'membersAfterCleanup':[],'drained':True}
 assert c['finishedEpoch']>=c['startedEpoch'] and (index==0 or c['startedEpoch']>=r['commands'][index-1]['finishedEpoch'])
 rs=rows(Path(str(prefix)+'.tsv'));data=read(Path(str(prefix)+'.json'));assert len(data)==1;j=data[0];assert len(rs)==34 and all(set(x)==set(y) and [x[k] for k in sig]==[y[k] for k in sig] for x,y in zip(rs,ref))
 assert j['jvmArgs']==shlex.split(args) and j['benchmark']==expected[4] and j['params']=={'coverageFamily':'global-wide','graphCount':'64','indexState':'cold','timeoutMillis':'300000'}
 assert j['mode']=='ss' and j['threads']==j['forks']==j['measurementIterations']==1 and j['warmupIterations']==0
 m={k:v['score'] for k,v in j['secondaryMetrics'].items()};assert m['queryCount']==m['successCount']==34 and m['failureCount']==m['timeoutCount']==0 and m['availableProcessors']==4 and 0<m['maxHeapBytes']<=8*1024**3 and m['processCpuNanos']>0
 for q,n in [(.5,'p50LatencyNanos'),(.95,'p95LatencyNanos')]:assert sorted(int(x['latencyNanos']) for x in rs)[math.ceil(34*q)-1]==m[n]
 for x,y in zip(rs,ref):
  diff={k:[y[k],x[k]] for k in x if k!='latencyNanos' and x[k]!=y[k]}
  if diff:refdiff.append({'run':label,'id':x['id'],'differences':diff})
 allRows[label]=rs;metrics[label]=m;resources[label]={'primaryMetric':j['primaryMetric'],'allSecondaryMetrics':j['secondaryMetrics'],'command':expected,'pid':c['pid'],'group':group,'position':position,'q5':rs[4]}
 for path in [Path(str(prefix)+'.tsv'),Path(str(prefix)+'.json')]:hashes[str(path)]=sha(path)
comparisons={}
for name,base,cand in COMPS:
 target=D/name;g=read(target/'status.json');cmd=read(target/'command.json');orders=['base-candidate' if x.index(base)<x.index(cand) else 'candidate-base' for x in ORDER]
 expected=[cmd[0],str(COMPARATOR),'compare-global-wide-pressure']
 for opt,version,ext in [('bases',base,'json'),('candidates',cand,'json'),('base-observations',base,'tsv'),('candidate-observations',cand,'tsv')]:expected+=['--'+opt,','.join(str(D/f'{version}-global-wide-{i}.{ext}') for i in [1,2,3])]
 expected+=['--run-orders',','.join(orders),'--graph-manifest',str(MANIFEST),'--correctness-oracle',str(ORACLE),'--minimum-speedup','10','--regression-only','--report',str(target/'report.md'),'--status',str(target/'status.json')];assert cmd==expected
 outcome=r['comparisonResults'][name];assert outcome=={'base':base,'candidate':cand,'runOrders':orders,'exitCode':0 if g['passed'] else 1,'status':g}
 remapRows={f'{side}-global-wide-{i}':allRows[f'{version}-global-wide-{i}'] for side,version in [('base',base),('candidate',cand)] for i in [1,2,3]};remapMetrics={f'{side}-global-wide-{i}':metrics[f'{version}-global-wide-{i}'] for side,version in [('base',base),('candidate',cand)] for i in [1,2,3]}
 comparisons[name]=recompute(g,orders,remapRows,remapMetrics)
 for p in [target/'command.json',target/'status.json']:hashes[str(p)]=sha(p)
for p,h in r['outputHashes'].items():assert sha(Path(p))==h,p
for p in [D/'run.json',ROOT/'run.py',REF,ORACLE,MANIFEST,Path(__file__)]:hashes[str(p)]=sha(p)
result={'status':'passed-independent-evidence-audit','accepted':False,'uniqueFull14QueryOutputs':306,'uniqueForks':9,'pairwiseReports':3,'comparisonObservationsAreShared':True,'allNineExactCommandsNormalDrains':True,'sourceSmallPinsReread':smallPins,'largePinsBoundToTerminalReceiptsOnly':largePins,'allReferenceNonTimeDifferences':refdiff,'resourcesByFork':resources,'comparisons':comparisons,'inputHashes':hashes}
(O/'post-audit.json').write_text(json.dumps(result,indent=2)+'\n');print('PASS306 full14/9forks/3comparators')
for name,x in comparisons.items():print(name,'regression',x['regressionPassed'],'target',x['targetAchieved'],'P95',[p['metrics']['p95Speedup'] for p in x['pairs']],'flags',x['repeatedFlags'])
