from pathlib import Path
import json,hashlib,collections,csv
O=Path(__file__).resolve().parent;D=O.parent/'existing-native-q5';H=Path('/private/tmp/graphite-sparse-native-stacks.kpkcdzsl');A=H/'analysis';B=Path('/private/tmp/graphite-sparse-initial-boundaries.tuo31r0x');pins={}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):pins[str(p)]=sha(p);return json.loads(p.read_text())
r=read(D/'result.json');old=read(A/'receipt.json');capture=read(H/'original34-currentpr-pairs/run.json');build=read(B/'build-receipt.json');assert old['status']=='complete' and old['fullOracleAndBoundaries']==204 and old['privateGroupsDrained']==12;assert capture['status']=='complete' and capture['inputsUnchanged'] and capture['graphInputsUnchanged'];assert build['status']=='complete' and build['inputsUnchanged']
base=build['jarOutputs']['base'];assert base['originalSha256']=='04ae90ec1f5560aa54f491a747e651c2f7b44ff453e169c9f2e8bb9fa9570814' and base['sha256']=='f5f651977485ae0c4fbe240a0ff9339e8724b614517bc36547d156f42c53e6ce';assert capture['inputHashesBefore'][base['path']]==capture['inputHashesAfter'][base['path']]==base['sha256']
JAVA={'Interpreted','JIT compiled','Inlined','C1 compiled'};out=[]
for x in r['runs']:
 label=x['label'];report=A/'results'/f'{label}.json';p=read(report);assert pins[str(report)]==old['files'][str(report.relative_to(A))]['sha256'];q=p['queries'][4];assert q==x['query'] and q['id']=='global-wide-class-pair-targeted' and q['ordinal']==5
 cmd=next(c for c in capture['commands'] if c['id']==label);assert cmd['command'][3]==base['path'] and cmd['exitCode']==0 and cmd['processGroupCleanup']['drained'];assert p['launcherPid']==cmd['pid']
 assert len(p['jvmInformation'])==1 and p['jvmInformation'][0]['fields']['pid']==p['pid']==x['pid']
 settings=p['settings']['values'];assert settings['version']==['4.3'] and settings['engine']==['wall'] and settings['clock']==['monotonic'] and settings['event']==['wall'] and settings['interval']==['1000000'] and settings['jstackdepth']==['128'];assert all(h['ticksPerSecond']==1000000000 for h in p['headers'])
 file=D/f'{label}-q5-samples.jsonl';pins[str(file)]=sha(file);samples=[json.loads(z) for z in file.read_text().splitlines()];assert len(samples)==x['selectedWith2msEdges'];assert len({z['eventOrdinal'] for z in samples})==len(samples)
 assert all(q['startNanos']-2000000<=z['startTicks']<=q['finishNanos']+2000000 for z in samples)
 bands={}
 for b in [0,1,2]:
  radius=b*1000000;s=q['startNanos'];f=q['finishNanos'];inner=[z for z in samples if s+radius<=z['startTicks']<=f-radius];edge=[z for z in samples if s-radius<=z['startTicks']<=f+radius and not(s+radius<=z['startTicks']<=f-radius)]
  assert len(inner)==x['bands'][str(b)]['interiorSamples']==q['bandsMillis'][str(b)]['interior']['sampleCount'];assert len(edge)==x['bands'][str(b)]['edgeSamples']==q['bandsMillis'][str(b)]['edge-ambiguous']['sampleCount']
  methods=collections.Counter();threads={};appCount=0;groups=collections.Counter(z['group'] for z in inner)
  for z in inner:
   frames=(z.get('stack') or {}).get('frames',[]);jf=[v for v in frames if v.get('type') in JAVA];app=[v for v in jf if (v.get('class') or '').startswith('io.johnsonlee.graphite.')];tid=z['thread']['osThreadId'];assert type(tid) is int and tid>0
   t=threads.setdefault(str(tid),{'thread':z['thread'],'samples':0,'states':collections.Counter(),'firstJavaFrames':collections.Counter(),'applicationSamples':0,'waitKinds':collections.Counter()});t['samples']+=1;t['states'][z['state']]+=1;t['waitKinds'][str(z['waitKind'])]+=1
   if jf:t['firstJavaFrames'][jf[0]['class']+'.'+jf[0]['method']+' ['+jf[0]['type']+']']+=1
   if app:
    appCount+=1;t['applicationSamples']+=1;methods.update(set(v['class']+'.'+v['method'] for v in app))
  assert threads==x['bands'][str(b)]['threads'] and dict(methods)==x['bands'][str(b)]['inclusiveApplicationMethodSampleCounts'] and appCount==x['bands'][str(b)]['uniqueApplicationSamples']
  assert dict(groups)==q['bandsMillis'][str(b)]['interior']['mutuallyExclusiveGroups']
  bands[str(b)]={'interior':len(inner),'edge':len(edge),'graphiteFrameUnionIncludingWaitAndSampler':appCount,'validInnerNanos':max(0,f-s-2*radius),'exclusiveGroups':dict(groups),'viewMethodSamples':{k:v for k,v in methods.items() if 'MappedCallSiteStringIndexView' in k},'resourceSamplerSamples':sum(1 for z in inner if any('BroadQueryResourceSampler' in (v.get('class') or '') for v in (z.get('stack') or {}).get('frames',[]))}
 # Full14 match current official maintained, timings remain historical.
 sig='id family shape selectivity operator boundary projection targetGraphId workloadIdentity limit outcome rowCount responseBytes digest'.split();g=int(label.rsplit('-',1)[1]);oldTsv=H/'original34-currentpr-pairs'/f'{label}.tsv';newTsv=O.parent/'original34'/f'official-global-wide-{g}.tsv';a=list(csv.DictReader(oldTsv.open(),delimiter='\t'))[4];b=list(csv.DictReader(newTsv.open(),delimiter='\t'))[4];assert all(a[k]==b[k] for k in sig) and int(a['latencyNanos'])==q['latencyNanos'];pins[str(oldTsv)]=sha(oldTsv);pins[str(newTsv)]=sha(newTsv)
 out.append({'label':label,'historicalPid':x['pid'],'historicalLatencyNanos':q['latencyNanos'],'bands':bands,'selectedSamples':len(samples)})
for p in [D/'extract.py',A/'native_common.py',Path(__file__)]:pins[str(p)]=sha(p)
result={'status':'passed-small-extraction-review','productionOrJavaExecuted':False,'lineage':base,'runs':out,'limits':['Only historical official04ae-derived boundary-instrumented f5f651 capture, never currenthelper177d or startingmain.','Native wall+LogCompilation+time-anchor instrumentation present; previous sampled q5timings not substituted for currentunobserved triples.','Recomputed selectedallthread0/1/2ms counts, firstJavaframes, OSidentities and inclusive dedupcounts; original large samplesJSONL SHA/provenance bound via completed extractor+oldreceipt, not independently rehashed here.','Application-named counter includes scheduler wait/caller/JMH/resourceSampler because it means anyGraphiteJavaframe, not querywork or CPU.','Method counters collapse overload descriptors byclass+method; full selectedframes retain descriptors/type/position.','Operational edge bands not clock-error bounds; 0ms not unambiguous, intervals do not imply exactactive time.','Inclusive schedulerframes and native GCthreads are not CPUcost or GCpause proof; defaultJIT labels notC2.'],'inputHashes':pins}
(O/'native-q5-review.json').write_text(json.dumps(result,indent=2)+'\n');print('Native q5selectedrecords/bands/threads/method unions match; noJVM')
