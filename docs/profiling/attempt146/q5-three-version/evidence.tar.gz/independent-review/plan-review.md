# Three-version original34 attribution plan: independent review

The proposed fixed nine-fork experiment is a useful bounded comparison. It brings frozen starting main, official PR, and the helper cancellation fix into the same batch, addressing a specific limitation of the previous separate comparisons. It is diagnostic evidence, not CI acceptance or a mechanism proof.

The production JAR identities must remain frozen: main a5c2db2b…, official 04ae90ec…, helper 177d9c15…. Each version receives three fresh original-JMH forks, every fork retains all 34 queries and the original prefix, 0 warmup / one measurement / one fork, 8g/P4, existing gc profiler/resource sampler and full 14-field oracle. No new query observer, selective warmup, reordered query, changed classpath payload or changed production/JMH body is needed.

## What the design controls and leaves open

The Latin order `[main,official,helper]`, `[official,helper,main]`, `[helper,main,official]` balances each version across within-group positions 1/2/3. Same-group pairwise results can contrast main→official with official→helper and main→helper. This is stronger than joining separate historical batches.

Three groups remain a small sample. The cyclic order is not all six permutations and does not fully balance predecessor/host-cache/thermal effects. Fresh JVMs remove same-JVM cross-version JIT sharing, but host state can persist. A pair can have the third version between its two measurements; record the full group order, absolute fork positions and intervening fork explicitly. Do not describe all pairs as adjacent or fully counterbalanced. No need to expand the fixed design after looking at outcomes.

Original comparator directions, using baseline→candidate for each pair, must be:

| Comparison | Group1 | Group2 | Group3 |
|---|---|---|---|
| main→official | base-candidate | candidate-base | base-candidate |
| main→helper | base-candidate | candidate-base | candidate-base |
| official→helper | base-candidate | base-candidate | candidate-base |

Keep the complete nine-fork order in the receipt because these two-label order strings omit intervening versions. The same fork legitimately appears in two pairwise reports; there are **306 unique query outputs**, not 612 independent outputs. All three comparator reports share observations and are not independent experiments. Use separate comparator output/status paths so no comparison overwrites another.

Retain original comparator code, thresholds, all34 shape/selectivity flags, global/wrapped P50/P95, process CPU and resource metrics. Nearest-rank P95 uses rank33 of34. Main remains the 10× target reference. Running the same comparator against official→helper must not redefine the final target as official or imply a CI pass. Resource sampler/full-replay CPU includes work between individual query timers; it is not per-q5 CPU. Missing metrics stay unavailable, never zero. Three observations are not a per-query P95.

## Existing q5 evidence and its limits

q5 is `global-wide-class-pair-targeted`, ordinal5, with one raw CONTAINS term ORed across caller_class/caller_name/callee_class/callee_name; RETURN projects caller_class/callee_class, LIMIT200. It is not a two-class AND or a multi-keyword query. Earlier local outputs returned one row, 2674 work units and identical complete non-time fields.

The prior helper→official comparison had no repeated q5 flag (base→helper 4.972→5.113, 4.981→5.045, 5.400→5.236ms). The separate frozen-main→helper batch flagged q5 twice (4.507→5.009, 4.264→5.527, 4.373→5.696ms). Historical official5e052 Linux CI flagged q5 twice versus then-current main847c, but not versus frozen main4e328 in the inspected batch. Linux-built artifacts are not asserted byte-identical to the local JARs. Those records cannot establish that the helper introduced the current difference, nor exclude that possibility; they do not waive any failed gate.

Source review finds q5 can take the balanced mapped-view ordinary-row route and reach exact-ID/posting operations using `checkViewInterrupted`. Cache state, absent trigrams, posting-mask alignment and actual nonempty cursors determine whether and how often the changed guard executes. Zero legacy indexLookup/parallelScan counters do not exclude mapped lookup or graph tasks. Equal work counters do not establish equal instructions, JIT shape or waiting. This uninstrumented experiment still will not measure actual guard counts or attribute CPU/waiting.

Interpretation must remain symmetric: an official→helper slowdown in the same groups supports an incremental artifact-level difference worthy of investigating; a main→official difference with a small official→helper contrast supports a pre-existing branch-level difference within this batch. Neither pattern alone proves the responsible function or eliminates host variation. If prior failures do not recur, call them unreproduced here, not resolved. All full34 flags remain, irrespective of q5.

## Required runner and final audit checks

Before execution, inspect actual source against the frozen original34 runner, validate all nine exact commands/JAR mappings and original JMH settings, bind source/build/class-scope/oracle/fixture/comparator pins, reject JVM environment injection, and use owned private process groups with real drain before subsequent measurement/final hashing. Preserve original failure logs and never treat incomplete forks as comparison data. Do not run this diagnostic concurrently with another measurement/build owned by the parent.

After parent-confirmed terminal completion, independently verify nine original34 output schemas/orders and all 306 full14 signatures; validate original JMH JSON arguments, one measurement, raw resources and exact commands/normal exits. Recompute all non-time differences and all three pairwise comparator reports with their actual order strings, retaining per-pair ratios/flags and common fork identities. No selective removal or replacement of a pair after observing results.

This review covers the proposed plan only. The runner had not yet been written when reviewed; executable protocol approval and result audit remain separate pending steps. No JVM or benchmark was launched and no frozen source was modified.
