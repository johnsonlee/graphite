### 64 fixture-derived global wide-query pressure gate

Evaluation: **non-regression**
P95 target in every independent paired fork: **10.0x**
Regression checks: **PASS**; target achieved: **NO**
Target remains unmet; a passing regression evaluation does not establish the speedup target.
pair-1: P95 speedup 1.35x; required 10.00x in every independent fork
pair-1: global-wide-wrapped-case-insensitive P95 speedup 0.84x; required 10.00x
pair-1: global-wide-wrapped-case-insensitive-distinct P95 speedup 1.35x; required 10.00x
pair-2: P95 speedup 0.90x; required 10.00x in every independent fork
pair-2: global-wide-wrapped-case-insensitive P95 speedup 0.95x; required 10.00x
pair-2: global-wide-wrapped-case-insensitive-distinct P95 speedup 0.90x; required 10.00x
pair-3: P95 speedup 0.91x; required 10.00x in every independent fork
pair-3: global-wide-wrapped-case-insensitive P95 speedup 0.83x; required 10.00x
pair-3: global-wide-wrapped-case-insensitive-distinct P95 speedup 0.91x; required 10.00x

- Worst paired base P50 / P95: **1.995 ms / 40.624 ms**
- Worst paired candidate P50 / P95: **2.481 ms / 45.167 ms**
- Worst individual P95 speedup (retained for audit): **0.90x**
- Worst wrapped case-insensitive P95 speedup: **0.83x**
- Worst order-median P95 speedup: **0.91x**
- candidate-base: **2 pair(s), 0.77x P50 / 0.91x P95**
- base-candidate: **1 pair(s), 0.79x P50 / 1.35x P95**

| Pair | Order | Base P50 | Base P95 | Candidate P50 | Candidate P95 | P50 speedup | P95 speedup | CPU total | CPU cores | Heap | RSS |
| ---: | :--- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 1 | base-candidate | 1.904 ms | 57.346 ms | 2.397 ms | 42.322 ms | 0.79x | 1.35x | 1531.663 ms → 1653.498 ms | 3.20 | 4.05 GiB → 4.38 GiB | 4.57 GiB → 4.90 GiB |
| 2 | candidate-base | 1.995 ms | 40.624 ms | 2.481 ms | 45.167 ms | 0.80x | 0.90x | 1489.344 ms → 1653.044 ms | 3.20 | 4.38 GiB → 4.39 GiB | 4.90 GiB → 4.90 GiB |
| 3 | candidate-base | 1.769 ms | 39.564 ms | 2.414 ms | 43.252 ms | 0.73x | 0.91x | 1433.570 ms → 1614.055 ms | 3.17 | 4.01 GiB → 4.38 GiB | 4.58 GiB → 4.90 GiB |

**Result: PASS**
