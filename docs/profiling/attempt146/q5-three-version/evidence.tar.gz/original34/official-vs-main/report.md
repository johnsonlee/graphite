### 64 fixture-derived global wide-query pressure gate

Evaluation: **non-regression**
P95 target in every independent paired fork: **10.0x**
Regression checks: **FAIL**; target achieved: **NO**
Target remains unmet; a passing regression evaluation does not establish the speedup target.
pair-1: P95 speedup 0.87x; required 10.00x in every independent fork
pair-1: global-wide-wrapped-case-insensitive P95 speedup 0.83x; required 10.00x
pair-1: global-wide-wrapped-case-insensitive-distinct P95 speedup 0.87x; required 10.00x
pair-2: P95 speedup 1.04x; required 10.00x in every independent fork
pair-2: global-wide-wrapped-case-insensitive P95 speedup 0.97x; required 10.00x
pair-2: global-wide-wrapped-case-insensitive-distinct P95 speedup 1.04x; required 10.00x
pair-3: P95 speedup 0.83x; required 10.00x in every independent fork
pair-3: global-wide-wrapped-case-insensitive P95 speedup 0.83x; required 10.00x
pair-3: global-wide-wrapped-case-insensitive-distinct P95 speedup 0.83x; required 10.00x

- Worst paired base P50 / P95: **1.769 ms / 39.564 ms**
- Worst paired candidate P50 / P95: **2.479 ms / 47.507 ms**
- Worst individual P95 speedup (retained for audit): **0.83x**
- Worst wrapped case-insensitive P95 speedup: **0.83x**
- Worst order-median P95 speedup: **0.85x**
- candidate-base: **1 pair(s), 0.88x P50 / 1.04x P95**
- base-candidate: **2 pair(s), 0.79x P50 / 0.85x P95**

| Pair | Order | Base P50 | Base P95 | Candidate P50 | Candidate P95 | P50 speedup | P95 speedup | CPU total | CPU cores | Heap | RSS |
| ---: | :--- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 1 | base-candidate | 1.904 ms | 57.346 ms | 2.219 ms | 65.539 ms | 0.86x | 0.87x | 1531.663 ms → 1812.636 ms | 3.39 | 4.05 GiB → 4.39 GiB | 4.57 GiB → 4.90 GiB |
| 2 | candidate-base | 1.995 ms | 40.624 ms | 2.263 ms | 39.107 ms | 0.88x | 1.04x | 1489.344 ms → 1595.452 ms | 3.17 | 4.38 GiB → 4.38 GiB | 4.90 GiB → 4.91 GiB |
| 3 | base-candidate | 1.769 ms | 39.564 ms | 2.479 ms | 47.507 ms | 0.71x | 0.83x | 1433.570 ms → 1672.128 ms | 3.24 | 4.01 GiB → 4.39 GiB | 4.58 GiB → 4.89 GiB |

**Result: FAIL**

pair-1: process CPU 1812636000 exceeds paired base 1531663000 by >15%
pair-3: process CPU 1672128000 exceeds paired base 1433570000 by >15%
pair-1/global-wide-wrapped-case-insensitive-distinct/targeted: aligned latency 38277917 exceeds base 28635834 by >15% and >1 ms; repeated in 2 independent pairs
