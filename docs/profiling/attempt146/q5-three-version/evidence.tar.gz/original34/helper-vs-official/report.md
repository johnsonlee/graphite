### 64 fixture-derived global wide-query pressure gate

Evaluation: **non-regression**
P95 target in every independent paired fork: **10.0x**
Regression checks: **PASS**; target achieved: **NO**
Target remains unmet; a passing regression evaluation does not establish the speedup target.
pair-1: P95 speedup 1.55x; required 10.00x in every independent fork
pair-1: global-wide-wrapped-case-insensitive P95 speedup 1.02x; required 10.00x
pair-1: global-wide-wrapped-case-insensitive-distinct P95 speedup 1.55x; required 10.00x
pair-2: P95 speedup 0.87x; required 10.00x in every independent fork
pair-2: global-wide-wrapped-case-insensitive P95 speedup 0.98x; required 10.00x
pair-2: global-wide-wrapped-case-insensitive-distinct P95 speedup 0.87x; required 10.00x
pair-3: P95 speedup 1.10x; required 10.00x in every independent fork
pair-3: global-wide-wrapped-case-insensitive P95 speedup 1.01x; required 10.00x
pair-3: global-wide-wrapped-case-insensitive-distinct P95 speedup 1.10x; required 10.00x

- Worst paired base P50 / P95: **2.263 ms / 39.107 ms**
- Worst paired candidate P50 / P95: **2.481 ms / 45.167 ms**
- Worst individual P95 speedup (retained for audit): **0.87x**
- Worst wrapped case-insensitive P95 speedup: **0.87x**
- Worst order-median P95 speedup: **1.10x**
- candidate-base: **1 pair(s), 1.03x P50 / 1.10x P95**
- base-candidate: **2 pair(s), 0.92x P50 / 1.21x P95**

| Pair | Order | Base P50 | Base P95 | Candidate P50 | Candidate P95 | P50 speedup | P95 speedup | CPU total | CPU cores | Heap | RSS |
| ---: | :--- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 1 | base-candidate | 2.219 ms | 65.539 ms | 2.397 ms | 42.322 ms | 0.93x | 1.55x | 1812.636 ms → 1653.498 ms | 3.20 | 4.39 GiB → 4.38 GiB | 4.90 GiB → 4.90 GiB |
| 2 | base-candidate | 2.263 ms | 39.107 ms | 2.481 ms | 45.167 ms | 0.91x | 0.87x | 1595.452 ms → 1653.044 ms | 3.20 | 4.38 GiB → 4.39 GiB | 4.91 GiB → 4.90 GiB |
| 3 | candidate-base | 2.479 ms | 47.507 ms | 2.414 ms | 43.252 ms | 1.03x | 1.10x | 1672.128 ms → 1614.055 ms | 3.17 | 4.39 GiB → 4.38 GiB | 4.89 GiB → 4.90 GiB |

**Result: PASS**
