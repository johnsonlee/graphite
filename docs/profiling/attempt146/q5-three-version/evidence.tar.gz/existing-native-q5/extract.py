"""Reuse only completed official-PR native captures. No JVM, profiler or production edit."""
from pathlib import Path
import sys,json,re,hashlib,collections,csv
D=Path(__file__).resolve().parent;H=Path('/private/tmp/graphite-sparse-native-stacks.kpkcdzsl');A=H/'analysis';sys.path.insert(0,str(A))
from native_common import query_relation,JAVA_TYPES
read=lambda p:json.loads(p.read_text())
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
receipt=read(A/'receipt.json');assert receipt['status']=='complete' and receipt['privateGroupsDrained']==12 and receipt['fullOracleAndBoundaries']==204
current=read(D.parent/'original34/run.json');assert current['status']=='complete' and len(current['completed'])==9
assert all(c['exitCode']==0 and c['processGroupCleanup']['drained'] for c in current['commands'])
pins={str(A/'receipt.json'):sha(A/'receipt.json'),str(A/'native_common.py'):sha(A/'native_common.py'),str(Path(__file__)):sha(Path(__file__))};runs=[]
pattern=re.compile(rb'^\{"eventOrdinal":(\d+),"startTicks":(\d+),')
for group in (1,2,3):
 label=f'base-global-wide-{group}';report=A/f'results/{label}.json';assert sha(report)==receipt['files'][str(report.relative_to(A))]['sha256'];pins[str(report)]=sha(report);r=read(report);q=r['queries'][4];assert q['ordinal']==5 and q['id']=='global-wide-class-pair-targeted'
 oldobs=H/f'original34-currentpr-pairs/{label}.tsv';old=list(csv.DictReader(oldobs.open(),delimiter='\t'))[4]
 newobs=D.parent/f'original34/official-global-wide-{group}.tsv';new=list(csv.DictReader(newobs.open(),delimiter='\t'))[4]
 signature='id family shape selectivity operator boundary projection targetGraphId workloadIdentity limit outcome rowCount responseBytes digest'.split()
 assert all(old[k]==new[k] for k in signature) and int(old['latencyNanos'])==q['latencyNanos']
 pins[str(oldobs)]=sha(oldobs);selected=[];source=A/f'results/{label}.samples.jsonl';digest=hashlib.sha256();lines=0
 with source.open('rb') as f:
  for line in f:
   digest.update(line);lines+=1;m=pattern.match(line);assert m,'Unexpected source schema'
   tick=int(m[2])
   if q['startNanos']-2_000_000<=tick<=q['finishNanos']+2_000_000:
    x=json.loads(line);assert x['startTicks']==tick and x['eventOrdinal']==int(m[1]);selected.append(x)
 actual=digest.hexdigest();expected=receipt['files'][str(source.relative_to(A))];assert actual==expected['sha256'] and source.stat().st_size==expected['bytes'];pins[str(source)]=actual
 with (D/(label+'-q5-samples.jsonl')).open('x') as f:
  for x in selected:f.write(json.dumps(x,separators=(',',':'))+'\n')
 bands={}
 for band in (0,1,2):
  interior=[x for x in selected if query_relation(x['startTicks'],q,band*1_000_000)=='interior'];edge=[x for x in selected if query_relation(x['startTicks'],q,band*1_000_000)=='edge-ambiguous']
  assert len(interior)==q['bandsMillis'][str(band)]['interior']['sampleCount'];assert len(edge)==q['bandsMillis'][str(band)]['edge-ambiguous']['sampleCount']
  methods=collections.Counter();bythread={};applications=[]
  for x in interior:
   frames=(x.get('stack') or {}).get('frames',[]);java=[f for f in frames if f.get('type') in JAVA_TYPES];app=[f for f in java if (f.get('class') or '').startswith('io.johnsonlee.graphite.')]
   identity=str(x['thread']['osThreadId']);t=bythread.setdefault(identity,{'thread':x['thread'],'samples':0,'states':collections.Counter(),'firstJavaFrames':collections.Counter(),'applicationSamples':0,'waitKinds':collections.Counter()});t['samples']+=1;t['states'][x['state']]+=1;t['waitKinds'][str(x['waitKind'])]+=1
   if java:t['firstJavaFrames'][java[0]['class']+'.'+java[0]['method']+' ['+java[0]['type']+']']+=1
   if app:
    t['applicationSamples']+=1;applications.append(x['eventOrdinal'])
    for name in set(f['class']+'.'+f['method'] for f in app):methods[name]+=1
  bands[str(band)]={'interiorSamples':len(interior),'edgeSamples':len(edge),'uniqueApplicationSamples':len(applications),'inclusiveApplicationMethodSampleCounts':dict(methods.most_common()),'threads':bythread}
 runs.append({'label':label,'pid':r['pid'],'query':q,'queryIdentity':old['workloadIdentity'],'sourceSampleFile':str(source),'sourceLines':lines,'sourceSHA256':actual,'selectedWith2msEdges':len(selected),'bands':bands})
 print(label,'q5ms',q['latencyNanos']/1e6,'applicationMethods1ms',list(bands['1']['inclusiveApplicationMethodSampleCounts'].items())[:12],flush=True)
result={'status':'completed-existing-data-extraction','captureVersions':'Only official04ae producer lineage in the prior native diagnostic; not starting main or current helper177d. Original benchmark contained time-anchor instrumentation and native wall/LogCompilation observers.','productionOrJVMExecuted':False,'runs':runs,'inputHashes':pins,'limitations':['Historical sampled q5 timings cannot replace this new uninstrumented three-version comparison or assign its latency deltas to the old stacks.','All original q5 14-field identities match current official observations; capture PIDs and windows are historical.','Native wall samples are not CPU, waiting samples are not exact wait durations, default JIT labels are not C2.','All threads and unknown/native/GC/compiler states retained; inclusive application method counts overlap. No causal attribution from sample counts.','Only three official historical captures are selected, predeclared before extraction; no candidate samples used to claim current helper behavior.']}
(D/'result.json').write_text(json.dumps(result,indent=2)+'\n')
print('completed')
