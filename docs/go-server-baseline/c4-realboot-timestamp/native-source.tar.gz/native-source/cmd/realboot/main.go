package main

import (
	"encoding/json"
	"fmt"
	"github.com/johnsonlee/graphite/graphite-server/internal/analysis/c4"
	"github.com/johnsonlee/graphite/graphite-server/internal/store"
	"os"
	"path/filepath"
)

func must(err error) {
	if err != nil {
		panic(err)
	}
}
func write(path string, v any) {
	b, e := json.MarshalIndent(v, "", "  ")
	must(e)
	must(os.WriteFile(path, append(b, '\n'), 0600))
}
func main() {
	for _, mode := range []string{"MAPPED", "EAGER"} {
		g, e := store.OpenMode(os.Args[1], mode)
		must(e)
		defer g.Close()
		dir := filepath.Join(os.Args[2], mode)
		must(os.MkdirAll(dir, 0700))
		resources, e := g.ResourceList("**")
		must(e)
		write(filepath.Join(dir, "stats.json"), map[string]any{"nodes": g.NodeCount, "edges": g.EdgeCount, "methods": len(g.Metadata.MethodList), "callSites": len(g.NodesOfKind("CallSiteNode")), "classOrigins": g.Metadata.ClassOrigins, "manifest": c4.ReadManifest(g), "resources": resources})
		for _, level := range []string{"all", "context", "container", "component"} {
			m, e := c4.BuildModel(g, level)
			must(e)
			write(filepath.Join(dir, level+".json"), m)
			for format, render := range map[string]func(map[string]any) (string, error){"mermaid": c4.RenderMermaid, "plantuml": c4.RenderPlantUML, "dsl": c4.RenderStructurizrDSL} {
				s, e := render(m)
				must(e)
				must(os.WriteFile(filepath.Join(dir, level+"."+format), []byte(s), 0600))
			}
		}
		fmt.Println(mode, "nodes", g.NodeCount, "methods", len(g.Metadata.MethodList))
	}
}
