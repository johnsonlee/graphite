workspace "Graphite C4 Workspace" {
    model {
        g_system_subject = softwareSystem "Subject" "Derived from the Graphite code graph"
        g_dependency_runtime_java = softwareSystem "Java Runtime" "External dependency inferred from code graph evidence"
        g_dependency_artifact_spring_jcl_5_1_14_release = softwareSystem "spring-jcl-5.1.14.RELEASE" "External dependency inferred from code graph evidence"
        g_dependency_artifact_spring_boot_2_1_13_release = softwareSystem "spring-boot-2.1.13.RELEASE" "External dependency inferred from code graph evidence"
        g_dependency_artifact_spring_core_5_1_14_release = softwareSystem "spring-core-5.1.14.RELEASE" "External dependency inferred from code graph evidence"
    }
    views {
        container g_system_subject "graphite-container" {
            include *
            autolayout tb
        }
        theme default
    }
}