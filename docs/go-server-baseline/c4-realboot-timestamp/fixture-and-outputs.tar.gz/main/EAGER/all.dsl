workspace "Graphite C4 Workspace" {
    model {
        g_person_host_applications = person "Host Applications" "Applications or services that embed and invoke the library"
        g_system_library = softwareSystem "Task Library" "A reusable library artifact inferred from the analyzed code graph"
        g_dependency_library_spring = softwareSystem "spring" "Reusable third-party library capabilities referenced from the subject system"
        g_dependency_runtime_java = softwareSystem "Java Runtime" "Language and platform runtime supporting the application and its libraries"
        g_dependency_artifact_spring_jcl_5_1_14_release = softwareSystem "spring-jcl-5.1.14.RELEASE" "External dependency inferred from code graph evidence"
        g_dependency_artifact_spring_boot_2_1_13_release = softwareSystem "spring-boot-2.1.13.RELEASE" "External dependency inferred from code graph evidence"
        g_dependency_artifact_spring_core_5_1_14_release = softwareSystem "spring-core-5.1.14.RELEASE" "External dependency inferred from code graph evidence"
        g_person_host_applications -> g_system_library "Uses Task Library from a host application context"
        g_system_library -> g_dependency_library_spring "Task Library uses spring"
        g_dependency_library_spring -> g_dependency_runtime_java "spring runs on Java Runtime"
    }
    views {
        systemContext g_system_library "graphite-context" {
            include *
            autolayout tb
        }
        container g_system_library "graphite-container" {
            include *
            autolayout tb
        }
        theme default
    }
}