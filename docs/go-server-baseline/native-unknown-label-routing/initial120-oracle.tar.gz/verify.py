"""Verify complete original-JVM responses, label order and explicit fixture mutations."""
from pathlib import Path
import collections
import gzip
import hashlib
import json

here=Path(__file__).resolve().parent
def compressed(name):return json.loads(gzip.decompress((here/name).read_bytes()))
cases=json.loads((here/"cases.json").read_text());main=json.loads((here/"main.json").read_text());repeat=compressed("repeat-main.json.gz")
assert len(cases)==len(main)==len(repeat)==120
assert len({case["name"] for case in cases})==120
assert cases[:114]==compressed("initial114-cases.json.gz")
fields=["name","spec","phase","outcome","columns","rows","types","error","qualifiedError","message","before","after"]
for spec,left,right in zip(cases,main,repeat):
    assert left["spec"]==spec and right["spec"]==spec
    for field in fields:assert left.get(field)==right.get(field),(spec["name"],field)
    assert left["phase"]=="execute"
by_name={row["name"]:row for row in main}
def bad_tag(name):
    row=by_name[name];assert row["error"]=="IllegalArgumentException" and row["message"]=="Unknown node tag: -1"
for cross in [False,True]:
    assert by_name[f"label-0-bad0-cross{cross}"]["rows"]==[]
    bad_tag(f"label-1-bad0-cross{cross}")
    assert by_name[f"label-2-bad0-cross{cross}"]["rows"]==[]
    bad_tag(f"label-5-bad24-cross{cross}")
    assert by_name[f"label-6-bad24-cross{cross}"]["rows"]==[]
    for label in [7,8,9]:
        for node in [0,24]:assert by_name[f"label-{label}-bad{node}-cross{cross}"]["rows"]==[]
    for predicate in [0,1]:assert by_name[f"predicate-order-{predicate}-cross{cross}"]["rows"]==[]
    bad_tag(f"predicate-order-2-cross{cross}")
for scoped in [False,True]:
    for selected in ["good","bad"]:
        bad_tag(f"scope-IntConstant-Missing-{selected}-{scoped}")
        assert by_name[f"scope-Missing-IntConstant-{selected}-{scoped}"]["rows"]==[]
assert by_name["clauses-0-bad0"]["rows"]==[{"x":0}]
assert by_name["clauses-2-bad0"]["rows"]==[{"rows":1,"nodes":0}]
for clause in [7,9]:bad_tag(f"clauses-{clause}-bad0")
for clause in [8,10,13]:assert by_name[f"clauses-{clause}-bad0"]["rows"]==[]
assert by_name["clauses-14-bad0"]["message"]=="Requested element count -1 is less than zero."
assert by_name["clauses-15-bad0"]["error"]=="CypherException" and by_name["clauses-15-bad0"]["message"]=="Division by zero"
for relation in [1,2,3]:bad_tag(f"relations-{relation}-bad0")
source=json.loads((here/"source-fixture.json").read_text());source_by_name={entry["file"]:entry for entry in source["files"]}
for name,entry in source_by_name.items():
    file=Path(source["root"])/name
    assert file.stat().st_size==entry["bytes"] and hashlib.sha256(file.read_bytes()).hexdigest()==entry["sha256"]
audits=json.loads((here/"fixture-audit.json").read_text())
for index,audit in enumerate(audits):
    copied=compressed(f"run{index}-fixture-copied.json.gz");before=compressed(f"run{index}-fixture-before.json.gz")
    after=compressed(f"run{index}-fixture-after.json.gz");mutations=compressed(f"run{index}-mutations.json.gz")
    cm={entry["file"]:entry for entry in copied};bm={entry["file"]:entry for entry in before};am={entry["file"]:entry for entry in after}
    assert len(cm)==len(bm)==1850 and len(am)==2220 and len(mutations)==77
    for file,entry in cm.items():
        reference=source_by_name[Path(file).name]
        assert entry["bytes"]==reference["bytes"] and entry["sha256"]==reference["sha256"]
    changed={file for file in cm if cm[file]!=bm[file]}
    assert changed=={mutation["file"] for mutation in mutations}
    for mutation in mutations:
        node=mutation["nodeID"];offset,tag_at,old_tag={0:(8,12,0),24:(233,237,12)}[node]
        assert (mutation["nodeDataRecordOffset"],mutation["tagByteOffset"],mutation["oldTag"])==(offset,tag_at,old_tag)
        assert mutation["indexTag"]==old_tag and mutation["newTag"]==255
        assert mutation["originalSha256"]==cm[mutation["file"]]["sha256"]
        assert mutation["mutatedSha256"]==bm[mutation["file"]]["sha256"]
    assert all(am.get(file)==entry for file,entry in bm.items())
    assert audit["changed"]==[] and audit["missing"]==[] and set(audit["added"])==am.keys()-bm.keys()
    assert all(Path(file).name in ["graph.nodeoffsets","graph.typeindex"] for file in audit["added"])
summary=dict(cases=120,actualMainCalls=240,repeatPublicAndStateDifferences=0,
             outcomes=dict(collections.Counter(row.get("error","SUCCESS") for row in main)),
             originalFixtureSourceFiles=len(source_by_name),physicalGraphCopiesPerRun=185,
             copiedFilesPerRun=1850,explicitMutatedFilesPerRun=77,runtimeChangedFilesPerRun=0,
             generatedSidecarsPerRun=370,performanceMeasurements=0)
(here/"verification.json").write_text(json.dumps(summary,indent=2)+"\n");print(json.dumps(summary,indent=2))
