module quotecheck

go 1.22
