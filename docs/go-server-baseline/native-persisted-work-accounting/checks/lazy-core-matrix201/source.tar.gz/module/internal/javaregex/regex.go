// Package javaregex implements Java Pattern-style whole-string matching in Go.
// Parsing and backtracking cooperate with context cancellation; no JVM is used.
package javaregex

import (
	"context"
	"fmt"
	"strings"
	"unicode/utf16"
	"unicode/utf8"
)

// SyntaxError carries Java PatternSyntaxException fields and message format.
type SyntaxError struct {
	Description, Pattern string
	Index                int
}

func (e *SyntaxError) Error() string {
	if e.Index < 0 {
		return e.Description + "\n" + e.Pattern
	}
	message := fmt.Sprintf("%s near index %d\n%s", e.Description, e.Index, e.Pattern)
	runes, _ := decodeJavaString(context.Background(), e.Pattern)
	if e.Index < javaIndex(runes, len(runes)) {
		var caret strings.Builder
		columns := 0
		for _, r := range runes {
			units := 1
			if r > 0xffff {
				units = 2
			}
			for i := 0; i < units && columns < e.Index; i++ {
				if r == '\t' {
					caret.WriteByte('\t')
				} else {
					caret.WriteByte(' ')
				}
				columns++
			}
			if columns == e.Index {
				break
			}
		}
		message += "\n" + caret.String() + "^"
	}
	return message
}

// UnsupportedError never silently substitutes a different regex dialect.
type UnsupportedError struct{ Feature string }

func (e *UnsupportedError) Error() string {
	return "Java regex feature is not implemented: " + e.Feature
}

type flags uint16

const (
	flagI flags = 1 << iota
	flagUCase
	flagUClass
	flagS
	flagM
	flagD
	flagX
	flagCanonical
)

type predicate func(rune) bool

type node struct {
	kind     byte
	children []*node
	pred     predicate
	literal  []rune
	flags    flags
	min, max int
	mode     byte
	group    int
	name     string
}

// Pattern is immutable after compilation and safe for concurrent matching.
type Pattern struct {
	source   string
	root     *node
	groups   int
	contains *quotedContains
}

func Compile(pattern string) (*Pattern, error) { return CompileContext(context.Background(), pattern) }
func CompileContext(ctx context.Context, pattern string) (*Pattern, error) {
	if err := ctx.Err(); err != nil {
		return nil, err
	}
	runes, err := decodeJavaString(ctx, pattern)
	if err != nil {
		return nil, err
	}
	runes, err = removeQEQuoting(ctx, runes)
	if err != nil {
		return nil, err
	}
	p := parser{ctx: ctx, source: pattern, input: runes, names: map[string]int{}}
	root, err := p.expression(false)
	if err != nil {
		return nil, err
	}
	if p.pos < len(p.input) {
		return nil, p.fail("Unmatched closing ')'", p.pos-1)
	}
	contains, err := compileQuotedContains(ctx, pattern)
	if err != nil {
		return nil, err
	}
	return &Pattern{source: pattern, root: root, groups: p.groups, contains: contains}, nil
}
func MatchesContext(ctx context.Context, pattern, text string) (bool, error) {
	p, err := CompileContext(ctx, pattern)
	if err != nil {
		return false, err
	}
	return p.MatchesContext(ctx, text)
}
func (p *Pattern) MatchesContext(ctx context.Context, text string) (bool, error) {
	if err := ctx.Err(); err != nil {
		return false, err
	}
	if p.contains != nil {
		matched, handled, err := p.contains.matches(ctx, text)
		if handled || err != nil {
			return matched, err
		}
	}
	runes, err := decodeJavaString(ctx, text)
	if err != nil {
		return false, err
	}
	m := matcher{ctx: ctx, text: runes}
	captures := make([]capture, p.groups+1)
	ok := m.match(p.root, state{captures: captures}, func(s state) bool { return s.pos == len(m.text) })
	if m.err != nil {
		return false, m.err
	}
	if err := ctx.Err(); err != nil {
		return false, err
	}
	return ok, nil
}
func javaIndex(runes []rune, end int) int {
	if end < 0 {
		return end
	}
	if end > len(runes) {
		end = len(runes)
	}
	n := 0
	for _, r := range runes[:end] {
		if utf16.IsSurrogate(r) || r < 0x10000 {
			n++
		} else {
			n += 2
		}
	}
	return n
}

// decodeJavaString accepts UTF-8 and WTF-8, preserving isolated Java UTF-16
// surrogates. Adjacent encoded high/low surrogate units form one code point,
// exactly as Character.codePointAt does after Java string concatenation.
func decodeJavaString(ctx context.Context, text string) ([]rune, error) {
	out := make([]rune, 0, len(text))
	for i := 0; i < len(text); {
		if len(out)&1023 == 0 {
			if err := ctx.Err(); err != nil {
				return nil, err
			}
		}
		r, size := decodeJavaRune(text[i:])
		i += size
		if r >= 0xD800 && r <= 0xDBFF && i < len(text) {
			low, n := decodeJavaRune(text[i:])
			if low >= 0xDC00 && low <= 0xDFFF {
				r = utf16.DecodeRune(r, low)
				i += n
			}
		}
		out = append(out, r)
	}
	return out, ctx.Err()
}
func decodeJavaRune(text string) (rune, int) {
	if len(text) >= 3 && text[0] == 0xED && text[1] >= 0xA0 && text[1] <= 0xBF && text[2]&0xC0 == 0x80 {
		return rune(text[0]&15)<<12 | rune(text[1]&63)<<6 | rune(text[2]&63), 3
	}
	return utf8.DecodeRuneInString(text)
}

func javaRunesString(runes []rune) string {
	var bytes []byte
	for _, r := range runes {
		if utf16.IsSurrogate(r) {
			bytes = append(bytes, byte(0xE0|r>>12), byte(0x80|r>>6&63), byte(0x80|r&63))
		} else {
			bytes = utf8.AppendRune(bytes, r)
		}
	}
	return string(bytes)
}
