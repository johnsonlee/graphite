import com.google.gson.*;
import it.unimi.dsi.util.FrontCodedStringList;
import it.unimi.dsi.fastutil.io.BinIO;
import java.nio.file.*;
import java.lang.reflect.*;
import java.util.*;
public class FindIdOracle {
 public static void main(String[]args)throws Exception{
  Class<?> type=Class.forName("io.johnsonlee.graphite.webgraph.StringTable");Object companion=type.getField("Companion").get(null);Method load=companion.getClass().getMethod("load",Path.class);Method find=Arrays.stream(type.getDeclaredMethods()).filter(m->m.getName().startsWith("findId")).findFirst().orElseThrow();
  List<List<String>> cases=List.of(List.of("a","a","a"),List.of("b","a"),List.of("","?","a","\ud800","\ud83d\ude00","\ue000"));
  cases=new ArrayList<>(cases);List<String> boundary=new ArrayList<>(List.of("", "\u0000", "A", "a", "aaa", "aa\u0000", "\ud7ff", "\ud800", "\udbff", "\udc00", "\udfff", "\ud83d\ude00", "\ue000", "\uffff"));Collections.sort(boundary);cases.add(boundary);
  for(int i=0;i<cases.size();i++){
   List<String> strings=cases.get(i);Path dir=Path.of(args[0],"table-"+i);Files.createDirectories(dir);BinIO.storeObject(new FrontCodedStringList(strings.iterator(),4,false),dir.resolve("graph.strings").toString());Object table=load.invoke(companion,dir);
   List<Map<String,Object>> hits=new ArrayList<>();List<String> targets=new ArrayList<>(strings);targets.addAll(List.of("missing", "AA", "a\ud800", "\ud800\udc00", "zzzz"));for(String text:targets){hits.add(Map.of("text",text,"textUTF16",text.chars().toArray(),"mainSID",find.invoke(table,text),"nativeFirstSID",strings.indexOf(text)));}
   String json=new GsonBuilder().disableHtmlEscaping().create().toJson(Map.of("case",i,"strings",strings,"stringsUTF16",strings.stream().map(x->x.chars().toArray()).toList(),"hits",hits));StringBuilder ascii=new StringBuilder();for(char c:json.toCharArray()){if(c>127)ascii.append(String.format("\\u%04x",(int)c));else ascii.append(c);}System.out.println(ascii);
  }
 }
}
