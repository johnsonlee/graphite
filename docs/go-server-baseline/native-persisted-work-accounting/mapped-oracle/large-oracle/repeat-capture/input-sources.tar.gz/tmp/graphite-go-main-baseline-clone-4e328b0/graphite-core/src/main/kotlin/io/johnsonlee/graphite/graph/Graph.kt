package io.johnsonlee.graphite.graph

import io.johnsonlee.graphite.core.BranchScope
import io.johnsonlee.graphite.core.CallSiteNode
import io.johnsonlee.graphite.core.Edge
import io.johnsonlee.graphite.core.MethodDescriptor
import io.johnsonlee.graphite.core.Node
import io.johnsonlee.graphite.core.NodeId
import io.johnsonlee.graphite.core.TypeDescriptor
import io.johnsonlee.graphite.input.ResourceAccessor
import java.util.regex.Pattern

data class ClassDependency(
    val callerClass: String,
    val calleeClass: String
)

data class ClassOverview(
    val classCounts: Map<String, Int>,
    val classEdges: Map<ClassDependency, Int>,
    val callSiteCount: Int
)

enum class StringMatchMode {
    STARTS_WITH,
    ENDS_WITH,
    CONTAINS,
    EQUALS
}

/** Exact value transformation applied before a storage-backed string match. */
enum class StringValueTransform {
    LOWERCASE
}

/** One exact predicate in a storage-backed disjunction lookup. */
data class StringPropertyPredicate(
    val property: String,
    val transform: StringValueTransform?,
    val mode: StringMatchMode,
    val expected: String
)

/**
 * Optional storage capability for graphs that can avoid materializing a full node scan.
 *
 * When the same graph also implements [StringPropertyLookupOrder], every non-null sequence
 * returned by this capability must be monotonic in [StringPropertyLookupOrder.stringPropertyNodeOrder].
 */
interface StringPropertyLookup {
    fun <T : Node> nodesByStringProperty(
        type: Class<T>,
        property: String,
        mode: StringMatchMode,
        expected: String,
        limit: Int
    ): Sequence<T>?
}

/** Receives one callback for each storage item inspected by a graph lookup. */
fun interface GraphWorkConsumer {
    fun consume()
}

/** A work consumer that can charge a batch without one atomic update per graph item. */
interface GraphWorkBatchConsumer : GraphWorkConsumer {
    fun consume(workUnits: Long)

    override fun consume() = consume(1L)
}

/**
 * A thread-safe batch consumer that explicitly permits one storage lookup to invoke it
 * concurrently from multiple scan workers.
 */
fun interface ParallelGraphWorkBatchConsumer : GraphWorkBatchConsumer

/**
 * A thread-safe batch consumer for a cross-graph lookup that splits one process-wide CPU budget
 * between graph workers and a shared background segment pool. The calling graph worker participates
 * in the scan; [segmentWorkerCount] is the maximum number of additional workers that this lookup may
 * request from that shared pool. Concurrent graph lookups share the same pool, so this value is not
 * multiplied by the number of graph workers.
 */
interface SplitGraphWorkBatchConsumer : ParallelGraphWorkBatchConsumer {
    val segmentWorkerCount: Int
}

/**
 * Requests the existing persisted string index through a read-only mapped view while preserving
 * the additive graph/segment worker split. This is intended for unscoped broad scans: explicitly
 * selected graph sets keep their retained-index lifecycle and telemetry.
 */
interface PreferredMappedStringIndexViewGraphWorkBatchConsumer : SplitGraphWorkBatchConsumer

/** Additive graph/segment worker allocation used by broad cross-graph scans. */
data class GraphScanParallelismPlan(
    val graphWorkerCount: Int,
    val segmentWorkerCount: Int
) {
    init {
        require(graphWorkerCount > 0) { "graphWorkerCount must be positive" }
        require(segmentWorkerCount >= 0) { "segmentWorkerCount must not be negative" }
    }

    companion object {
        /** Splits NCPU evenly; the segment side receives the spare CPU when NCPU is odd. */
        fun balanced(processors: Int = Runtime.getRuntime().availableProcessors()): GraphScanParallelismPlan {
            val available = processors.coerceAtLeast(1)
            if (available == 1) return GraphScanParallelismPlan(1, 0)
            val graphWorkers = available / 2
            return GraphScanParallelismPlan(graphWorkers, available - graphWorkers)
        }

        /** Applies a graph-worker override while keeping graph plus segment workers within NCPU. */
        fun withGraphWorkers(
            processors: Int = Runtime.getRuntime().availableProcessors(),
            graphWorkers: Int
        ): GraphScanParallelismPlan {
            val available = processors.coerceAtLeast(1)
            val boundedGraphWorkers = graphWorkers.coerceIn(1, available)
            return GraphScanParallelismPlan(boundedGraphWorkers, available - boundedGraphWorkers)
        }
    }
}

/**
 * A batch consumer that explicitly requests one storage lookup to stay serial because its caller
 * already parallelizes independent graph sources. This avoids nested scan pools while preserving
 * the same shared work and cancellation accounting.
 */
fun interface SerialGraphWorkBatchConsumer : GraphWorkBatchConsumer

/** Requests a bounded serial lookup to prefer raw storage so it can stop as soon as LIMIT is full. */
fun interface PreferredRawGraphWorkBatchConsumer : SerialGraphWorkBatchConsumer

/** Permits one parallel raw build, then requests retained string-index lookups without segment fanout. */
fun interface PreferredPersistedStringIndexGraphWorkBatchConsumer :
    SerialGraphWorkBatchConsumer,
    ParallelGraphWorkBatchConsumer

/** Polls request cancellation while a storage backend scans method metadata. */
fun interface MethodMetadataScanConsumer {
    fun inspect()
}

/**
 * Optional method-metadata capability for lazy, cancellation-aware storage scans.
 *
 * This stays outside [Graph] so adding cancellable method discovery does not add JVM
 * interface methods that older third-party [Graph] implementations would be forced to
 * implement at runtime. Method metadata is not graph work, so the callback deliberately
 * has a type distinct from [GraphWorkConsumer].
 */
interface StreamingMethodLookup {
    fun methods(
        pattern: MethodPattern,
        scanConsumer: MethodMetadataScanConsumer
    ): Sequence<MethodDescriptor>

    fun methodSlice(
        pattern: MethodPattern,
        limit: Int,
        scanConsumer: MethodMetadataScanConsumer
    ): List<MethodDescriptor>? = null
}

/** Optional string lookup capability that exposes its internal work to callers. */
interface WorkAwareStringPropertyLookup : StringPropertyLookup {
    fun <T : Node> nodesByStringProperty(
        type: Class<T>,
        property: String,
        mode: StringMatchMode,
        expected: String,
        limit: Int,
        workConsumer: GraphWorkConsumer
    ): Sequence<T>?
}

/**
 * Optional storage capability for matching a precisely transformed string value.
 *
 * When the same graph also implements [StringPropertyLookupOrder], every non-null sequence
 * returned by this capability must be monotonic in [StringPropertyLookupOrder.stringPropertyNodeOrder].
 */
interface TransformedStringPropertyLookup {
    fun <T : Node> nodesByTransformedStringProperty(
        type: Class<T>,
        property: String,
        transform: StringValueTransform,
        mode: StringMatchMode,
        expected: String,
        limit: Int
    ): Sequence<T>?
}

/** Transformed string lookup capability that exposes every inspected work item. */
interface WorkAwareTransformedStringPropertyLookup : TransformedStringPropertyLookup {
    fun <T : Node> nodesByTransformedStringProperty(
        type: Class<T>,
        property: String,
        transform: StringValueTransform,
        mode: StringMatchMode,
        expected: String,
        limit: Int,
        workConsumer: GraphWorkConsumer
    ): Sequence<T>?
}

/**
 * Optional capability for matching several string properties in one canonical node scan.
 * Returned nodes must match at least one predicate and must not contain duplicates.
 */
interface StringPropertyDisjunctionLookup {
    fun <T : Node> nodesByStringPropertyDisjunction(
        type: Class<T>,
        predicates: List<StringPropertyPredicate>,
        limit: Int
    ): Sequence<T>?
}

/** Disjunction lookup capability that exposes each inspected node as one work item. */
interface WorkAwareStringPropertyDisjunctionLookup : StringPropertyDisjunctionLookup {
    fun <T : Node> nodesByStringPropertyDisjunction(
        type: Class<T>,
        predicates: List<StringPropertyPredicate>,
        limit: Int,
        workConsumer: GraphWorkConsumer
    ): Sequence<T>?
}

/** One duplicate-preserving storage projection row in canonical node encounter order. */
data class StringPropertyProjectionRow(
    val values: List<String?>
)

/** Optional capability for projecting bounded string matches without materializing full nodes. */
interface StringPropertyDisjunctionProjection {
    fun projectStringPropertyDisjunction(
        type: Class<out Node>,
        predicates: List<StringPropertyPredicate>,
        projectedProperties: List<String>,
        limit: Int,
        workConsumer: GraphWorkConsumer? = null
    ): List<StringPropertyProjectionRow>?
}

/** Storage-level result for a string-disjunction aggregate without node materialization. */
data class StringPropertyDisjunctionAggregate(
    val count: Long,
    val distinctValues: Set<String>? = null
)

/** Optional capability for counting or deduplicating indexed string matches in storage. */
interface StringPropertyDisjunctionAggregation {
    fun aggregateStringPropertyDisjunction(
        type: Class<out Node>,
        predicates: List<StringPropertyPredicate>,
        distinctProperty: String? = null
    ): StringPropertyDisjunctionAggregate?
}

/** Storage aggregation that preserves query work-budget and cancellation accounting. */
interface WorkAwareStringPropertyDisjunctionAggregation : StringPropertyDisjunctionAggregation {
    fun aggregateStringPropertyDisjunction(
        type: Class<out Node>,
        predicates: List<StringPropertyPredicate>,
        distinctProperty: String? = null,
        workConsumer: GraphWorkConsumer
    ): StringPropertyDisjunctionAggregate?
}

/** One storage-projected distinct row in the backend's canonical node encounter order. */
data class StringPropertyDistinctRow(
    val encounterOrder: Long,
    val values: List<String?>
)

/**
 * Optional storage capability for DISTINCT string-property projections. When [selectedValues] is
 * non-null, implementations return only selected tuples that occur anywhere in the match set.
 */
interface StringPropertyDisjunctionDistinctProjection {
    fun distinctStringPropertyDisjunction(
        type: Class<out Node>,
        predicates: List<StringPropertyPredicate>,
        projectedProperties: List<String>,
        limit: Int,
        selectedValues: Set<List<String?>>? = null,
        workConsumer: GraphWorkConsumer? = null
    ): List<StringPropertyDistinctRow>?
}

/**
 * Optional lifecycle hook for a storage backend whose disjunction accelerator is a rebuildable
 * cache. A caller may release the cache after a completed source scan that produced no rows;
 * implementations must keep already-returned results valid and rebuild transparently later.
 */
interface ReleasableStringPropertyDisjunctionCache {
    fun releaseStringPropertyDisjunctionCache()
}

/** Optional planning hint for avoiding worker overhead once a mapped lookup is warm. */
interface StringPropertyDisjunctionLookupStrategy {
    fun prefersSerialStringPropertyDisjunction(
        type: Class<out Node>,
        predicates: List<StringPropertyPredicate>
    ): Boolean
}

/** Optional planning hint that a persisted lookup can be restored without building a raw index. */
interface PreparedStringPropertyDisjunctionLookup {
    fun hasPreparedStringPropertyDisjunction(
        type: Class<out Node>,
        predicates: List<StringPropertyPredicate>
    ): Boolean
}

/** Optional planning hint that a complete disjunction index is already retained in process memory. */
interface RetainedStringPropertyDisjunctionLookup {
    fun hasRetainedStringPropertyDisjunction(
        type: Class<out Node>,
        predicates: List<StringPropertyPredicate>
    ): Boolean
}

/**
 * Ordering capability for storage lookups that are emitted in canonical node traversal order.
 * Implementations must return a stable key and must emit all string-property lookup sequences
 * monotonically by that key.
 */
interface StringPropertyLookupOrder {
    fun stringPropertyNodeOrder(node: Node): Long
}

/**
 * The unified program graph that combines all analysis graphs.
 * This is the central abstraction of Graphite.
 *
 * Key design decisions:
 * 1. Immutable - once built, the graph doesn't change
 * 2. Queryable - supports efficient traversal and pattern matching
 * 3. Composable - can be built incrementally from different sources
 */
@Suppress("TooManyFunctions")
interface Graph {
    /**
     * Get a node by its ID
     */
    fun node(id: NodeId): Node?

    /**
     * Get all nodes of a specific type
     */
    fun <T : Node> nodes(type: Class<T>): Sequence<T>

    /**
     * Return a precomputed node count for [type] when the graph can answer
     * without scanning/deserializing nodes. Implementations may return null
     * to indicate callers should fall back to [nodes].
     */
    fun nodeCount(type: Class<out Node>): Long? = null

    /**
     * Return a precomputed edge count when the graph can answer without
     * scanning every node's adjacency list.
     */
    fun edgeCount(): Long? = null

    /**
     * Get all outgoing edges from a node
     */
    fun outgoing(id: NodeId): Sequence<Edge>

    /**
     * Get all incoming edges to a node
     */
    fun incoming(id: NodeId): Sequence<Edge>

    /**
     * Get outgoing edges of a specific type
     */
    fun <T : Edge> outgoing(id: NodeId, type: Class<T>): Sequence<T>

    /**
     * Get incoming edges of a specific type
     */
    fun <T : Edge> incoming(id: NodeId, type: Class<T>): Sequence<T>

    /**
     * Find all call sites that invoke a method matching the pattern
     */
    fun callSites(methodPattern: MethodPattern): Sequence<CallSiteNode>

    /**
     * Get the type hierarchy for a type
     */
    fun supertypes(type: TypeDescriptor): Sequence<TypeDescriptor>
    fun subtypes(type: TypeDescriptor): Sequence<TypeDescriptor>

    /**
     * Find methods matching a pattern
     */
    fun methods(pattern: MethodPattern): Sequence<MethodDescriptor>

    /**
     * Return a precomputed method count when the graph can answer without
     * materializing every method descriptor.
     */
    fun methodCount(): Long? = null

    /**
     * Return up to [limit] methods matching [pattern] when the graph can do so
     * without materializing the full method index.
     */
    fun methodSlice(pattern: MethodPattern, limit: Int): List<MethodDescriptor>? = null

    /**
     * Get the underlying values for an enum constant.
     * Enum constructors can have multiple user-defined arguments.
     *
     * @param enumClass fully qualified enum class name
     * @param enumName the name of the enum constant
     * @return list of constructor arguments (excluding name and ordinal), or null if not available
     */
    fun enumValues(enumClass: String, enumName: String): List<Any?>?

    /**
     * Get annotations for a class member (field or method).
     *
     * @param className fully qualified class name
     * @param memberName field name or method name
     * @return map of annotation FQN to annotation values, or empty map if none
     */
    fun memberAnnotations(className: String, memberName: String): Map<String, Map<String, Any?>>

    /**
     * Return all member annotations keyed by "$className#$memberName" when
     * the graph already stores that index. Implementations may return null to
     * let callers discover annotated members by scanning nodes.
     */
    fun memberAnnotationIndex(): Map<String, Map<String, Map<String, Any?>>>? = null

    /**
     * Access resource files from the analyzed archive (JAR, WAR, directory).
     */
    val resources: ResourceAccessor

    /**
     * Get all branch scopes in the graph.
     * Each BranchScope records which nodes belong to each branch of a condition.
     */
    fun branchScopes(): Sequence<BranchScope>

    /**
     * Get branch scopes where the given node is the condition operand.
     */
    fun branchScopesFor(conditionNodeId: NodeId): Sequence<BranchScope>

    /**
     * Get all type names that have type hierarchy information (supertypes or subtypes).
     */
    fun typeHierarchyTypes(): Set<String> = emptySet()

    /**
     * Get the origin artifact or source container for the given class, if known.
     *
     * Examples:
     * - `my-app.jar`
     * - a Spring Boot nested library origin
     * - a Spring Boot application classes origin
     */
    fun classOrigin(className: String): String? = null

    /**
     * Get all known class origins keyed by fully qualified class name.
     */
    fun classOrigins(): Map<String, String> = emptyMap()

    /**
     * Get artifact-level dependency weights keyed by source artifact, then target artifact.
     *
     * Example:
     * - `elasticsearch-8.17.0 -> lucene-core-9.12.0`
     */
    fun artifactDependencies(): Map<String, Map<String, Int>> = emptyMap()

    /**
     * Return a precomputed class-level call overview when the graph can answer
     * without scanning/deserializing call-site nodes.
     */
    fun classOverview(limit: Int): ClassOverview? = null

}

/**
 * Scan method metadata while polling cancellation before applying [pattern].
 * Storage backends can keep this lazy by implementing [StreamingMethodLookup].
 */
fun Graph.methods(
    pattern: MethodPattern,
    scanConsumer: MethodMetadataScanConsumer
): Sequence<MethodDescriptor> = (this as? StreamingMethodLookup)
    ?.methods(pattern, scanConsumer)
    ?: methods(MethodPattern()).onEach { scanConsumer.inspect() }.filter(pattern::matches)

/**
 * Use a bounded method lookup only when the backend can poll cancellation during its scan.
 * Returning null lets callers fall back to the streaming [methods] extension.
 */
fun Graph.methodSlice(
    pattern: MethodPattern,
    limit: Int,
    scanConsumer: MethodMetadataScanConsumer
): List<MethodDescriptor>? = (this as? StreamingMethodLookup)
    ?.methodSlice(pattern, limit, scanConsumer)

/**
 * Use a storage-aware string lookup when [Graph] also implements
 * [StringPropertyLookup]. Existing graph implementations remain binary
 * compatible and return null through this extension.
 */
fun <T : Node> Graph.nodesByStringProperty(
    type: Class<T>,
    property: String,
    mode: StringMatchMode,
    expected: String,
    limit: Int = Int.MAX_VALUE
): Sequence<T>? = (this as? StringPropertyLookup)
    ?.nodesByStringProperty(type, property, mode, expected, limit)

/** Use a storage lookup only when it can report every inspected work item. */
fun <T : Node> Graph.nodesByStringProperty(
    type: Class<T>,
    property: String,
    mode: StringMatchMode,
    expected: String,
    limit: Int,
    workConsumer: GraphWorkConsumer
): Sequence<T>? = (this as? WorkAwareStringPropertyLookup)
    ?.nodesByStringProperty(type, property, mode, expected, limit, workConsumer)

/** Use a storage-aware transformed string lookup when the graph supports it. */
fun <T : Node> Graph.nodesByTransformedStringProperty(
    type: Class<T>,
    property: String,
    transform: StringValueTransform,
    mode: StringMatchMode,
    expected: String,
    limit: Int = Int.MAX_VALUE
): Sequence<T>? = (this as? TransformedStringPropertyLookup)
    ?.nodesByTransformedStringProperty(type, property, transform, mode, expected, limit)

/** Use a transformed lookup only when it can report every inspected work item. */
fun <T : Node> Graph.nodesByTransformedStringProperty(
    type: Class<T>,
    property: String,
    transform: StringValueTransform,
    mode: StringMatchMode,
    expected: String,
    limit: Int,
    workConsumer: GraphWorkConsumer
): Sequence<T>? = (this as? WorkAwareTransformedStringPropertyLookup)
    ?.nodesByTransformedStringProperty(type, property, transform, mode, expected, limit, workConsumer)

/** Use a fused storage lookup when the graph can evaluate the complete disjunction exactly. */
fun <T : Node> Graph.nodesByStringPropertyDisjunction(
    type: Class<T>,
    predicates: List<StringPropertyPredicate>,
    limit: Int = Int.MAX_VALUE
): Sequence<T>? = (this as? StringPropertyDisjunctionLookup)
    ?.nodesByStringPropertyDisjunction(type, predicates, limit)

/** Use a fused disjunction lookup only when it can report every inspected node. */
fun <T : Node> Graph.nodesByStringPropertyDisjunction(
    type: Class<T>,
    predicates: List<StringPropertyPredicate>,
    limit: Int,
    workConsumer: GraphWorkConsumer
): Sequence<T>? = (this as? WorkAwareStringPropertyDisjunctionLookup)
    ?.nodesByStringPropertyDisjunction(type, predicates, limit, workConsumer)

/**
 * Pattern for matching methods.
 * Supports wildcards and annotations.
 */
data class MethodPattern(
    val declaringClass: String? = null,        // e.g., "com.example.*" or regex ".*Client" when useRegex=true
    val name: String? = null,                  // e.g., "getOption" or regex "getOption.*" when useRegex=true
    val parameterTypes: List<String>? = null,  // e.g., ["java.lang.Integer"] or null for any
    val returnType: String? = null,
    val annotations: List<String> = emptyList(), // e.g., ["org.springframework.web.bind.annotation.GetMapping"]
    val useRegex: Boolean = false              // when true, declaringClass and name are treated as regex patterns
) {
    @Transient
    private val declaringClassExactRegex = exactRegex(declaringClass)

    @Transient
    private val declaringClassRegex = compileRegex(declaringClass, declaringClassExactRegex)

    @Transient
    private val nameExactRegex = exactRegex(name)

    @Transient
    private val nameRegex = compileRegex(name, nameExactRegex)

    @Transient
    private val parameterTypeExactRegexes = parameterTypes?.map(::exactRegex)

    @Transient
    private val parameterTypeRegexes = parameterTypes?.mapIndexed { index, pattern ->
        compileRegex(pattern, parameterTypeExactRegexes?.get(index))
    }

    @Transient
    private val returnTypeExactRegex = exactRegex(returnType)

    @Transient
    private val returnTypeRegex = compileRegex(returnType, returnTypeExactRegex)

    fun matches(method: MethodDescriptor): Boolean {
        if (declaringClass != null &&
            !matchesPattern(
                method.declaringClass.className,
                declaringClass,
                declaringClassExactRegex,
                declaringClassRegex
            )
        ) {
            return false
        }
        if (name != null && !matchesPattern(method.name, name, nameExactRegex, nameRegex)) {
            return false
        }
        if (parameterTypes != null) {
            if (method.parameterTypes.size != parameterTypes.size) return false
            if (!method.parameterTypes.indices.all { index ->
                    matchesPattern(
                        method.parameterTypes[index].className,
                        parameterTypes[index],
                        parameterTypeExactRegexes?.get(index),
                        parameterTypeRegexes?.get(index)
                    )
                }) return false
        }
        if (returnType != null &&
            !matchesPattern(method.returnType.className, returnType, returnTypeExactRegex, returnTypeRegex)
        ) {
            return false
        }
        return true
    }

    private fun exactRegex(pattern: String?): String? {
        if (!useRegex || pattern == null) return null
        return pattern.takeIf { it.startsWith("\\Q") && it.endsWith("\\E") }
            ?.substring(2, pattern.length - 2)
            ?.replace("\\E\\\\E\\Q", "\\E")
            ?.takeIf { Pattern.quote(it) == pattern }
    }

    private fun compileRegex(pattern: String?, exact: String?): Pattern? =
        pattern?.takeIf { useRegex && exact == null }?.let(Pattern::compile)

    private fun matchesPattern(actual: String, pattern: String, exactRegex: String?, regex: Pattern?): Boolean {
        return if (useRegex) {
            exactRegex?.let(actual::equals) ?: requireNotNull(regex).matcher(actual).matches()
        } else if (pattern.endsWith("*")) {
            actual.startsWith(pattern.dropLast(1))
        } else {
            actual == pattern
        }
    }
}

/**
 * Builder for constructing graphs
 */
interface GraphBuilder {
    fun addNode(node: Node): GraphBuilder
    fun addEdge(edge: Edge): GraphBuilder
    fun build(): Graph
}

/**
 * Extension functions for convenient traversal
 */
inline fun <reified T : Node> Graph.nodes(): Sequence<T> = nodes(T::class.java)
inline fun <reified T : Edge> Graph.outgoing(id: NodeId): Sequence<T> = outgoing(id, T::class.java)
inline fun <reified T : Edge> Graph.incoming(id: NodeId): Sequence<T> = incoming(id, T::class.java)
