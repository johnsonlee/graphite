module github.com/johnsonlee/graphite/graphite-server

go 1.22
