description = "Graphite Explorer - Interactive web visualization for saved graphs"

plugins {
    application
    id("com.gradleup.shadow") version "8.3.0"
    id("org.jetbrains.kotlinx.kover") version "0.9.1"
    id("me.champeau.jmh")
}

application {
    mainClass.set("io.johnsonlee.graphite.cli.ExploreMainKt")
}

val integrationFixtures: Configuration by configurations.creating

dependencies {
    implementation(project(":core"))
    implementation(project(":cypher"))
    implementation(project(":webgraph"))
    implementation(libs.picocli)
    implementation(libs.gson)
    implementation(libs.javalin)
    implementation(libs.javalin.micrometer)
    implementation(libs.micrometer.core)
    implementation(libs.micrometer.registry.prometheus)

    testImplementation(project(":query"))

    add(integrationFixtures.name, libs.android.all)

    jmh(project(":sootup"))
    jmh(libs.jmh.core)
    jmhAnnotationProcessor(libs.jmh.generator)
}

val integrationFixtureJvmArgs = providers.provider {
    integrationFixtures.resolve().mapNotNull { jar ->
        when {
            jar.name.startsWith("android-all-") && jar.name.endsWith(".jar") -> "-Dandroid.jar.path=${jar.absolutePath}"
            else -> null
        }
    }
}

jmh {
    includeTests.set(false)
    val filter = project.findProperty("jmh.filter") as String?
    if (filter != null) {
        includes.set(listOf(filter))
    }
    failOnError.set(true)
    jvmArgsAppend.addAll(integrationFixtureJvmArgs)
}

tasks.jar {
    archiveClassifier.set("slim")
    manifest {
        attributes(
            "Implementation-Title" to "Graphite Explore",
            "Implementation-Version" to project.version.toString(),
        )
    }
}

tasks.shadowJar {
    archiveBaseName.set("graphite-explore")
    archiveClassifier.set("")
    archiveVersion.set("")
    mergeServiceFiles()

    minimize {
        exclude(dependency("org.antlr:antlr4-runtime:.*"))
        exclude(dependency("org.jetbrains.kotlin:kotlin-stdlib:.*"))
        exclude(dependency("org.jetbrains.kotlin:kotlin-reflect:.*"))
        exclude(dependency("org.slf4j:slf4j-nop:.*"))
        exclude(dependency("io.javalin:.*:.*"))
        exclude(dependency("org.eclipse.jetty:.*:.*"))
        exclude(dependency("org.eclipse.jetty.websocket:.*:.*"))
    }

    manifest {
        attributes(
            "Main-Class" to "io.johnsonlee.graphite.cli.ExploreMainKt",
            "Implementation-Title" to "Graphite Explore",
            "Implementation-Version" to project.version.toString(),
        )
    }
}

tasks.named<JavaExec>("run") {
    systemProperty("graphite.version", project.version.toString())
}

kover {
    reports {
        filters {
            excludes {
                classes(
                    "*Benchmark*",
                    "io.johnsonlee.graphite.cli.ExplorerMemoryCounters",
                    "io.johnsonlee.graphite.cli.MemorySample",
                    "io.johnsonlee.graphite.cli.ExploreMainKt"
                )
            }
        }
    }
}

tasks.test {
    systemProperty("graphite.version", project.version.toString())
    testLogging {
        events("passed", "skipped", "failed")
        showExceptions = true
        showStackTraces = true
    }
}

// All entry points (run, installDist, slim and shadow JARs) use the same verified
// native resources. The default remains a portable Linux/macOS distribution;
// -Pgraphite.nativeTargets=host is an explicit local-development shortcut.
val nativeResources = layout.buildDirectory.dir("generated/native-resources")
val nativeTargets = providers.gradleProperty("graphite.nativeTargets")
    .orElse("darwin-amd64,darwin-arm64,linux-amd64,linux-arm64")
val nativePrebuilt = providers.gradleProperty("graphite.nativePrebuilt")
val prepareNativeServer by tasks.registering(Exec::class) {
    inputs.files(rootProject.fileTree("graphite-server") {
        include("**/*.go", "go.mod", "go.sum", "internal/web/assets/**", "internal/profiling/report.html", "internal/server/spec/**", "internal/javaregex/*.json", "internal/javaregex/*.json.gz", "cmd/graphite-server/*.txt")
        exclude("**/*_test.go", "**/testdata/**")
    })
    inputs.files(rootProject.fileTree("scripts/native") { include("*.go") })
    inputs.property("version", project.version.toString())
    inputs.property("targets", nativeTargets)
    if (nativePrebuilt.isPresent) inputs.dir(rootProject.file(nativePrebuilt.get()))
    outputs.dir(nativeResources)
    workingDir(rootProject.projectDir)
    commandLine("go", "run", "scripts/native/build.go",
        "--output", nativeResources.get().dir("graphite-native").asFile.absolutePath,
        "--version", project.version.toString(), "--targets", nativeTargets.get())
    if (nativePrebuilt.isPresent) args("--prebuilt", rootProject.file(nativePrebuilt.get()).absolutePath)
}
sourceSets.main { resources.srcDir(nativeResources) }
tasks.processResources { dependsOn(prepareNativeServer) }
