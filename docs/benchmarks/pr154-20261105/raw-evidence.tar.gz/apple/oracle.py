#!/usr/bin/env python3
"""Correctness only. Run after the main benchmark stops. Save every full HTTP body.
Usage: python3 oracle.py config.json --out NEW_DIR
No performance samples/claims. Two complete responses per declared case and variant.
"""
import argparse, hashlib, json, socket, subprocess, time, urllib.request, urllib.error
from pathlib import Path

def digest_file(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
    return h.hexdigest()

def unique(pairs):
    d={}
    for k,v in pairs:
        if k in d: raise ValueError('duplicate JSON key: '+k)
        d[k]=v
    return d

def fetch(base, case, directory, label):
    body=json.dumps({'query':case['query'],'graphs':case['scope'],'mode':'cross-graph','limit':case['limit']}).encode()
    (directory/(label+'.request.json')).write_bytes(body)
    raw=b''; status=None
    try:
        req=urllib.request.Request(base+'/api/cypher/graphs',body,{'Content-Type':'application/json'})
        with urllib.request.urlopen(req,timeout=90) as response:
            status=response.status;raw=response.read()
    except urllib.error.HTTPError as e:
        status=e.code;raw=e.read();raise
    finally:
        (directory/(label+'.response.json')).write_bytes(raw)
        (directory/(label+'.status.json')).write_text(json.dumps({'status':status,'bytes':len(raw)})+'\n')
    assert status==200
    x=json.loads(raw,object_pairs_hook=unique)
    assert not x.get('error') and not x.get('truncated'),x
    assert x.get('mode')=='cross-graph' and set(x['graphs'])==set(case['scope']),x
    assert isinstance(x.get('columns'),list) and isinstance(x.get('rows'),list)
    assert len(x['rows'])<case['limit'],'transport cap reached'
    row_text=[json.dumps(r,sort_keys=True,separators=(',',':'),ensure_ascii=False) for r in x['rows']]
    if case['row_order']=='unordered': row_text.sort()
    canonical=json.dumps([x['columns'],row_text],separators=(',',':'),ensure_ascii=False).encode()
    (directory/(label+'.canonical.json')).write_bytes(canonical)
    represented=set()
    for row in x['rows']:
        for field in ('graph','leftGraph','rightGraph'):
            if field in row: represented.add(row[field])
        if case['name']=='shared-wire-literals-prefiltered':
            assert row['leftGraph']!=row['rightGraph']
            assert row['wireLiteral'] in ['application/json','Content-Type','GET','POST']
            assert row['pairs']>0
    assert len(represented)>=2 and represented<=set(case['scope']),'actual result must involve >=2 declared graphs'
    if case['name'] in ('network-message-call-scan','all-graph-node-census'):
        assert represented==set(case['scope'])
    return {'digest':hashlib.sha256(canonical).hexdigest(),'rows':len(x['rows']),'representedGraphs':sorted(represented),'scope':case['scope']}

def main():
    p=argparse.ArgumentParser();p.add_argument('config',type=Path);p.add_argument('--out',type=Path,required=True);a=p.parse_args()
    cfg=json.loads(a.config.read_text());a.out.mkdir(parents=True,exist_ok=False)
    report={'correctnessOnly':True,'passed':False,'variants':{},'failures':[]}
    try:
        cases=[cfg['protocol']['readiness']]+cfg['protocol']['cases']
        for variant in ['baseline','candidate']:
            v=cfg['variants'][variant];directory=a.out/variant;directory.mkdir()
            with socket.socket() as sock:sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
            cmd=[s.replace('{port}',str(port)) for s in v['server_command']]
            for g in v['graphs']:cmd+=['--graph',g['id']+':'+str(Path(g['path']).resolve())]
            record={'command':cmd,'revision':v['revision'],'binarySha256':digest_file(cmd[0]),'cases':{},'stopped':False};report['variants'][variant]=record
            (directory/'command.json').write_text(json.dumps(record,indent=2)+'\n')
            with (directory/'server.log').open('wb') as log:
                process=subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT)
                try:
                    deadline=time.monotonic()+cfg['protocol']['startup_timeout_seconds']; attempt=0
                    while True:
                        assert process.poll() is None,'server exited before readiness'
                        try:fetch('http://127.0.0.1:'+str(port),cases[0],directory,'readiness-'+str(attempt));break
                        except Exception as e:
                            (directory/('readiness-'+str(attempt)+'.error.txt')).write_text(repr(e)+'\n')
                            if time.monotonic()>deadline:raise
                            attempt+=1;time.sleep(.1)
                    for case in cases:
                        results=[fetch('http://127.0.0.1:'+str(port),case,directory,case['name']+'-'+str(i)) for i in range(2)]
                        assert results[0]==results[1], 'unstable complete response '+case['name']
                        record['cases'][case['name']]=results[0]
                    assert process.poll() is None,'server exited unexpectedly'
                finally:
                    if process.poll() is None:
                        process.terminate()
                        try:process.wait(timeout=10)
                        except subprocess.TimeoutExpired:process.kill();process.wait()
                    record['stopped']=process.poll() is not None
                    record['exitCode']=process.returncode
        assert report['variants']['baseline']['cases']==report['variants']['candidate']['cases'],'base/head complete response mismatch'
        report['passed']=True
    except BaseException as e:
        report['failures'].append(repr(e));raise
    finally:
        (a.out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
if __name__=='__main__':main()
