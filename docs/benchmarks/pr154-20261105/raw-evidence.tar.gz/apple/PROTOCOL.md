Supplementary real Apple/JVM three-graph workload. Prepared before measurements.

Run only after the main real64 pipeline is idle; no concurrent benchmark or compilation.
The config uses main-controller prepared base/head native executables at exact revisions
7c59d799 and 190eba79. Both consume byte-identical existing persisted graph inputs.
Signal is the final full IR roundtrip-verified graph; SwiftPM and Signal Server are older
real-source graphs. See provenance.json for pinned sources, producer identities and gaps.
This measures native load/query behavior, not Apple compilation or construction recovery.

Commands, from this directory, each with a fresh output directory:

    python3 oracle.py config.json --out oracle
    python3 apple-lifecycle.py load config.json --out load
    python3 apple-lifecycle.py query config.json --out query

Do not proceed to measurements if oracle fails. It saves full requests, responses,
canonical rows/columns, binary hashes and commands; validates all three graph request
scope, at least two result graph identities, repeated-result stability, cross-variant
parity, and actual different-graph pairs for the shared-wire-literals query. It finally
stops each server. Its runs are correctness only, with no reported timing. New Signal
coverage changes old expected answers; do not substitute the historical result digest.

Four fixed cases and readiness are in config.json. Every HTTP request explicitly names
all three graphs in cross-graph mode; none adds a single-graph restriction. Full body
consumption precedes latency completion; outer execution-time fields are excluded from
semantic parity while rows, duplicates, columns and row provenance are retained.
SQL-style LIMIT 100 belongs to two declared queries; HTTP cap 10000 must never be hit.
Success raw request timings and response digest/count/bytes are journaled. The independent
oracle preserves full success response bytes; failures include full error bodies.

Three paired rounds execute AB, BA, AB. Query arms use separate fresh processes, five
warmups per case, then 100 closed-loop requests per case at concurrency one and four.
Total query samples: 4800 measured and 120 warmup, plus readiness attempts. Fixed-batch
workload is not a sustained saturation test. p50/p95 use nearest rank separately for
each repeated case/concurrency; report pooled values plus all round values/ranges.
Do not pool different case latencies. Preserve failures and all observations.

Load: spawn through all-graph readiness plus consumption of all four cases, including
first-use/deferred work. Load row CPU is live process CPU at this boundary; wait4 CPU
and peak RSS additionally cover full process lifetime through shutdown. Query CPU is
server user+system delta around each request batch (macOS Mach absolute ticks converted
using mach_timebase_info; Linux /proc clock ticks). Query peak RSS is wait4 lifetime
high-water including startup/warmup, not query-only peak. Ten-millisecond RSS samples
are supplementary lower bounds. CPU/RSS are process metrics, not concurrent tree sums.
The ready handshake latency itself is not a substitute for complete-use load latency.

OS filesystem cache is warm/uncontrolled after oracle and input fingerprinting; no cold
cache claim. Ambient workstation activity must be recorded; no quiet-run assumption.
Existing graphs from historical producers isolate consumers but do not measure current
producer completeness. SwiftPM import log lacks an exact historical importer binary SHA;
this gap must remain disclosed. New run fingerprints bind all actual persisted inputs.
Report results as supplementary observations with explicit per-case latency/CPU/RSS and
correctness conclusions. No automatic performance acceptance, no single-graph metrics.
