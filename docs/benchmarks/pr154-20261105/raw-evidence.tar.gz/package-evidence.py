#!/usr/bin/env python3
"""Package local benchmark records without binaries, graph payloads or process inventory."""
from pathlib import Path
import gzip
import hashlib
import json
import shutil
import tarfile

ROOT = Path(__file__).resolve().parent
PUBLIC = ROOT / "public"

def sha(path):
    with path.open("rb") as f:
        return hashlib.file_digest(f, "sha256").hexdigest()

def main():
    assert json.loads((ROOT / "run-standalone/report/report.json").read_text())["passed"]
    assert json.loads((ROOT / "apple/oracle/report.json").read_text())["passed"]
    assert json.loads((ROOT / "delivery-final-audit.json").read_text())["passed"]
    for operation in ("load", "query"):
        assert json.loads((ROOT / f"apple/{operation}/summary.json").read_text())["ok"]
    assert (PUBLIC / "README.md").is_file(), "render and independently verify report first"
    for source, target in (
        ("run-standalone/report/report.json", "core-report.json"),
        ("apple/query/summary.json", "apple-query-summary.json"),
        ("apple/load/summary.json", "apple-load-summary.json"),
        ("apple/oracle/report.json", "apple-oracle.json"),
        ("core-sample-verification.json", "core-sample-verification.json"),
        ("delivery-final-audit.json", "delivery-final-audit.json"),
    ):
        shutil.copyfile(ROOT / source, PUBLIC / target)
    paths = []
    for name in ("plan.json", "preflight-tests.log", "controller-build.log",
                 "base-standalone-smoke.log", "head-standalone-smoke.log",
                 "controller.log", "controller-standalone.log", "render-report.py",
                 "package-evidence.py", "verify-core-samples.py", "core-sample-verification.json", "delivery-final-audit.json"):
        paths.append(ROOT / name)
    for folder in ("run", "run-standalone", "apple"):
        for path in (ROOT / folder).rglob("*"):
            if not path.is_file() or "__pycache__" in path.parts:
                continue
            # Graph payloads and executables stay local; manifests remain reproducible inputs.
            rel = path.relative_to(ROOT / folder)
            if "graphs" in rel.parts and path.name not in ("graphs.tsv", "fixture-provenance.tsv"):
                continue
            if path.suffix in (".json", ".jsonl", ".log", ".receipt", ".tsv", ".txt", ".py", ".md"):
                paths.append(path)
    paths.append(PUBLIC / "environment.json")
    paths = sorted(set(paths))
    inventory = [{"path": str(p.relative_to(ROOT)), "bytes": p.stat().st_size,
                  "sha256": sha(p)} for p in paths]
    (PUBLIC / "raw-files.json").write_text(json.dumps(inventory, indent=2) + "\n")
    archive = PUBLIC / "raw-evidence.tar.gz"
    with archive.open("wb") as f, gzip.GzipFile(fileobj=f, mode="wb", mtime=0) as gz:
        with tarfile.open(fileobj=gz, mode="w") as tar:
            for path in paths:
                info = tar.gettarinfo(str(path), arcname=str(path.relative_to(ROOT)))
                info.uid = info.gid = 0
                info.uname = info.gname = ""
                with path.open("rb") as data:
                    tar.addfile(info, data)
    # Consume the completed archive, independent of the writer's source-file handles.
    with tarfile.open(archive, "r:gz") as tar:
        for entry in inventory:
            f = tar.extractfile(entry["path"])
            assert f is not None
            assert hashlib.file_digest(f, "sha256").hexdigest() == entry["sha256"]
    limit = 40 * 1024 * 1024
    if archive.stat().st_size > limit:
        with archive.open("rb") as f:
            part = 0
            while chunk := f.read(limit):
                part += 1
                (PUBLIC / f"raw-evidence.tar.gz.part{part:03d}").write_bytes(chunk)
        archive.unlink()
    archives = sorted(PUBLIC.glob("raw-evidence.tar.gz*"))
    downloads = ["# Raw benchmark evidence", "",
                 "These files retain all samples and failures, full real64 HTTP responses, Apple complete-response oracles, commands, fixture identities and logs. Product executables and persisted graph payloads are omitted; regenerate them at the recorded source revisions.", ""]
    for path in archives:
        downloads.append(f"- [{path.name}]({path.name}?raw=1): {path.stat().st_size:,} bytes; SHA-256 `{sha(path)}`")
    if not archive.exists():
        downloads += ["", "Reassemble before extracting:", "", "```sh", "cat raw-evidence.tar.gz.part* > raw-evidence.tar.gz", "tar -xzf raw-evidence.tar.gz", "```"]
    downloads += ["", "[Archive member checksums](raw-files.json) · [Public file checksums](SHA256SUMS)", ""]
    (PUBLIC / "DOWNLOAD.md").write_text("\n".join(downloads))
    manifest = [{"path": p.name, "bytes": p.stat().st_size, "sha256": sha(p)}
                for p in sorted(PUBLIC.iterdir()) if p.is_file() and p.name != "SHA256SUMS"]
    (PUBLIC / "SHA256SUMS").write_text("".join(f"{p['sha256']}  {p['path']}\n" for p in manifest))
    print(json.dumps({"rawFiles": len(paths), "publicFiles": manifest}, indent=2))

if __name__ == "__main__":
    main()
