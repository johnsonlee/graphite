#!/usr/bin/env python3
"""Render only complete, verified local benchmark evidence; never executes products.
Usage: python3 render-report.py [--root PATH]. Missing/invalid data exits nonzero.
Writes public/README.md, public/environment.json and pr-body-benchmark.md.
"""
import argparse, collections, hashlib, json, math
from pathlib import Path
BASE='7c59d7993be51f0807495890d068effcfaff155b'
HEAD='190eba79a4428d3100c8fba480bd858a19ac893d'
SCOPE={'signal-ios','swiftpm','signal-server'}

def need(ok,msg):
    if not ok: raise ValueError(msg)
def read(p): return json.loads(p.read_text())
def lines(p): return [json.loads(s) for s in p.read_text().splitlines() if s.strip()]
def q(xs,p):
    need(bool(xs),'empty quantile');return sorted(xs)[math.ceil(len(xs)*p)-1]
def fmt(x): return 'UNAVAILABLE' if x is None else f'{x:,.3f}'
def percent(base,head):
    return 'UNAVAILABLE' if base is None or head is None or base == 0 else f'{(head-base)/base*100:+.2f}%'
def rng(xs):return f'{fmt(min(xs))}–{fmt(max(xs))}'
def same(a,b):return math.isclose(a,b,rel_tol=1e-10,abs_tol=1e-8)
def table(headers,rows):return '\n'.join(['| '+' | '.join(headers)+' |','| '+' | '.join(['---']*len(headers))+' |']+['| '+' | '.join(str(v).replace('|','\\|').replace('\n',' ') for v in row)+' |' for row in rows])
def collapsed(title,body):return '<details>\n<summary>'+title+'</summary>\n\n'+body+'\n\n</details>'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()

def apple_verify(root,config):
    out={};oracle=read(root/'apple/oracle/report.json')
    need(oracle['passed'] is True and not oracle['failures'],'Apple full-response oracle failed')
    need(set(oracle['variants'])=={'baseline','candidate'},'oracle variants')
    expected={c['name'] for c in config['protocol']['cases']};allcases=expected|{config['protocol']['readiness']['name']}
    need(len(expected)==4,'four Apple cases required')
    for label,revision in [('baseline',BASE),('candidate',HEAD)]:
        v=oracle['variants'][label];need(v['revision']==revision and v['stopped'] is True,'oracle identity/lifecycle')
        need(set(v['cases'])==allcases,'oracle case coverage')
        for name,c in v['cases'].items():
            need(set(c['scope'])==SCOPE and len(c['representedGraphs'])>=2,'oracle actual multi-graph scope')
            need(c==oracle['variants']['baseline']['cases'][name],'oracle parity')
    for op in ['load','query']:
        folder=root/'apple'/op;summary=read(folder/'summary.json');raw=lines(folder/'samples.jsonl')
        need(read(folder/'protocol.json')==config,op+' protocol drift')
        need(summary['ok'] is True and summary['quantile_method']=='nearest-rank',op+' summary failed')
        need(len(summary['parity'])==5 and {r['case'] for r in summary['parity']}==allcases and all(r['ok'] is True for r in summary['parity']),op+' parity coverage')
        need(not any(r['kind']=='failure' for r in raw),op+' failure journal')
        req=[r for r in raw if r['kind']=='request'];attempts=[r for r in req if r.get('phase')=='readiness' and not r['ok']]
        actual=[r for r in req if r.get('phase')!='readiness']
        need(all(r['ok'] is True and set(r['scope'])==SCOPE for r in actual),op+' request failure/scope')
        for r in req:
            need(set(r['scope'])==SCOPE,'request scope drift')
            if r['ok']:
                c=oracle['variants'][r['variant']]['cases'][r['case']]
                need(r['digest']==c['digest'] and r['row_count']==c['rows'],'oracle/raw response mismatch')
        ids=[r for r in raw if r['kind']=='graph_identity'];need(len(ids)==6,'graph identity coverage')
        for gid in SCOPE:
            a=[r for r in ids if r['graph']['id']==gid];need(len(a)==2 and a[0]['files']==a[1]['files'],'base/head graph bytes differ')
        resources=[r for r in raw if r['kind']=='server_resources']
        need(len(resources)==6 and all(r['ok'] is True for r in resources),'server lifecycle incomplete')
        need({(r['variant'],r['round']) for r in resources}=={(v,n) for v in ['baseline','candidate'] for n in range(3)},'server round coverage')
        out[op]={'summary':summary,'raw':raw,'resources':resources,'readinessRetries':len(attempts)}
        if op=='load':
            loads=[r for r in raw if r['kind']=='load'];need(len(loads)==6 and all(r['ok'] for r in loads),'six loads required')
            need(len(actual)==24 and all(r['phase']=='load-consumption' for r in actual),'load four full cases per arm')
            need(collections.Counter((r['variant'],r['round'],r['case']) for r in actual)==collections.Counter({(v,n,c):1 for v in ['baseline','candidate'] for n in range(3) for c in expected}),'load per-round coverage')
            out[op]['loads']=loads
        else:
            measured=[r for r in actual if r['phase']=='measured'];warm=[r for r in actual if r['phase']=='warmup']
            need(len(measured)==4800 and len(warm)==120 and len(actual)==4920,'4800 measured + 120 warmup required')
            need(collections.Counter((r['variant'],r['round'],r['case']) for r in warm)==collections.Counter({(v,n,c):5 for v in ['baseline','candidate'] for n in range(3) for c in expected}),'warmup coverage')
            grouped=collections.defaultdict(list)
            for r in measured:grouped[(r['variant'],r['case'],r['concurrency'],r['round'])].append(r)
            need(len(grouped)==48 and all(len(v)==100 and {r['sample'] for r in v}==set(range(100)) for v in grouped.values()),'measured sample slots')
            batches=[r for r in raw if r['kind']=='query_batch'];need(len(batches)==48,'48 CPU batches')
            for b in batches:
                need(b['ok'] is True and b['failures']==0 and b['samples']==100 and b['cpu_seconds']>=0,'batch failure/CPU')
                need(b['cpu_before']['cpu_counter']!='proc_pid_rusage-v2-nanoseconds','uncorrected Mach ticks')
            need({(b['variant'],b['case'],b['concurrency'],b['round']) for b in batches}==set(grouped),'CPU group coverage')
            need(len(summary['queries'])==16,'sixteen pooled case/concurrency rows')
            for s in summary['queries']:
                rounds=[[r['wall_ms'] for r in grouped[(s['variant'],s['case'],s['concurrency'],n)]] for n in range(3)];values=sum(rounds,[])
                need(s['samples']==300 and same(s['p50_ms'],q(values,.5)) and same(s['p95_ms'],q(values,.95)),'pooled percentile differs from raw')
                need(s['round_p95_range_ms']==[min(q(v,.95) for v in rounds),max(q(v,.95) for v in rounds)],'round range differs from raw')
            out[op]['batches']=batches
    return out,oracle

def main(root):
    report=read(root/'run-standalone/report/report.json')
    need(report['baseSha']==BASE and report['headSha']==HEAD,'wrong core revisions')
    need(report['passed'] is True and report['errors']==[] and report['performanceAcceptance'] is False,'core failed/acceptance changed')
    suites={s['suite']:s for s in report['suites']};need(set(suites)=={'frontend-build-save','native-real64'},'required suites')
    need(set(report['requiredSuites'])==set(suites),'required suite declaration')
    for name,count in [('frontend-build-save',7),('native-real64',8)]:
        s=suites[name];need(s['baseSha']==BASE and s['headSha']==HEAD,'suite revision drift')
        need(len(s['checks'])==count and all(c['passed'] is True for c in s['checks']),name+' checks failed/incomplete')
    native=suites['native-real64'];sampling=native['sampling']
    need(all(sampling[k]==v for k,v in [('concurrency',4),('oraclePerCase',1),('warmupPerCase',2),('pressurePerCase',20),('isolatedPerCase',40)]),'core sampling changed')
    core={}
    for t in native['timings']:
        if t['stage'] not in ['pressure','isolated']:continue
        stat='p95' if 'nearest-rank p95;' in t['method'] else 'p50'
        key=(t['stage'],t['case'],stat);need(key not in core,'duplicate timing');core[key]=t
        if t['stage']=='pressure':need(t['comparable'] and t['samplesBase']==20 and t['samplesHead']==20 and t['baseMs'] is not None and t['headMs'] is not None,'incomplete pressure observations')
    cases=sorted({c for stage,c,stat in core if stage=='pressure'});need(len(cases)==73 and sum(k[0]=='pressure' for k in core)==146,'all73 pressure cases')
    config=read(root/'apple/config.json');need(config['protocol']['rounds']==3 and config['protocol']['requests_per_case']==100 and config['protocol']['concurrency']==[1,4] and config['protocol']['warmup_requests']==5,'Apple fixed protocol')
    apple,oracle=apple_verify(root,config)
    for label,role in [('baseline','base'),('candidate','head')]:need(oracle['variants'][label]['binarySha256']==native['inputs'][role]['binarySha256'],'Apple/core binary differs')
    environment=read(root/'environment.json');publicenv={k:environment[k] for k in ['recordedUtc','platform','machine','cpu','memoryBytes','logicalCpus','java'] if k in environment}
    publicenv['limitations']=['Interactive workstation; background activity was recorded privately, not assumed absent.','Filesystem cache uncontrolled; no disk-cold claim.','macOS has no Linux cgroup host OOM counters.','Full process lists, executable paths and private application names omitted.']
    parts=['# Local PR #154 benchmark (2026-11-05, Asia/Seoul)',f'Base `{BASE}` → head `{HEAD}`. **Correctness and coverage: PASS** (15 core checks; no core errors; Apple full-response oracle, all scoped requests and parity passed). **Formal performance acceptance: not established.**',
    'This is a local comparison of the unmodified trusted main controller plus a separate real Apple/JVM three-graph supplement. Measurements below are observations, not latency/CPU/RSS regression acceptance. All signs and absolute changes are retained; no favorable-case selection.']
    def core_table(selected,stage='pressure'):
        rows=[]
        for c in selected:
            a=core.get((stage,c,'p50'));b=core.get((stage,c,'p95'))
            if not a or not b:continue
            rows.append([c,fmt(a['baseMs']),fmt(a['headMs']),fmt(None if a['baseMs'] is None or a['headMs'] is None else a['headMs']-a['baseMs']),percent(a['baseMs'],a['headMs']),fmt(b['baseMs']),fmt(b['headMs']),fmt(None if b['baseMs'] is None or b['headMs'] is None else b['headMs']-b['baseMs']),percent(b['baseMs'],b['headMs']),f"{a['samplesBase']}/{a['samplesHead']}"])
        return table(['Case','Base p50 ms','Head p50 ms','Δ p50 ms','Δ p50 %','Base p95 ms','Head p95 ms','Δ p95 ms','Δ p95 %','N base/head'],rows)
    top=sorted(cases,key=lambda c:(-core[('pressure',c,'p95')]['baseMs'],c))[:5]
    slow50=[core[('pressure',c,'p50')]['headMs']-core[('pressure',c,'p50')]['baseMs'] for c in top]
    slow95=[core[('pressure',c,'p95')]['headMs']-core[('pressure',c,'p95')]['baseMs'] for c in top]
    if all(v>0 for v in slow50+slow95):
        parts += [f"**Observed query regression in this run:** the five highest-baseline-p95 cases all have higher head p50 and p95. Their case-level absolute p50 increases range from {fmt(min(slow50))} to {fmt(max(slow50))} ms; p95 increases range from {fmt(min(slow95))} to {fmt(max(slow95))} ms. Tables below retain each case and its percentage change. These are observed increases; this single ordered pair cannot isolate code effects from interactive-machine noise. Construction/loading observations remain separate conclusions."]
    parts+=['## Real64 server pressure','64 distinct persisted class shards from four pinned real JAR corpora (Android, Tika, Hive, Kotlin compiler). Every request uses the global graph scope. Concurrency 4; 20 measured requests per case after two warmups and one first-use oracle. Nearest-rank p50/p95 are computed per case through full HTTP body consumption, never pooled across cases. Fixed batches are not a saturation test.','Five cases selected by highest absolute baseline p95:',core_table(top),collapsed('All 73 pressure cases',core_table(cases))]
    worse50=sum(core[('pressure',c,'p50')]['headMs']>core[('pressure',c,'p50')]['baseMs'] for c in cases);worse95=sum(core[('pressure',c,'p95')]['headMs']>core[('pressure',c,'p95')]['baseMs'] for c in cases)
    parts+=[f'Head observations are higher in {worse50}/73 case p50 values and {worse95}/73 case p95 values; these counts do not establish statistical significance or recovery.',collapsed('Separate isolated observations (not replacements for pressure)', 'Each arm independently selects cases whose pressure p50 is below 100 ms, then takes 40 requests at concurrency 1. In this run, 67 cases were selected in both arms and all scheduled samples are present. The six slow cases were not scheduled by the predeclared rule; their isolated UNAVAILABLE values mean not scheduled. UNAVAILABLE is not zero. These short-case observations are secondary and do not select a performance candidate.\n\n'+core_table(cases,'isolated'))]
    singles=suites['frontend-build-save']['timings']+[t for t in native['timings'] if t['case']=='real64-loading']
    need(len(singles)==3 and all(t['samplesBase']==1 and t['samplesHead']==1 and t['comparable'] for t in singles),'core single-shot boundary coverage')
    parts+=['## Core construction and loading',table(['Boundary','Base ms','Head ms','Δ ms','N base/head'],[[t['case']+' / '+t['stage'],fmt(t['baseMs']),fmt(t['headMs']),fmt(t['headMs']-t['baseMs']),'1/1'] for t in singles]),'Construction runs through usable saved graphs. Loading is shown separately through registry readiness and through the complete first-use oracle, exposing deferred work. These N=1 boundaries are report-only. Core process CPU and peak RSS were not collected by this protocol; no resource recovery claim is possible.']
    qs={(s['variant'],s['case'],s['concurrency']):s for s in apple['query']['summary']['queries']};arows=[];cpurows=[]
    for c in [c['name'] for c in config['protocol']['cases']]:
        for concurrency in [1,4]:
            a,b=[qs[(v,c,concurrency)] for v in ['baseline','candidate']]
            cpus=[sum(r['cpu_seconds'] for r in apple['query']['batches'] if r['variant']==v and r['case']==c and r['concurrency']==concurrency)*1000/300 for v in ['baseline','candidate']]
            arows.append([c,concurrency,fmt(a['p50_ms']),fmt(b['p50_ms']),fmt(b['p50_ms']-a['p50_ms']),percent(a['p50_ms'],b['p50_ms']),fmt(a['p95_ms']),fmt(b['p95_ms']),fmt(b['p95_ms']-a['p95_ms']),percent(a['p95_ms'],b['p95_ms']),rng(a['round_p95_range_ms']),rng(b['round_p95_range_ms'])])
            cpurows.append([c,concurrency,fmt(cpus[0]),fmt(cpus[1]),fmt(cpus[1]-cpus[0]),percent(cpus[0],cpus[1]),'300/300'])
    parts+=['## Apple/JVM three-graph supplement','Each request explicitly spans Signal iOS, SwiftPM and Signal Server. Four cases cover calls, literal-to-call provenance, field types and same wire literals on different graphs. The independent oracle saved full responses twice per case/arm and proved at least two represented graphs, exact typed-result parity and cross-graph wire pairs. All 4800 measured and 120 warmup requests succeeded. Each table arm has 300 measured requests per case/concurrency, across three paired AB/BA/AB rounds; five warmups per case precede measured batches. Percentiles use nearest rank; ranges are the three round p95 values.',table(['Case','C','Base p50 ms','Head p50 ms','Δ p50 ms','Δ p50 %','Base p95 ms','Head p95 ms','Δ p95 ms','Δ p95 %','Base round p95 range','Head round p95 range'],arows),'Server CPU per completed request (batch user+system delta; separate from response latency):',table(['Case','C','Base CPU ms/req','Head CPU ms/req','Δ CPU ms/req','Δ CPU %','N base/head'],cpurows)]
    loads=apple['load']['loads'];lr=[];rss=[]
    for v in ['baseline','candidate']:
        z=[r for r in loads if r['variant']==v];lr.append([v,3,rng([r['wall_ms'] for r in z]),fmt(q([r['wall_ms'] for r in z],.5)),rng([r['cpu_seconds']*1000 for r in z])])
        for op in ['load','query']:
            z=[r for r in apple[op]['resources'] if r['variant']==v];rss.append([v,op,3,rng([r['peak_process_rss_bytes']/1024**2 for r in z]),rng([r['cpu_seconds']*1000 for r in z])])
    parts+=['Apple load ends after readiness and consumption of all four cases, including deferred work:',table(['Arm','Rounds','Load wall range ms','Median wall ms','Boundary CPU range ms'],lr),'Process lifetime resource accounting is separate:',table(['Arm','Operation','Processes','Peak RSS range MiB','Lifetime CPU range ms'],rss),'Query CPU ms/request is the sum of live server user+system deltas over the three 100-request batches divided by 300. macOS Mach ticks are converted using mach_timebase_info; Linux uses /proc clock ticks. wait4 peak process RSS includes startup and warmup, requests and shutdown: it is not query-only RSS. Periodic current-RSS samples are only lower bounds. Load boundary CPU differs deliberately from full process-lifetime CPU.',f"Connection/readiness retries retained: load {apple['load']['readinessRetries']}, query {apple['query']['readinessRetries']}. These are startup polling attempts, separate from the zero failures in measured, warmup and load-consumption requests. No failed journal operation or incomplete server lifecycle was accepted."]
    parts+=['## Reproduction and limitations',f"Hardware: {publicenv.get('cpu','unknown')}, {publicenv.get('logicalCpus','unknown')} logical CPUs, {publicenv.get('memoryBytes',0)/1024**3:.0f} GiB RAM; {publicenv.get('platform','unknown')}. Java: {publicenv.get('java','unknown').splitlines()[0]}. Sanitized details: [environment.json](environment.json).",'Trusted controller source is base 7c59d799; product source revisions are the exact base/head above. The main pipeline uses locked release native builds and fresh real64 construction. JVM producers/forks use G1 with a 4 GiB maximum heap and ExitOnOutOfMemoryError (below the 8 GiB ceiling). macOS lacks Linux cgroup OOM counters; process survival and JVM receipts are checked, but no Linux host-OOM claim is made. Input hashes and product identities are retained in the core report.','The initial Git-worktree preparation failed in Gradle/JGit before measurement; original run/ evidence is retained. The successful run-standalone/ uses standalone exact-commit source checkouts. No failed preparation sample is treated as a measurement.','The supplementary harness is frozen in apple/apple-lifecycle.py; config, PROTOCOL.md, provenance.json and oracle.py describe the exact commands. Oracle → load → query must execute after the core pipeline is idle. No cache eviction was performed; filesystem cache is warm/uncontrolled and ambient workstation load is not assumed absent.','Both supplementary arms use the same final Signal persisted graph (packed SHA 31788b41dc78ae25c46f2614125254bc5dfeb934d794aa51964b277ed0a2eeaf), produced from the unchanged Swift IR and repaired fc88002a JVM consumer, with full 560895-node/199849-edge/enum-metadata roundtrip verification. The older 2881-consumer graph is excluded. Signal includes five explicitly accepted dictionary-valued plist omissions. SwiftPM and Signal Server are pinned real-source legacy graphs, not rebuilt by the current head; SwiftPM legacy importer SHA was not recorded in its import log. Their actual persisted file hashes are retained. This isolates native consumers and does not establish Apple construction performance or current producer completeness.','All raw results, errors, complete response oracles and commands are retained in the downloadable evidence archive. Public environment output intentionally excludes the process list and private application names. No thresholds were relaxed and no formal performance acceptance is claimed.']
    parts += ['Evidence: [download and integrity instructions](DOWNLOAD.md), [core report](core-report.json), [independent core sample verification](core-sample-verification.json), [Apple full-response oracle](apple-oracle.json), [Apple query summary](apple-query-summary.json), [Apple load summary](apple-load-summary.json).',
    'The trusted [benchmark protocol](https://github.com/johnsonlee/graphite/blob/'+BASE+'/benchmark/README.md), [native request catalogue](https://github.com/johnsonlee/graphite/blob/'+BASE+'/benchmark/src/native_queries.json), and [fixture preparation](https://github.com/johnsonlee/graphite/blob/'+BASE+'/benchmark/src/prepare.rs) are pinned to the exact base commit. Source JAR hashes are retained in core-report.json; Apple source commits, graph producers and query text are in the archive’s apple/provenance.json and apple/config.json.',
    'Reproduction uses Java 17 and independent standalone clones (not Git worktrees). Choose a fresh working directory and fresh output directories. On macOS, set JAVA_HOME to the installed JDK 17 before running:',
    '```bash\nexport JAVA_HOME="$(/usr/libexec/java_home -v 17)"\nexport PATH="$JAVA_HOME/bin:$PATH"\nfor role in base-standalone head-standalone trusted; do\n  git clone https://github.com/johnsonlee/graphite.git "$role"\ndone\ngit -C base-standalone checkout --detach '+BASE+'\ngit -C head-standalone checkout --detach '+HEAD+'\ngit -C trusted checkout --detach '+BASE+'\ncargo build --release --locked --manifest-path trusted/Cargo.toml \\\n  --target-dir controller-target -p graphite-benchmark\ncontroller-target/release/graphite-benchmark run \\\n  --base-source base-standalone --head-source head-standalone \\\n  --harness-source trusted --output run-standalone\n# After the core pipeline stops, use the archived Apple scripts/config.\n# Rebind graph and prepared-binary paths to the reproduced local artifacts.\ncd apple\npython3 oracle.py config.json --out oracle\npython3 apple-lifecycle.py load config.json --out load\npython3 apple-lifecycle.py query config.json --out query\ncd ..\npython3 render-report.py\n```',
    'Java 17 is required for these recorded builds. The evidence archive supplies exact Apple config paths and source identities, not the large graph and binary payloads that remain local; recreate or provide the same verified graph inputs before replay. Rendering does not execute any benchmark. Percent changes are UNAVAILABLE for a zero or missing baseline; absolute changes remain primary.']
    text='\n\n'.join(parts)+'\n';public=root/'public';public.mkdir(exist_ok=True)
    # Nothing is emitted until all validation above succeeds.
    (public/'environment.json').write_text(json.dumps(publicenv,indent=2)+'\n');(public/'README.md').write_text(text)
    appendix=text.replace('# Local PR #154 benchmark','## Local benchmark appendix',1).replace('[environment.json](environment.json)','sanitized environment.json in the attached benchmark evidence')
    for name in ('DOWNLOAD.md','core-report.json','apple-query-summary.json','apple-load-summary.json','apple-oracle.json','core-sample-verification.json'):
        appendix=appendix.replace(']('+name+')','](__EVIDENCE_BASE__/'+name+')')
    (root/'pr-body-benchmark.md').write_text(appendix + '\n[Immutable benchmark evidence and full report](__EVIDENCE_URL__)\n')
    (public/'render-validation.json').write_text(json.dumps({'passed':True,'base':BASE,'head':HEAD,'coreChecks':15,'appleMeasuredRequests':4800,'appleWarmupRequests':120,'formalPerformanceAcceptance':False,'sourceReportSha256':sha(root/'run-standalone/report/report.json'),'rendererSha256':sha(Path(__file__))},indent=2)+'\n')
    print('Rendered verified public README, sanitized environment and PR appendix; nothing published.')
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--root',type=Path,default=Path(__file__).resolve().parent);a=p.parse_args();main(a.root)
