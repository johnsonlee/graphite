#!/usr/bin/env python3
"""Independent cross-check of report quantiles against retained request records."""
import collections
import json
import math
from pathlib import Path

root = Path(__file__).resolve().parent
report = json.loads((root / "run-standalone/report/report.json").read_text())
assert report["passed"] and not report["errors"]
suite = next(s for s in report["suites"] if s["suite"] == "native-real64")
summary = {}
for arm in ("base", "head"):
    records = json.loads((root / f"run-standalone/results/native/{arm}-requests.json").read_text())
    assert records and all(r["passed"] and not r["error"] for r in records)
    assert all(len(r["graphIds"]) == len(set(r["graphIds"])) == 64 for r in records)
    groups = collections.defaultdict(list)
    for r in records:
        groups[r["stage"], r["case"]].append(r["requestMs"])
    pressure = {c: v for (s, c), v in groups.items() if s == "pressure"}
    assert len(pressure) == 73 and all(len(v) == 20 for v in pressure.values())
    checked = 0
    for t in suite["timings"]:
        if t["stage"] not in ("pressure", "isolated"):
            continue
        values = sorted(groups.get((t["stage"], t["case"]), []))
        observed = t[arm + "Ms"]
        if observed is None:
            assert not values
            continue
        p = .95 if "nearest-rank p95;" in t["method"] else .5
        expected = values[math.ceil(len(values) * p) - 1]
        assert math.isclose(expected, observed, rel_tol=1e-10, abs_tol=1e-8), (arm, t["case"])
        assert len(values) == t["samplesBase" if arm == "base" else "samplesHead"]
        checked += 1
    summary[arm] = {"requestRecords": len(records), "pressureCases": len(pressure),
                    "pressureRequests": sum(map(len, pressure.values())), "quantilesChecked": checked}
out = {"passed": True, "base": report["baseSha"], "head": report["headSha"],
       "requestScope": "64 graph IDs on every retained request", "arms": summary}
(root / "core-sample-verification.json").write_text(json.dumps(out, indent=2) + "\n")
print(json.dumps(out, indent=2))
