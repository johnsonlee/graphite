# Benchmark correctness and OOM: FAIL

Timing is report-only. No latency, throughput, CPU or RSS threshold affects acceptance. These GitHub runner observations do not establish performance regression acceptance. Missing observations are UNAVAILABLE.

- Preparation failed; see prepared/preparation.json

## frontend-build-save

Base: `7c59d7993be51f0807495890d068effcfaff155b`  
Head: `190eba79a4428d3100c8fba480bd858a19ac893d`

| Gate | Kind | Result | Detail |
| --- | --- | --- | --- |
| runner | correctness | FAIL | No such file or directory (os error 2) |
| heap evidence | heap | FAIL | Required execution did not complete |
| required coverage | coverage | FAIL | Required execution did not complete |

| Case | Stage | Workload | Method | Samples base/head | Base ms | Head ms | Delta ms | Delta % | Evidence |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |

Timing: UNAVAILABLE.

Raw artifacts are retained alongside the suite JSON.

## native-real64

Base: `7c59d7993be51f0807495890d068effcfaff155b`  
Head: `190eba79a4428d3100c8fba480bd858a19ac893d`

| Gate | Kind | Result | Detail |
| --- | --- | --- | --- |
| base-real64-pressure-correctness | correctness | FAIL | No such file or directory (os error 2) |
| head-real64-pressure-correctness | correctness | FAIL | No such file or directory (os error 2) |
| matched-real-source-inputs | coverage | FAIL | source JAR/shard hashes match: false; exact 73 query texts match: false |
| base-head-reviewed-semantics | correctness | FAIL | Exact queries and complete typed responses, or compiled-in directed expectations bound to both product content identities; exact query match: false; exact response match: false; see semantic-transitions.json |
| fixed-real64-pressure-protocol | coverage | FAIL | 73 cases; concurrency4; first-use1/warmup2/pressure20; pressure p50&lt;100ms selects isolated40 at concurrency1. Selection changes reporting only, never acceptance. |
| native-host-oom | heap | PASS | No Linux cgroup accounting on this platform; process failures are checked; formal hosted OOM evidence requires Linux |
| base-native-concurrent-error-recovery | correctness | FAIL | Capacity probes did not complete |
| head-native-concurrent-error-recovery | correctness | FAIL | Capacity probes did not complete |

Base: UNAVAILABLE — No such file or directory (os error 2)

Head: UNAVAILABLE — No such file or directory (os error 2)

| Case | Stage | Workload | Method | Samples base/head | Base ms | Head ms | Delta ms | Delta % | Evidence |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| real64-loading | registry-ready | real64 | single fresh-process boundary; REPORT_ONLY; filesystem cache uncontrolled | 0/0 | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE | Execution or comparability checks failed |
| real64-loading | startup-through-first-use-oracle | real64 | single fresh-process boundary; REPORT_ONLY; filesystem cache uncontrolled | 0/0 | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE | Execution or comparability checks failed |

Raw artifacts are retained alongside the suite JSON.
