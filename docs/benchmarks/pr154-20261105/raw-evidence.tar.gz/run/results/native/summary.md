## Benchmark correctness and OOM: FAIL

Timing differences are **report-only**; correctness, OOM and required coverage decide this gate. GitHub runner timings do not establish performance acceptance.

Base: `7c59d7993be51f0807495890d068effcfaff155b`  
Head: `190eba79a4428d3100c8fba480bd858a19ac893d`

### native-real64

- **FAIL** base-real64-pressure-correctness: No such file or directory (os error 2)
- **FAIL** head-real64-pressure-correctness: No such file or directory (os error 2)
- **FAIL** matched-real-source-inputs: source JAR/shard hashes match: false; exact 73 query texts match: false
- **FAIL** base-head-reviewed-semantics: Exact queries and complete typed responses, or compiled-in directed expectations bound to both product content identities; exact query match: false; exact response match: false; see semantic-transitions.json
- **FAIL** fixed-real64-pressure-protocol: 73 cases; concurrency4; first-use1/warmup2/pressure20; pressure p50&lt;100ms selects isolated40 at concurrency1. Selection changes reporting only, never acceptance.
- **PASS** native-host-oom: No Linux cgroup accounting on this platform; process failures are checked; formal hosted OOM evidence requires Linux
- **FAIL** base-native-concurrent-error-recovery: Capacity probes did not complete
- **FAIL** head-native-concurrent-error-recovery: Capacity probes did not complete

| Case | Stage | Measurement | N base/head | Base ms | Head ms | Delta ms | Delta % |
| --- | --- | --- | --- | ---: | ---: | ---: | ---: |
| real64-loading | registry-ready | single fresh-process boundary | 0/0 | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| real64-loading | startup-through-first-use-oracle | single fresh-process boundary | 0/0 | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |

Full methods, comparability reasons, isolated observations, raw request bodies and logs are retained in the downloadable report/evidence artifacts. UNAVAILABLE never means zero; a zero baseline has no defined percentage change.
