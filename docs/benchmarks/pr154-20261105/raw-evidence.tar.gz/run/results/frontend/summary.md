## Benchmark correctness and OOM: FAIL

Timing differences are **report-only**; correctness, OOM and required coverage decide this gate. GitHub runner timings do not establish performance acceptance.

Base: `7c59d7993be51f0807495890d068effcfaff155b`  
Head: `190eba79a4428d3100c8fba480bd858a19ac893d`

### frontend-build-save

- **FAIL** runner: No such file or directory (os error 2)
- **FAIL** heap evidence: Required execution did not complete
- **FAIL** required coverage: Required execution did not complete

| Case | Stage | Measurement | N base/head | Base ms | Head ms | Delta ms | Delta % |
| --- | --- | --- | --- | ---: | ---: | ---: | ---: |

Full methods, comparability reasons, isolated observations, raw request bodies and logs are retained in the downloadable report/evidence artifacts. UNAVAILABLE never means zero; a zero baseline has no defined percentage change.
