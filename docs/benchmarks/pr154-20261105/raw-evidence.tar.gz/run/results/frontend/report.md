# Benchmark correctness and OOM: FAIL

Timing is report-only. No latency, throughput, CPU or RSS threshold affects acceptance. These GitHub runner observations do not establish performance regression acceptance. Missing observations are UNAVAILABLE.

## frontend-build-save

Base: `7c59d7993be51f0807495890d068effcfaff155b`  
Head: `190eba79a4428d3100c8fba480bd858a19ac893d`

| Gate | Kind | Result | Detail |
| --- | --- | --- | --- |
| runner | correctness | FAIL | No such file or directory (os error 2) |
| heap evidence | heap | FAIL | Required execution did not complete |
| required coverage | coverage | FAIL | Required execution did not complete |

| Case | Stage | Workload | Method | Samples base/head | Base ms | Head ms | Delta ms | Delta % | Evidence |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |

Timing: UNAVAILABLE.

Raw artifacts are retained alongside the suite JSON.
