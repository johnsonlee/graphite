## Benchmark correctness and OOM: PASS

Timing differences are **report-only**; correctness, OOM and required coverage decide this gate. GitHub runner timings do not establish performance acceptance.

Base: `7c59d7993be51f0807495890d068effcfaff155b`  
Head: `190eba79a4428d3100c8fba480bd858a19ac893d`

### frontend-build-save

- **PASS** base frontend build/save correctness: fresh real64 build/save plus whole Tika/Hive/Kotlin correctness/readback complete; 7 G1 JVM receipts under 4 GiB; ExitOnOutOfMemoryError rejects even recoverable production OOM
- **PASS** base frontend build/save heap: fresh real64 build/save plus whole Tika/Hive/Kotlin correctness/readback complete; 7 G1 JVM receipts under 4 GiB; ExitOnOutOfMemoryError rejects even recoverable production OOM
- **PASS** base frontend build/save coverage: fresh real64 build/save plus whole Tika/Hive/Kotlin correctness/readback complete; 7 G1 JVM receipts under 4 GiB; ExitOnOutOfMemoryError rejects even recoverable production OOM
- **PASS** head frontend build/save correctness: fresh real64 build/save plus whole Tika/Hive/Kotlin correctness/readback complete; 7 G1 JVM receipts under 4 GiB; ExitOnOutOfMemoryError rejects even recoverable production OOM
- **PASS** head frontend build/save heap: fresh real64 build/save plus whole Tika/Hive/Kotlin correctness/readback complete; 7 G1 JVM receipts under 4 GiB; ExitOnOutOfMemoryError rejects even recoverable production OOM
- **PASS** head frontend build/save coverage: fresh real64 build/save plus whole Tika/Hive/Kotlin correctness/readback complete; 7 G1 JVM receipts under 4 GiB; ExitOnOutOfMemoryError rejects even recoverable production OOM
- **PASS** host OOM events: before=None; after=None

| Case | Stage | Measurement | N base/head | Base ms | Head ms | Delta ms | Delta % |
| --- | --- | --- | --- | ---: | ---: | ---: | ---: |
| real64-build-save | frontend-build-save | JMH SingleShotTime | 1/1 | 280728.161 | 266061.404 | -14666.757 | -5.22% |

### native-real64

- **PASS** base-real64-pressure-correctness: All complete responses, repeated-request stability and semantic scope assertions passed
- **PASS** head-real64-pressure-correctness: All complete responses, repeated-request stability and semantic scope assertions passed
- **PASS** matched-real-source-inputs: source JAR/shard hashes match: true; exact 73 query texts match: true
- **PASS** base-head-reviewed-semantics: Exact queries and complete typed responses, or compiled-in directed expectations bound to both product content identities; exact query match: true; exact response match: true; see semantic-transitions.json
- **PASS** fixed-real64-pressure-protocol: 73 cases; concurrency4; first-use1/warmup2/pressure20; pressure p50&lt;100ms selects isolated40 at concurrency1. Selection changes reporting only, never acceptance.
- **PASS** native-host-oom: No Linux cgroup accounting on this platform; process failures are checked; formal hosted OOM evidence requires Linux
- **PASS** base-native-concurrent-error-recovery: Separate real64 server: four concurrent complete requests, outcome metrics, invalid inputs and exact recovery results passed; deterministic rejection/deadline contracts are covered by production-handler unit tests, not these paired network probes; no performance samples
- **PASS** head-native-concurrent-error-recovery: Separate real64 server: four concurrent complete requests, outcome metrics, invalid inputs and exact recovery results passed; deterministic rejection/deadline contracts are covered by production-handler unit tests, not these paired network probes; no performance samples

| Case | Stage | Measurement | N base/head | Base ms | Head ms | Delta ms | Delta % |
| --- | --- | --- | --- | ---: | ---: | ---: | ---: |
| real64-loading | registry-ready | single fresh-process boundary | 1/1 | 20095.892 | 19637.295 | -458.597 | -2.28% |
| real64-loading | startup-through-first-use-oracle | single fresh-process boundary | 1/1 | 22414.732 | 22378.459 | -36.272 | -0.16% |
| zero/global-wide-four-properties | pressure | nearest-rank p50 | 20/20 | 0.362 | 0.381 | 0.020 | +5.41% |
| zero/global-wide-four-properties | pressure | nearest-rank p95 | 20/20 | 0.451 | 0.512 | 0.061 | +13.51% |
| zero/global-wide-class-pair | pressure | nearest-rank p50 | 20/20 | 0.311 | 0.344 | 0.033 | +10.53% |
| zero/global-wide-class-pair | pressure | nearest-rank p95 | 20/20 | 0.421 | 0.503 | 0.082 | +19.43% |
| zero/global-wide-name-pair | pressure | nearest-rank p50 | 20/20 | 0.274 | 0.299 | 0.026 | +9.43% |
| zero/global-wide-name-pair | pressure | nearest-rank p95 | 20/20 | 0.385 | 0.428 | 0.043 | +11.09% |
| zero/global-wide-caller-class | pressure | nearest-rank p50 | 20/20 | 0.290 | 0.303 | 0.013 | +4.52% |
| zero/global-wide-caller-class | pressure | nearest-rank p95 | 20/20 | 0.361 | 0.547 | 0.186 | +51.56% |
| zero/global-wide-callee-class | pressure | nearest-rank p50 | 20/20 | 0.278 | 0.280 | 0.002 | +0.78% |
| zero/global-wide-callee-class | pressure | nearest-rank p95 | 20/20 | 0.359 | 0.399 | 0.040 | +11.06% |
| zero/global-wide-provenance | pressure | nearest-rank p50 | 20/20 | 0.252 | 0.298 | 0.046 | +18.20% |
| zero/global-wide-provenance | pressure | nearest-rank p95 | 20/20 | 0.344 | 0.415 | 0.071 | +20.75% |
| zero/global-wide-aliased | pressure | nearest-rank p50 | 20/20 | 0.263 | 0.293 | 0.030 | +11.44% |
| zero/global-wide-aliased | pressure | nearest-rank p95 | 20/20 | 0.413 | 0.523 | 0.110 | +26.52% |
| zero/global-wide-parameterized-as-literal | pressure | nearest-rank p50 | 20/20 | 0.239 | 0.286 | 0.047 | +19.47% |
| zero/global-wide-parameterized-as-literal | pressure | nearest-rank p95 | 20/20 | 0.359 | 0.411 | 0.052 | +14.46% |
| zero/global-wide-wrapped-case-insensitive | pressure | nearest-rank p50 | 20/20 | 0.238 | 0.278 | 0.040 | +16.98% |
| zero/global-wide-wrapped-case-insensitive | pressure | nearest-rank p95 | 20/20 | 0.336 | 0.460 | 0.124 | +36.88% |
| zero/global-wide-wrapped-case-insensitive-distinct | pressure | nearest-rank p50 | 20/20 | 0.291 | 0.304 | 0.013 | +4.55% |
| zero/global-wide-wrapped-case-insensitive-distinct | pressure | nearest-rank p95 | 20/20 | 0.378 | 0.461 | 0.083 | +22.03% |
| targeted/global-wide-four-properties | pressure | nearest-rank p50 | 20/20 | 0.572 | 0.585 | 0.013 | +2.22% |
| targeted/global-wide-four-properties | pressure | nearest-rank p95 | 20/20 | 0.696 | 0.694 | -0.002 | -0.30% |
| targeted/global-wide-class-pair | pressure | nearest-rank p50 | 20/20 | 0.436 | 0.469 | 0.034 | +7.75% |
| targeted/global-wide-class-pair | pressure | nearest-rank p95 | 20/20 | 0.574 | 0.652 | 0.078 | +13.61% |
| targeted/global-wide-name-pair | pressure | nearest-rank p50 | 20/20 | 0.424 | 0.461 | 0.037 | +8.63% |
| targeted/global-wide-name-pair | pressure | nearest-rank p95 | 20/20 | 0.581 | 0.618 | 0.037 | +6.38% |
| targeted/global-wide-caller-class | pressure | nearest-rank p50 | 20/20 | 0.416 | 0.433 | 0.017 | +3.99% |
| targeted/global-wide-caller-class | pressure | nearest-rank p95 | 20/20 | 0.521 | 0.606 | 0.085 | +16.40% |
| targeted/global-wide-callee-class | pressure | nearest-rank p50 | 20/20 | 0.401 | 0.444 | 0.042 | +10.56% |
| targeted/global-wide-callee-class | pressure | nearest-rank p95 | 20/20 | 0.558 | 0.613 | 0.055 | +9.93% |
| targeted/global-wide-provenance | pressure | nearest-rank p50 | 20/20 | 0.417 | 0.406 | -0.010 | -2.50% |
| targeted/global-wide-provenance | pressure | nearest-rank p95 | 20/20 | 0.521 | 0.632 | 0.111 | +21.37% |
| targeted/global-wide-aliased | pressure | nearest-rank p50 | 20/20 | 0.405 | 0.434 | 0.029 | +7.23% |
| targeted/global-wide-aliased | pressure | nearest-rank p95 | 20/20 | 0.526 | 0.599 | 0.073 | +13.91% |
| targeted/global-wide-parameterized-as-literal | pressure | nearest-rank p50 | 20/20 | 0.398 | 0.418 | 0.019 | +4.80% |
| targeted/global-wide-parameterized-as-literal | pressure | nearest-rank p95 | 20/20 | 0.568 | 0.577 | 0.009 | +1.61% |
| targeted/global-wide-wrapped-case-insensitive | pressure | nearest-rank p50 | 20/20 | 0.407 | 0.415 | 0.007 | +1.77% |
| targeted/global-wide-wrapped-case-insensitive | pressure | nearest-rank p95 | 20/20 | 0.480 | 0.611 | 0.131 | +27.32% |
| targeted/global-wide-wrapped-case-insensitive-distinct | pressure | nearest-rank p50 | 20/20 | 0.461 | 0.463 | 0.002 | +0.43% |
| targeted/global-wide-wrapped-case-insensitive-distinct | pressure | nearest-rank p95 | 20/20 | 0.545 | 0.699 | 0.154 | +28.16% |
| dense/global-wide-four-properties | pressure | nearest-rank p50 | 20/20 | 1.046 | 1.085 | 0.040 | +3.78% |
| dense/global-wide-four-properties | pressure | nearest-rank p95 | 20/20 | 1.565 | 1.629 | 0.064 | +4.07% |
| dense/global-wide-class-pair | pressure | nearest-rank p50 | 20/20 | 1.048 | 1.072 | 0.024 | +2.28% |
| dense/global-wide-class-pair | pressure | nearest-rank p95 | 20/20 | 1.453 | 1.259 | -0.194 | -13.37% |
| dense/global-wide-name-pair | pressure | nearest-rank p50 | 20/20 | 0.985 | 1.046 | 0.061 | +6.23% |
| dense/global-wide-name-pair | pressure | nearest-rank p95 | 20/20 | 1.345 | 1.507 | 0.162 | +12.03% |
| dense/global-wide-caller-class | pressure | nearest-rank p50 | 20/20 | 0.984 | 1.063 | 0.078 | +7.97% |
| dense/global-wide-caller-class | pressure | nearest-rank p95 | 20/20 | 1.265 | 1.575 | 0.309 | +24.46% |
| dense/global-wide-callee-class | pressure | nearest-rank p50 | 20/20 | 0.946 | 1.019 | 0.072 | +7.65% |
| dense/global-wide-callee-class | pressure | nearest-rank p95 | 20/20 | 1.501 | 1.417 | -0.084 | -5.58% |
| dense/global-wide-provenance | pressure | nearest-rank p50 | 20/20 | 1.021 | 1.082 | 0.062 | +6.05% |
| dense/global-wide-provenance | pressure | nearest-rank p95 | 20/20 | 1.303 | 1.635 | 0.333 | +25.53% |
| dense/global-wide-aliased | pressure | nearest-rank p50 | 20/20 | 1.055 | 1.101 | 0.046 | +4.39% |
| dense/global-wide-aliased | pressure | nearest-rank p95 | 20/20 | 1.434 | 1.603 | 0.169 | +11.78% |
| dense/global-wide-parameterized-as-literal | pressure | nearest-rank p50 | 20/20 | 1.077 | 1.101 | 0.024 | +2.23% |
| dense/global-wide-parameterized-as-literal | pressure | nearest-rank p95 | 20/20 | 1.336 | 1.503 | 0.167 | +12.53% |
| dense/global-wide-wrapped-case-insensitive | pressure | nearest-rank p50 | 20/20 | 1.190 | 1.241 | 0.052 | +4.33% |
| dense/global-wide-wrapped-case-insensitive | pressure | nearest-rank p95 | 20/20 | 1.402 | 1.805 | 0.403 | +28.72% |
| dense/global-wide-wrapped-case-insensitive-distinct | pressure | nearest-rank p50 | 20/20 | 3.183 | 3.421 | 0.238 | +7.48% |
| dense/global-wide-wrapped-case-insensitive-distinct | pressure | nearest-rank p95 | 20/20 | 3.590 | 4.232 | 0.642 | +17.88% |
| localized-early/global-wide-four-properties | pressure | nearest-rank p50 | 20/20 | 0.440 | 0.422 | -0.018 | -4.09% |
| localized-early/global-wide-four-properties | pressure | nearest-rank p95 | 20/20 | 0.727 | 0.687 | -0.040 | -5.53% |
| localized-middle/global-wide-four-properties | pressure | nearest-rank p50 | 20/20 | 0.578 | 0.610 | 0.032 | +5.46% |
| localized-middle/global-wide-four-properties | pressure | nearest-rank p95 | 20/20 | 1.086 | 0.800 | -0.286 | -26.31% |
| localized-late/global-wide-four-properties | pressure | nearest-rank p50 | 20/20 | 0.576 | 0.621 | 0.044 | +7.71% |
| localized-late/global-wide-four-properties | pressure | nearest-rank p95 | 20/20 | 0.806 | 0.880 | 0.074 | +9.12% |
| broad-all-64/global-wide-four-properties | pressure | nearest-rank p50 | 20/20 | 0.983 | 1.075 | 0.092 | +9.38% |
| broad-all-64/global-wide-four-properties | pressure | nearest-rank p95 | 20/20 | 1.388 | 1.520 | 0.132 | +9.51% |
| schema-label-histogram | pressure | nearest-rank p50 | 20/20 | 0.545 | 0.602 | 0.058 | +10.59% |
| schema-label-histogram | pressure | nearest-rank p95 | 20/20 | 0.632 | 0.787 | 0.155 | +24.61% |
| schema-key-histogram | pressure | nearest-rank p50 | 20/20 | 0.915 | 1.037 | 0.122 | +13.33% |
| schema-key-histogram | pressure | nearest-rank p95 | 20/20 | 1.102 | 1.466 | 0.364 | +33.03% |
| schema-relationship-histogram | pressure | nearest-rank p50 | 20/20 | 15.238 | 16.759 | 1.521 | +9.98% |
| schema-relationship-histogram | pressure | nearest-rank p95 | 20/20 | 18.077 | 19.644 | 1.567 | +8.67% |
| shape-wide-contains | pressure | nearest-rank p50 | 20/20 | 0.593 | 0.665 | 0.072 | +12.23% |
| shape-wide-contains | pressure | nearest-rank p95 | 20/20 | 0.798 | 0.906 | 0.108 | +13.50% |
| shape-label-scan-callsite | pressure | nearest-rank p50 | 20/20 | 0.420 | 0.489 | 0.069 | +16.30% |
| shape-label-scan-callsite | pressure | nearest-rank p95 | 20/20 | 0.681 | 0.837 | 0.156 | +22.88% |
| shape-label-scan-method | pressure | nearest-rank p50 | 20/20 | 0.398 | 0.444 | 0.046 | +11.44% |
| shape-label-scan-method | pressure | nearest-rank p95 | 20/20 | 0.710 | 0.738 | 0.028 | +3.94% |
| shape-label-scan-constant | pressure | nearest-rank p50 | 20/20 | 0.389 | 0.412 | 0.024 | +6.10% |
| shape-label-scan-constant | pressure | nearest-rank p95 | 20/20 | 1.026 | 0.649 | -0.376 | -36.68% |
| shape-label-scan-field | pressure | nearest-rank p50 | 20/20 | 0.372 | 0.397 | 0.026 | +6.89% |
| shape-label-scan-field | pressure | nearest-rank p95 | 20/20 | 0.953 | 0.640 | -0.313 | -32.80% |
| shape-all-nodes | pressure | nearest-rank p50 | 20/20 | 0.724 | 0.827 | 0.104 | +14.33% |
| shape-all-nodes | pressure | nearest-rank p95 | 20/20 | 1.436 | 1.344 | -0.092 | -6.41% |
| shape-equality | pressure | nearest-rank p50 | 20/20 | 0.559 | 0.595 | 0.036 | +6.43% |
| shape-equality | pressure | nearest-rank p95 | 20/20 | 0.776 | 0.741 | -0.035 | -4.53% |
| shape-inequality | pressure | nearest-rank p50 | 20/20 | 0.379 | 0.447 | 0.068 | +17.81% |
| shape-inequality | pressure | nearest-rank p95 | 20/20 | 0.503 | 0.647 | 0.144 | +28.61% |
| shape-id-lookup | pressure | nearest-rank p50 | 20/20 | 0.481 | 0.542 | 0.061 | +12.75% |
| shape-id-lookup | pressure | nearest-rank p95 | 20/20 | 0.693 | 0.722 | 0.029 | +4.19% |
| shape-in-list | pressure | nearest-rank p50 | 20/20 | 0.289 | 0.357 | 0.068 | +23.42% |
| shape-in-list | pressure | nearest-rank p95 | 20/20 | 0.452 | 0.477 | 0.025 | +5.54% |
| shape-null-check | pressure | nearest-rank p50 | 20/20 | 0.362 | 0.444 | 0.082 | +22.64% |
| shape-null-check | pressure | nearest-rank p95 | 20/20 | 0.651 | 0.725 | 0.074 | +11.44% |
| shape-regex | pressure | nearest-rank p50 | 20/20 | 0.403 | 0.446 | 0.043 | +10.76% |
| shape-regex | pressure | nearest-rank p95 | 20/20 | 0.658 | 0.751 | 0.093 | +14.07% |
| shape-one-hop | pressure | nearest-rank p50 | 20/20 | 0.450 | 0.545 | 0.095 | +21.19% |
| shape-one-hop | pressure | nearest-rank p95 | 20/20 | 0.667 | 0.821 | 0.155 | +23.18% |
| shape-one-hop-typed | pressure | nearest-rank p50 | 20/20 | 0.422 | 0.491 | 0.069 | +16.43% |
| shape-one-hop-typed | pressure | nearest-rank p95 | 20/20 | 1.033 | 0.623 | -0.409 | -39.66% |
| shape-two-hop | pressure | nearest-rank p50 | 20/20 | 0.413 | 0.508 | 0.095 | +23.09% |
| shape-two-hop | pressure | nearest-rank p95 | 20/20 | 0.862 | 0.677 | -0.185 | -21.43% |
| shape-incoming | pressure | nearest-rank p50 | 20/20 | 0.429 | 0.511 | 0.082 | +19.00% |
| shape-incoming | pressure | nearest-rank p95 | 20/20 | 0.831 | 0.679 | -0.152 | -18.28% |
| shape-var-length | pressure | nearest-rank p50 | 20/20 | 0.368 | 0.446 | 0.078 | +21.09% |
| shape-var-length | pressure | nearest-rank p95 | 20/20 | 0.540 | 0.606 | 0.066 | +12.15% |
| shape-path | pressure | nearest-rank p50 | 20/20 | 0.494 | 0.607 | 0.113 | +22.98% |
| shape-path | pressure | nearest-rank p95 | 20/20 | 0.630 | 0.836 | 0.206 | +32.66% |
| shape-traverse-filtered | pressure | nearest-rank p50 | 20/20 | 0.651 | 0.799 | 0.148 | +22.74% |
| shape-traverse-filtered | pressure | nearest-rank p95 | 20/20 | 0.835 | 1.027 | 0.193 | +23.06% |
| shape-count-all | pressure | nearest-rank p50 | 20/20 | 0.210 | 0.252 | 0.042 | +20.19% |
| shape-count-all | pressure | nearest-rank p95 | 20/20 | 0.299 | 0.386 | 0.087 | +29.26% |
| shape-count-label | pressure | nearest-rank p50 | 20/20 | 0.194 | 0.226 | 0.032 | +16.48% |
| shape-count-label | pressure | nearest-rank p95 | 20/20 | 0.324 | 0.395 | 0.071 | +21.92% |
| shape-group-count | pressure | nearest-rank p50 | 20/20 | 300.978 | 327.934 | 26.955 | +8.96% |
| shape-group-count | pressure | nearest-rank p95 | 20/20 | 399.176 | 430.431 | 31.255 | +7.83% |
| shape-distinct | pressure | nearest-rank p50 | 20/20 | 272.278 | 287.873 | 15.594 | +5.73% |
| shape-distinct | pressure | nearest-rank p95 | 20/20 | 315.101 | 361.279 | 46.177 | +14.65% |
| shape-collect | pressure | nearest-rank p50 | 20/20 | 1897.477 | 2072.484 | 175.007 | +9.22% |
| shape-collect | pressure | nearest-rank p95 | 20/20 | 2007.798 | 2384.493 | 376.695 | +18.76% |
| shape-count-traversal | pressure | nearest-rank p50 | 20/20 | 15.400 | 16.715 | 1.316 | +8.54% |
| shape-count-traversal | pressure | nearest-rank p95 | 20/20 | 20.671 | 18.077 | -2.595 | -12.55% |
| shape-order-by | pressure | nearest-rank p50 | 20/20 | 1929.906 | 2136.016 | 206.110 | +10.68% |
| shape-order-by | pressure | nearest-rank p95 | 20/20 | 2057.484 | 2444.850 | 387.365 | +18.83% |
| shape-order-by-desc | pressure | nearest-rank p50 | 20/20 | 1936.861 | 2146.073 | 209.211 | +10.80% |
| shape-order-by-desc | pressure | nearest-rank p95 | 20/20 | 2063.579 | 2441.624 | 378.045 | +18.32% |
| shape-skip | pressure | nearest-rank p50 | 20/20 | 1.206 | 1.330 | 0.124 | +10.30% |
| shape-skip | pressure | nearest-rank p95 | 20/20 | 1.285 | 1.561 | 0.276 | +21.44% |
| shape-function-calls | pressure | nearest-rank p50 | 20/20 | 0.577 | 0.584 | 0.007 | +1.23% |
| shape-function-calls | pressure | nearest-rank p95 | 20/20 | 0.670 | 0.679 | 0.009 | +1.34% |
| shape-case-expr | pressure | nearest-rank p50 | 20/20 | 0.475 | 0.494 | 0.019 | +4.07% |
| shape-case-expr | pressure | nearest-rank p95 | 20/20 | 0.522 | 0.541 | 0.019 | +3.59% |
| shape-coalesce | pressure | nearest-rank p50 | 20/20 | 0.484 | 0.486 | 0.002 | +0.46% |
| shape-coalesce | pressure | nearest-rank p95 | 20/20 | 0.550 | 0.605 | 0.055 | +9.92% |
| shape-labels-fn | pressure | nearest-rank p50 | 20/20 | 0.474 | 0.491 | 0.017 | +3.68% |
| shape-labels-fn | pressure | nearest-rank p95 | 20/20 | 0.540 | 0.585 | 0.045 | +8.31% |
| shape-with-filter | pressure | nearest-rank p50 | 20/20 | 0.431 | 0.453 | 0.022 | +5.03% |
| shape-with-filter | pressure | nearest-rank p95 | 20/20 | 0.489 | 0.546 | 0.057 | +11.70% |
| shape-with-aggregate | pressure | nearest-rank p50 | 20/20 | 475.085 | 495.495 | 20.409 | +4.30% |
| shape-with-aggregate | pressure | nearest-rank p95 | 20/20 | 520.984 | 576.977 | 55.993 | +10.75% |
| shape-cartesian | pressure | nearest-rank p50 | 20/20 | 0.655 | 0.676 | 0.021 | +3.19% |
| shape-cartesian | pressure | nearest-rank p95 | 20/20 | 0.722 | 0.765 | 0.043 | +6.02% |
| shape-union | pressure | nearest-rank p50 | 20/20 | 0.459 | 0.511 | 0.052 | +11.42% |
| shape-union | pressure | nearest-rank p95 | 20/20 | 0.510 | 0.599 | 0.089 | +17.40% |

Full methods, comparability reasons, isolated observations, raw request bodies and logs are retained in the downloadable report/evidence artifacts. UNAVAILABLE never means zero; a zero baseline has no defined percentage change.
