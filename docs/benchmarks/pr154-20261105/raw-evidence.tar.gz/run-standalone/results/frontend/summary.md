## Benchmark correctness and OOM: PASS

Timing differences are **report-only**; correctness, OOM and required coverage decide this gate. GitHub runner timings do not establish performance acceptance.

Base: `7c59d7993be51f0807495890d068effcfaff155b`  
Head: `190eba79a4428d3100c8fba480bd858a19ac893d`

### frontend-build-save

- **PASS** base frontend build/save correctness: fresh real64 build/save plus whole Tika/Hive/Kotlin correctness/readback complete; 7 G1 JVM receipts under 4 GiB; ExitOnOutOfMemoryError rejects even recoverable production OOM
- **PASS** base frontend build/save heap: fresh real64 build/save plus whole Tika/Hive/Kotlin correctness/readback complete; 7 G1 JVM receipts under 4 GiB; ExitOnOutOfMemoryError rejects even recoverable production OOM
- **PASS** base frontend build/save coverage: fresh real64 build/save plus whole Tika/Hive/Kotlin correctness/readback complete; 7 G1 JVM receipts under 4 GiB; ExitOnOutOfMemoryError rejects even recoverable production OOM
- **PASS** head frontend build/save correctness: fresh real64 build/save plus whole Tika/Hive/Kotlin correctness/readback complete; 7 G1 JVM receipts under 4 GiB; ExitOnOutOfMemoryError rejects even recoverable production OOM
- **PASS** head frontend build/save heap: fresh real64 build/save plus whole Tika/Hive/Kotlin correctness/readback complete; 7 G1 JVM receipts under 4 GiB; ExitOnOutOfMemoryError rejects even recoverable production OOM
- **PASS** head frontend build/save coverage: fresh real64 build/save plus whole Tika/Hive/Kotlin correctness/readback complete; 7 G1 JVM receipts under 4 GiB; ExitOnOutOfMemoryError rejects even recoverable production OOM
- **PASS** host OOM events: before=None; after=None

| Case | Stage | Measurement | N base/head | Base ms | Head ms | Delta ms | Delta % |
| --- | --- | --- | --- | ---: | ---: | ---: | ---: |
| real64-build-save | frontend-build-save | JMH SingleShotTime | 1/1 | 280728.161 | 266061.404 | -14666.757 | -5.22% |

Full methods, comparability reasons, isolated observations, raw request bodies and logs are retained in the downloadable report/evidence artifacts. UNAVAILABLE never means zero; a zero baseline has no defined percentage change.
