# Benchmark correctness and OOM: PASS

Timing is report-only. No latency, throughput, CPU or RSS threshold affects acceptance. These GitHub runner observations do not establish performance regression acceptance. Missing observations are UNAVAILABLE.

## frontend-build-save

Base: `7c59d7993be51f0807495890d068effcfaff155b`  
Head: `190eba79a4428d3100c8fba480bd858a19ac893d`

| Gate | Kind | Result | Detail |
| --- | --- | --- | --- |
| base frontend build/save correctness | correctness | PASS | fresh real64 build/save plus whole Tika/Hive/Kotlin correctness/readback complete; 7 G1 JVM receipts under 4 GiB; ExitOnOutOfMemoryError rejects even recoverable production OOM |
| base frontend build/save heap | heap | PASS | fresh real64 build/save plus whole Tika/Hive/Kotlin correctness/readback complete; 7 G1 JVM receipts under 4 GiB; ExitOnOutOfMemoryError rejects even recoverable production OOM |
| base frontend build/save coverage | coverage | PASS | fresh real64 build/save plus whole Tika/Hive/Kotlin correctness/readback complete; 7 G1 JVM receipts under 4 GiB; ExitOnOutOfMemoryError rejects even recoverable production OOM |
| head frontend build/save correctness | correctness | PASS | fresh real64 build/save plus whole Tika/Hive/Kotlin correctness/readback complete; 7 G1 JVM receipts under 4 GiB; ExitOnOutOfMemoryError rejects even recoverable production OOM |
| head frontend build/save heap | heap | PASS | fresh real64 build/save plus whole Tika/Hive/Kotlin correctness/readback complete; 7 G1 JVM receipts under 4 GiB; ExitOnOutOfMemoryError rejects even recoverable production OOM |
| head frontend build/save coverage | coverage | PASS | fresh real64 build/save plus whole Tika/Hive/Kotlin correctness/readback complete; 7 G1 JVM receipts under 4 GiB; ExitOnOutOfMemoryError rejects even recoverable production OOM |
| host OOM events | heap | PASS | before=None; after=None |

| Case | Stage | Workload | Method | Samples base/head | Base ms | Head ms | Delta ms | Delta % | Evidence |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| real64-build-save | frontend-build-save | jar/4-corpora/64-distinct-shards | JMH SingleShotTime; one fork; informational only | 1/1 | 280728.161 | 266061.404 | -14666.757 | -5.22% | report only |

Raw artifacts are retained alongside the suite JSON.
